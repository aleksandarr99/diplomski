﻿using TournamentModels;

namespace DatabaseCommunication
{
    internal class ValueValidator
    {
        private static string nullOrEmptyStringMessage = "can not be null or empty string";
        public static (bool, string) ValidateAdmin(Admin admin)
        {
            if (admin == null)
                return (false, "Admin is null");

            if (string.IsNullOrEmpty(admin.Name))
                return (false, "Name " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(admin.Surname))
                return (false, "Surname " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(admin.Password))
                return (false, "Password " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(admin.Username))
                return (false, "Username " + nullOrEmptyStringMessage);

            return (true, "Valid values");

        }

        public static (bool, string) ValidatePlayer(Player player)
        {
            if (player == null)
                return (false, "Player is null");

            if (string.IsNullOrEmpty(player.Name))
                return (false, "Name " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(player.Surname))
                return (false, "Lastname " + nullOrEmptyStringMessage);
            if (player.Number < 0)
                return (false, "Number must be equal or bigger than 0.");

            return (true, "Valid values");
        }

        public static (bool, string) ValidateCountry(Country country)
        {
            if (country == null)
                return (false, "Country is null");

            if (string.IsNullOrEmpty(country.Name))
                return (false, "Name " + nullOrEmptyStringMessage);
            return (true, "Valid values");
        }

        public static (bool, string) ValidateReferee(Referee referee)
        {
            if (referee == null)
                return (false, "Referee is null");

            if (string.IsNullOrEmpty(referee.Name))
                return (false, "Name " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(referee.Surname))
                return (false, "Surname " + nullOrEmptyStringMessage);
            if (referee.Experience < 0)
                return (false, "Experiance should be greater than 0" + nullOrEmptyStringMessage);

            return (true, "Valid values");
        }

        public static (bool, string) ValidateTournament(TournamentModels.Tournament tournament)
        {
            if (tournament == null)
                return (false, "Tournament is null");

            if (string.IsNullOrEmpty(tournament.Name))
                return (false, "Name " + nullOrEmptyStringMessage);
            if (string.IsNullOrEmpty(tournament.City))
                return (false, "City " + nullOrEmptyStringMessage);
            if (tournament.AdminID == -1)
                return (false, "Invalid Admin");

            if (tournament.StartTime >= tournament.EndTime)
                return (false, "Start date have to be before End date.");

            return (true, "Valid values");
        }

        public static (bool, string) ValidateGame(Game game, bool update = false)
        {
            if (game == null)
                return (false, "Game is null");

            if (game.FirstTeamID == -1)
                return (false, "Invalid First Team");
            if (game.SecondTeamID == -1)
                return (false, "Invalid Second Team");
            if (game.RefereeID == -1)
                return (false, "Invalid Referee");
            if (game.TournamentID == -1)
                return (false, "Invalid Tournament");
            if(game.Stage == -1)
                return (false, "Invalid Stage");

            if (update)
            {
                if (game.FirstTeamScore == -1)
                    return (false, "Invalid First Team Score");
                if (game.SecondTeamScore == -1)
                    return (false, "Invalid Second Team Score");
            }

            return (true, "Valid values");
        }
    }
}
