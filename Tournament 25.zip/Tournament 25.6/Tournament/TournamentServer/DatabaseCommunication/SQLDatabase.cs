﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace DatabaseCommunication
{
    public abstract class SQLDatabase
    {
        // MDSP
        private readonly string defaultConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=data;Integrated Security=True;";
        // home
        //private readonly string defaultConnectionString = @"Server=localhost;Database=Football;Trusted_Connection=True;";
        protected SqlConnection _connection;
        public SQLDatabase(string connectionString = null)
        {
            if (string.IsNullOrEmpty(connectionString))
                connectionString = defaultConnectionString;

            _connection = new SqlConnection(connectionString);
        }

        protected SqlTransaction BeginTransaction(string name)
        {
            if (_connection.State == System.Data.ConnectionState.Closed)
                OpenConnection();
            return _connection.BeginTransaction();
        }

        protected void OpenConnection()
        {
            _connection.Open();
        }

        protected void CloseConnection()
        {
            if (_connection != null && _connection.State != System.Data.ConnectionState.Closed)
                _connection.Close();
        }

        protected SqlCommand CreateCommand(string commandString, SqlTransaction transaction = null)
        {
            if (_connection.State == System.Data.ConnectionState.Closed)
                OpenConnection();

            return transaction == null
                ? new SqlCommand(commandString, _connection)
                : new SqlCommand(commandString, _connection, transaction);
        }

        protected string CreateConditionString(Dictionary<string, string> parameters, bool and = true)
        {
            if(parameters == null || parameters.Count == 0)
                return string.Empty;

            var operation = and ? "AND" : "OR";

            var paramsList = parameters.Select(item => $"{item.Key} LIKE '%{item.Value}%'");
            return string.Join($" {operation} ", paramsList.ToList());
        }

    }
}
