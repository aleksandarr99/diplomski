﻿using System;
using System.Collections.Generic;
using System.Linq;
using TournamentModels;

namespace DatabaseCommunication
{
    public class DummyDatabase : ITournamentDatabase
    {
        public DummyDatabase()
        {
            InitValues();
        }

        private List<Player> _players = new List<Player>();
        private List<Admin> _admins = new List<Admin>();
        private List<Game> _games = new List<Game>();
        private List<Referee> _referees = new List<Referee>();
        private List<Country> _countries = new List<Country>();
        private List<TournamentModels.Tournament> _tournaments = new List<TournamentModels.Tournament>();


        private void InitValues()
        {
            _players = new List<Player>()
            {
                new Player()
                {
                    Number = 14,
                    Name = "Mladen",
                    Surname = "Milosevic"
                },
                new Player()
                {
                    Number = 2,
                    Name = "Aleksandar",
                    Surname = "Radojevic"
                },
                new Player()
                {
                    Number = 7,
                    Name = "Mica",
                    Surname = "Radojevic"
                }
            };

            _admins = new List<Admin>()
            {
                new Admin()
                {
                    Id = 1,
                    Username = "aca",
                    Name = "Aleksandar",
                    Surname = "Radojevic",
                },
                new Admin()
                {
                    Id = 2,
                    Username = "mika",
                    Name = "Mika",
                    Surname = "Mikic",
                },
                new Admin()
                {
                    Id = 3,
                    Username = "pera",
                    Name = "Pera",
                    Surname = "Peric",
                }
            };

            _referees = new List<Referee>()
            {
                new Referee()
                {
                    Id = 2,
                    Name = "Mika",
                    Surname = "Mikic",
                    Experience = 2
                },
                new Referee()
                {
                    Id = 3,
                    Name = "Pera",
                    Surname = "Peric",
                    Experience = 5
                }
            };

            _tournaments = new List<TournamentModels.Tournament>()
            {
                new TournamentModels.Tournament()
                {
                    Admin = _admins[0],
                    City = "Medelin, Columbia",
                    EndTime = DateTime.Now,
                    StartTime = new DateTime(2023, 07, 15),
                    Name = "Copa America"
                }
            };

            _countries = new List<Country>()
            {
                new Country()
                {
                    Id = 1,
                    Name = "Serbia",
                    Players = new List<Player>()
                    {
                        _players[0],
                        _players[1]
                    }
                },
                new Country()
                {
                    Id = 2,
                    Name = "Spain"
                },
                new Country()
                {
                    Id = 3,
                    Name = "Germany"
                },
            };

            _games = new List<Game>()
            {
                new Game()
                {
                    FirstTeam = _countries[0],
                    SecondTeam = _countries[1],
                    FirstTeamScore = 3,
                    SecondTeamScore = 2,
                    Referee = _referees[0],
                    Tournament = _tournaments[0]
                }
            };
        }

        #region Players

        public (List<Player>, string) GetPlayers()
        {
            return (_players, "All Good");
        }

        public (List<Player>, string) SearchPlayers(Dictionary<string, string> parameters, bool and = true)
        {
            List<Player> players = _players;
            if (parameters.TryGetValue("Name", out string name))
                players = players.FindAll(x => x.Name == name);
            if (parameters.TryGetValue("Lastname", out string lastname))
                players = players.FindAll(x => x.Surname == lastname);

            return (players, "All Good");
        }

        public (bool, string) DeletePlayer(Player player)
        {
            var p = _players.FirstOrDefault(x => x.CountryID == player.CountryID && x.Number == player.Number);
            if (p == null)
                return (false, "Cannot find player");

            _players.Remove(p);
            return (true, "All Good");
        }

        public (bool, string) UpdatePlayer(Player player)
        {
            var existing = _players.FirstOrDefault(x => x.CountryID == player.CountryID && x.Number == player.Number);

            if (existing == null)
                return (false, "Cannot find player");
            existing.Name = player.Name;
            existing.Surname = player.Surname;

            return (true, "All Good");
        }

        public (bool, string) CreatePlayer(Player player)
        {
            if (_players.Any(x => x.CountryID == player.CountryID && x.Number == player.Number))
                return (false, "Already exists a player with a same CountryID and Number");

            _players.Add(player);
            return (false, "All Good");
        }

        #endregion

        #region Admins

        public (Admin, string) Login(string username, string password)
        {
            return (null, "Not implemented");
        }

        public (List<Admin>, string) GetAdmins()
        {
            return (null, "not implemented");
        }

        public (List<Admin>, string) SearchAdmins(Dictionary<string, string> parameters, bool and = true)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteAdmin(int id)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateAdmin(Admin admin)
        {
            return (false, "not implemented");
        }

        public (int, string) CreateAdmin(Admin admin)
        {
            return (-1, "not implemented");
        }

        #endregion

        #region Country

        public (List<Country>, string) GetCountries()
        {
            return (null, "not implemented");
        }

        public (List<Country>, string) SearchCountries(Dictionary<string, string> parameters, bool and = true)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteCountry(int id)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateCountry(Country country)
        {
            return (false, "not implemented");
        }

        public (int, string) CreateCountry(Country country)
        {
            return (-1, "not implemented");
        }

        #endregion

        #region Referee

        public (List<Referee>, string) GetReferees()
        {
            return (null, "not implemented");
        }

        public (List<Referee>, string) SearchReferees(Dictionary<string, string> parameters, bool and = true)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteReferee(int id)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateReferee(Referee referee)
        {
            return (false, "not implemented");
        }

        public (int, string) CreateReferee(Referee referee)
        {
            return (-1, "not implemented");
        }

        #endregion

        #region Tournament

        public (int, string) CreateTournament(TournamentModels.Tournament tournament)
        {
            return (-1, "not implemented");
        }

        public (List<TournamentModels.Tournament>, string) GetTournaments()
        {
            return (null, "not implemented");
        }

        public (List<TournamentModels.Tournament>, string) SearchTournaments(Dictionary<string, string> parameters, bool and = true)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteTournament(int id)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateTournament(TournamentModels.Tournament tournament)
        {
            return (false, "not implemented");
        }
        #endregion

        #region Game

        public (List<Game>, string) GetGames()
        {
            return (null, "not implemented");
        }

        public (List<Game>, string) SearchGames(Dictionary<string, string> parameters, bool and = true)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteGame(int id)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateGame(Game game)
        {
            return (false, "not implemented");
        }

        public (List<int>, string) CreateGames(List<Game> games)
        {
            return (null, "not implemented");
        }

        public (bool, string) UpdateGames(List<Game> games)
        {
            return (false, "not implemented");
        }
        #endregion

        #region Participation

        public (int, string) CreateParticipation(int tournamentId, int countryId, int stage)
        {
            return (-1, "not implemented");
        }

        public (List<KeyValuePair<int, int>>, string) GetTournamentParticipants(int tournamentId)
        {
            return (null, "not implemented");
        }

        public (List<KeyValuePair<int, int>>, string) GetCountryParticipations(int countryId)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteParticipation(int tournamentId, int countryId)
        {
            return (false, "not implemented");
        }

        public (bool, string) UpdateParticipation(int tournamentId, int countryId, int stage)
        {
            return (false, "not implemented");
        }
        #endregion


        #region Engagement
        public (int, string) CreateEngagement(int tournamentId, int refereeId)
        {
            return (-1, "not implemented");
        }

        public (List<int>, string) GetTournamentReferees(int tournamentId)
        {
            return (null, "not implemented");
        }

        public (List<int>, string) GetRefereeEngagements(int refereeId)
        {
            return (null, "not implemented");
        }

        public (bool, string) DeleteEngagement(int tournamentId, int refereeId)
        {
            return (false, "not implemented");
        }

        #endregion
        public (List<Odds>, string) SearchOdds(int homeId = -1, int awayId = -1)
        {
            return (null, "not implemented");
        }
    }
}
