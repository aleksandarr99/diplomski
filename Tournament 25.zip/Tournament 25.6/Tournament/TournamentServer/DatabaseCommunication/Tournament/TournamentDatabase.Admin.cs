﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        #region Admin

        public (Admin, string) Login(string username, string password)
        {
            try
            {
                var command = CreateCommand($"select * from {ADMIN_TABLE_NAME} where Username='{username}' AND Password='{password}'");
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Admin admin = GetAdminFromReader(reader);
                        return (admin, "All Good");
                    }
                }
                return (null, "Invalid Credentials");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (int, string) CreateAdmin(Admin admin)
        {
            var valid = ValueValidator.ValidateAdmin(admin);

            if (!valid.Item1)
                return (-1, valid.Item2);

            try
            {
                var command = CreateCommand($"insert into {ADMIN_TABLE_NAME} " +
                    $" values ('{admin.Name}', '{admin.Surname}', '{admin.Username}', '{admin.Password}');");
                command.ExecuteNonQuery();


                var idCommand = CreateCommand($"select Max(ID) from {ADMIN_TABLE_NAME};");
                var id = (int)idCommand.ExecuteScalar();

                admin.Id = id;
                return (id, "All Good");
            }
            catch (Exception e)
            {
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeleteAdmin(int id)
        {
            if (id == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {ADMIN_TABLE_NAME} WHERE ID={id}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<Admin>, string) GetAdmins()
        {
            List<Admin> admins = new List<Admin>();
            try
            {
                var command = CreateCommand($"select * from {ADMIN_TABLE_NAME}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Admin admin = GetAdminFromReader(reader);
                        admins.Add(admin);
                    }
                }

                return (admins, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<Admin>, string) SearchAdmins(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters, and);
            if (string.IsNullOrEmpty(conditions))
                return GetAdmins();

            try
            {
                var admins = new List<Admin>();
                var command = CreateCommand($"select * from {ADMIN_TABLE_NAME} where {conditions}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var admin = GetAdminFromReader(reader);
                        admins.Add(admin);
                    }
                }
                return (admins, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateAdmin(Admin admin)
        {
            if (admin == null)
                return (false, "Admin is null");

            var validate = ValueValidator.ValidateAdmin(admin);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {ADMIN_TABLE_NAME} SET " +
                    $"Name = '{admin.Name}', " +
                    $"Surname = '{admin.Surname}', " +
                    $"Username = '{admin.Username}', " +
                    $"Password = '{admin.Password}' " +
                    $"where ID={admin.Id};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        #endregion

        private Admin GetAdminFromReader(SqlDataReader reader)
        {
            Admin admin = new Admin
            {
                Id = (int)reader["ID"],
                Name = (string)reader["Name"],
                Surname = (string)reader["Surname"],
                Username = (string)reader["Username"],
                Password = (string)reader["Password"]
            };
            return admin;
        }

    }
}
