﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        public (int, string) CreateEngagement(int tournamentId, int refereeId)
        {
            try
            {
                var command = CreateCommand($"insert into {ENGAGEMENT_TABLE_NAME} " +
                    $" values ('{tournamentId}', '{refereeId}');");
                command.ExecuteNonQuery();

                return (1, "All Good");
            }
            catch (Exception e)
            {
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<int>, string) GetTournamentReferees(int tournamentId)
        {
            List<int> referees = new List<int>();
            try
            {
                var command = CreateCommand($"select * from {ENGAGEMENT_TABLE_NAME} where TournamentID={tournamentId}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int countryId = (int)reader["RefereeID"];
                        referees.Add(countryId);
                    }
                }
                return (referees, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (List<int>, string) GetRefereeEngagements(int refereeId)
        {
            List<int> participants = new List<int>();
            try
            {
                var command = CreateCommand($"select * from {ENGAGEMENT_TABLE_NAME} where RefereeID={refereeId}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int tournamentId = (int)reader["TournamentID"];
                        participants.Add(refereeId);
                    }
                }
                return (participants, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) DeleteEngagement(int tournamentId, int refereeId)
        {
            if (tournamentId == -1 || refereeId == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {ENGAGEMENT_TABLE_NAME} WHERE TournamentID={tournamentId} AND RefereeID={refereeId};");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }
    }
}
