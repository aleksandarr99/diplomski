﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        public (List<int>, string) CreateGames(List<Game> games)
        {
            SqlTransaction transaction = BeginTransaction("Games creation transaction");

            try
            {
                List<int> ids = new List<int>();
                games.ForEach(game =>
                {
                    var valid = ValueValidator.ValidateGame(game);

                    if (!valid.Item1)
                        throw new Exception(valid.Item2);

                    var command = CreateCommand($"insert into {GAME_TABLE_NAME} " +
                        $" values ({game.FirstTeamScore}," +
                                    $"{game.SecondTeamScore}," +
                                    $"{game.Stage}," +
                                    $"{game.TournamentID}," +
                                    $"{game.FirstTeamID}," +
                                    $"{game.SecondTeamID}," +
                                    $"{game.RefereeID}," +
                                    $"NULL);", transaction);
                    command.ExecuteNonQuery();
                });

                transaction.Commit();

                games.ForEach(game =>
                {
                    var idCommand = CreateCommand($"select MAX(ID) from {GAME_TABLE_NAME} where " +
                        $"TournamentID={game.TournamentID} AND " +
                        $"FirstTeamID={game.FirstTeamID} AND " +
                        $"SecondTeamID={game.SecondTeamID} AND " +
                        $"RefereeID={game.RefereeID} AND " +
                        $"Stage={game.Stage};", transaction);

                    game.Id = (int)idCommand.ExecuteScalar();

                    ids.Add(game.Id);
                });
                return (ids, "All Good");
            }
            catch (Exception e)
            {
                try
                {
                    transaction.Rollback();
                }
                catch { }
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateGames(List<Game> games)
        {
            SqlTransaction transaction = BeginTransaction("Games update transaction");
            try
            {
                games.ForEach(game =>
                {
                    var valid = ValueValidator.ValidateGame(game, true);

                    if (!valid.Item1)
                        throw new Exception(valid.Item2);

                    string commandString =
                        $"update {GAME_TABLE_NAME} SET " +
                        $"FirstTeamScore = {game.FirstTeamScore}, " +
                        $"SecondTeamScore = {game.SecondTeamScore} " +
                        $"where ID={game.Id};";

                    var command = CreateCommand(commandString, transaction);
                    command.ExecuteNonQuery();
                });

                transaction.Commit();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                try
                {
                    transaction.Rollback();
                }
                catch { }
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeleteGame(int id)
        {
            if (id == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {GAME_TABLE_NAME} WHERE ID={id}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<Game>, string) GetGames()
        {
            List<Game> games = new List<Game>();
            try
            {
                var command = CreateCommand($"select * from {GAME_TABLE_NAME}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Game game = GetGameFromReader(reader);
                        games.Add(game);
                    }
                }

                return (games, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<Game>, string) SearchGames(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters, and);
            if (string.IsNullOrEmpty(conditions))
                return GetGames();

            try
            {
                var games = new List<Game>();
                var command = CreateCommand($"select * from {GAME_TABLE_NAME} where {conditions}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var game = GetGameFromReader(reader);
                        games.Add(game);
                    }
                }
                return (games, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateGame(Game game)
        {
            if (game == null)
                return (false, "Game is null");

            var validate = ValueValidator.ValidateGame(game, true);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {GAME_TABLE_NAME} SET " +
                    $"FirstTeamScore = {game.FirstTeamScore}, " +
                    $"SecondTeamScore = {game.SecondTeamScore}, " +
                    $"where ID={game.Id};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        private Game GetGameFromReader(SqlDataReader reader)
        {
            Game game = new Game
            {
                Id = (int)reader["ID"],
                FirstTeamScore = (int)reader["FirstTeamScore"],
                SecondTeamScore = (int)reader["SecondTeamScore"],
                Stage = (int)reader["Stage"],
                TournamentID = (int)reader["TournamentID"],
                FirstTeamID = (int)reader["FirstTeamID"],
                SecondTeamID = (int)reader["SecondTeamID"],
                RefereeID = (int)reader["RefereeID"],
            };
            return game;
        }
    }
}
