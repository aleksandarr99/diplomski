﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        private static readonly string dateTimeFormat = "MM/dd/yyyy HH:mm:ss";

        public (int, string) CreateTournament(TournamentModels.Tournament tournament)
        {
            var valid = ValueValidator.ValidateTournament(tournament);

            if (!valid.Item1)
                return (-1, valid.Item2);
            SqlTransaction transaction = BeginTransaction("Create Tournament Transaction");

            try
            {
                var command = CreateCommand($"insert into {TOURNAMENT_TABLE_NAME} " +
                    $" values ('{tournament.Name}', '{tournament.City}', '{tournament.Description}', '{tournament.StartTime.ToString(dateTimeFormat)}', '{tournament.EndTime.ToString(dateTimeFormat)}', '{tournament.AdminID}', '{(int)tournament.Capacity}', NULL);", transaction);
                command.ExecuteNonQuery();

                var idCommand = CreateCommand($"select Max(ID) from {TOURNAMENT_TABLE_NAME};", transaction);
                var id = (int)idCommand.ExecuteScalar();

                tournament.Id = id;

                foreach (var refereeId in tournament.RefereeIds)
                {
                    command = CreateCommand($"insert into {ENGAGEMENT_TABLE_NAME} " +
                    $" values ({refereeId}, {tournament.Id});", transaction);
                    command.ExecuteNonQuery();
                }
                foreach (var countryId in tournament.CountryIds)
                {
                    command = CreateCommand($"insert into {PARTICIPATION_TABLE_NAME} " +
                    $" values ({countryId}, {tournament.Id}, {((int)tournament.Capacity) / 2});", transaction);
                    command.ExecuteNonQuery();
                }

                transaction.Commit();

                return (id, "All Good");
            }
            catch (Exception e)
            {
                try
                {
                    transaction.Rollback();
                }
                catch { }
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeleteTournament(int id)
        {
            if (id == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {TOURNAMENT_TABLE_NAME} WHERE ID={id}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<TournamentModels.Tournament>, string) GetTournaments()
        {
            List<TournamentModels.Tournament> tournaments = new List<TournamentModels.Tournament>();
            try
            {
                var command = CreateCommand($"select * from {TOURNAMENT_TABLE_NAME}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TournamentModels.Tournament tournament = GetTournamentFromReader(reader);
                        tournaments.Add(tournament);
                    }
                }

                foreach (var tournament in tournaments)
                {
                    var participants = GetTournamentParticipants(tournament.Id).Item1;

                    foreach (var participant in participants)
                        tournament.CountryIds.Add(participant.Key);

                    var referees = GetTournamentReferees(tournament.Id).Item1;
                    foreach (var referee in referees)
                        tournament.RefereeIds.Add(referee);
                }

                return (tournaments, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<TournamentModels.Tournament>, string) SearchTournaments(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters, and);
            if (string.IsNullOrEmpty(conditions))
                return GetTournaments();

            try
            {
                var tournaments = new List<TournamentModels.Tournament>();
                var command = CreateCommand($"select * from {TOURNAMENT_TABLE_NAME} where {conditions}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var admin = GetTournamentFromReader(reader);
                        tournaments.Add(admin);
                    }
                }
                return (tournaments, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateTournament(TournamentModels.Tournament tournament)
        {
            if (tournament == null)
                return (false, "Tournament is null");

            var validate = ValueValidator.ValidateTournament(tournament);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {TOURNAMENT_TABLE_NAME} SET " +
                    $"Name = '{tournament.Name}', " +
                    $"City = '{tournament.City}', " +
                    $"Description = '{tournament.Description}', " +
                    $"WinnerName = '{tournament.WinnerName}', " +
                    $"StartTime = '{tournament.StartTime}', " +
                    $"EndTime = '{tournament.EndTime}' " +
                    $"where ID={tournament.Id};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        private TournamentModels.Tournament GetTournamentFromReader(SqlDataReader reader)
        {
            TournamentModels.Tournament tournament = new TournamentModels.Tournament
            {
                Id = (int)reader["ID"],
                Name = (string)reader["Name"],
                City = (string)reader["City"],
                Description = (string)reader["Description"],
                AdminID = (int)reader["AdminID"],
                Capacity = (TournamentCapacity)reader["Capacity"]
            };
            string startTime = (string)reader["StartTime"];
            string endTime = (string)reader["EndTime"];

            if (reader["WinnerName"] is string winner)
                tournament.WinnerName = winner;

            if (DateTime.TryParse(startTime, out DateTime startResult))
                tournament.StartTime = startResult;

            if (DateTime.TryParse(endTime, out DateTime endResult))
                tournament.EndTime= endResult;
            return tournament;
        }
    }
}
