﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        public (int, string) CreateParticipation(int tournamentId, int countryId, int stage)
        {
            try
            {
                var command = CreateCommand($"insert into {PARTICIPATION_TABLE_NAME} " +
                    $" values ('{tournamentId}', '{countryId}', '{stage}');");
                command.ExecuteNonQuery();

                return (1, "All Good");
            }
            catch (Exception e)
            {
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<KeyValuePair<int, int>>, string) GetTournamentParticipants(int tournamentId)
        {
            List<KeyValuePair<int, int>> participants = new List<KeyValuePair<int, int>>();
            try
            {
                var command = CreateCommand($"select * from {PARTICIPATION_TABLE_NAME} where TournamentID={tournamentId}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int countryId = (int)reader["CountryID"];
                        int stage = (int)reader["Stage"];
                        participants.Add(new KeyValuePair<int, int>(countryId, stage));
                    }
                }
                return (participants, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (List<KeyValuePair<int, int>>, string) GetCountryParticipations(int countryId)
        {
            List<KeyValuePair<int, int>> participants = new List<KeyValuePair<int, int>>();
            try
            {
                var command = CreateCommand($"select * from {PARTICIPATION_TABLE_NAME} where CountryID={countryId}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int tournamentId = (int)reader["TournamentID"];
                        int stage = (int)reader["Stage"];
                        participants.Add(new KeyValuePair<int, int>(countryId, stage));
                    }
                }
                return (participants, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) DeleteParticipation(int tournamentId, int countryId)
        {
            if (tournamentId == -1 || countryId == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {PARTICIPATION_TABLE_NAME} WHERE TournamentID={tournamentId} AND CountryID={countryId};");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateParticipation(int tournamentId, int countryId, int stage)
        {
            if (tournamentId == -1 || countryId == -1)
                return (false, "Id cannot be -1");

            try
            {
                string commandString =
                    $"update {PARTICIPATION_TABLE_NAME} SET " +
                    $"Stage = '{stage}' " +
                    $"where TournamentID={tournamentId} AND CountryID={countryId};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }
    }
}
