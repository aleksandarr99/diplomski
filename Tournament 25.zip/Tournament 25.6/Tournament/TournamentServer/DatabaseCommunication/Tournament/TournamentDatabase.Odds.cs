﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        public (List<Odds>, string) SearchOdds(int homeId = -1, int awayId = -1)
        {
            List<Odds> odds = new List<Odds>();
            try
            {
                string commandString = homeId == -1 || awayId == -1 ?
                    $"select * from {ODDS_TABLE_NAME}" :
                    $"select * from {ODDS_TABLE_NAME} where HomeID={homeId} AND AwayID={awayId}";
                var command = CreateCommand(commandString);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                        odds.Add(GetOddsFromReader(reader));
                }

                return (odds, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        private Odds GetOddsFromReader(SqlDataReader reader)
        {
            return new Odds()
            {
                Id = (int)reader["ID"],
                HomeId = (int)reader["HomeID"],
                HomeWinOdds = (double)reader["HomeWinOdds"],
                AwayId = (int)reader["AwayID"],
                AwayWinOdds = (double)reader["AwayWinOdds"],
                DrawOdds = (double)reader["DrawOdds"]
            };
        }
    }
}
