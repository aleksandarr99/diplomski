﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        #region Players
        public (bool, string) CreatePlayer(Player player)
        {
            var valid = ValueValidator.ValidatePlayer(player);

            if (!valid.Item1)
                return valid;

            try
            {
                var command = CreateCommand($"insert into {PLAYER_TABLE_NAME} " +
                    $" values ('{player.CountryID}', '{player.Number}', '{player.Name}', '{player.Surname}');");
                command.ExecuteNonQuery();

                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeletePlayer(Player player)
        {
            if (player == null)
                return (false, "Player is null");

            try
            {
                var command = CreateCommand($"delete from {PLAYER_TABLE_NAME} WHERE CountryID={player.CountryID} AND Number={player.Number}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<Player>, string) GetPlayers()
        {
            List<Player> players = new List<Player>();
            try
            {
                var command = CreateCommand($"select * from {PLAYER_TABLE_NAME}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Player player = GetPlayerFromReader(reader);
                        players.Add(player);
                    }
                }

                return (players, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<Player>, string) SearchPlayers(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters);

            if (string.IsNullOrEmpty(conditions))
                return GetPlayers();

            try
            {
                var players = new List<Player>();
                var command = CreateCommand($"select * from {PLAYER_TABLE_NAME} where {conditions}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var player = GetPlayerFromReader(reader);
                        players.Add(player);
                    }
                }
                return (players, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdatePlayer(Player player)
        {
            if (player == null)
                return (false, "Player is null");

            var validate = ValueValidator.ValidatePlayer(player);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {PLAYER_TABLE_NAME} SET " +
                    $"Name = '{player.Name}', " +
                    $"Surname = '{player.Surname}' " +
                    $"where CountryID={player.CountryID} AND Number={player.Number};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        #endregion

        private Player GetPlayerFromReader(SqlDataReader reader)
        {
            Player player = new Player();
            player.CountryID = (int)reader["CountryID"];
            player.Number = (int)reader["Number"];
            player.Name = (string)reader["Name"];
            player.Surname = (string)reader["Surname"];
            return player;
        }
    }
}
