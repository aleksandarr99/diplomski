﻿namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase : SQLDatabase, ITournamentDatabase
    {
        private static readonly string REFEREE_TABLE_NAME = "REFEREE";
        private static readonly string ADMIN_TABLE_NAME = "ADMIN";
        private static readonly string PLAYER_TABLE_NAME = "PLAYER";
        private static readonly string COUNTRY_TABLE_NAME = "COUNTRY";
        private static readonly string TOURNAMENT_TABLE_NAME = "TOURNAMENT";
        private static readonly string GAME_TABLE_NAME = "GAME";
        private static readonly string PARTICIPATION_TABLE_NAME = "PARTICIPATION";
        private static readonly string ENGAGEMENT_TABLE_NAME = "ENGAGEMENT";
        private static readonly string ODDS_TABLE_NAME = "ODDS";
        public TournamentDatabase(string connectionString = null)
            :base (connectionString)
        {

        }
    }
}
