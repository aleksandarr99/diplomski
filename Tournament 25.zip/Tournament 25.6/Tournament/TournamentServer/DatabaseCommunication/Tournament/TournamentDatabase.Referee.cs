﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    public partial class TournamentDatabase
    {
        #region Referee

        public (int, string) CreateReferee(Referee referee)
        {
            var valid = ValueValidator.ValidateReferee(referee);

            if (!valid.Item1)
                return (-1, valid.Item2);

            try
            {
                var command = CreateCommand($"insert into {REFEREE_TABLE_NAME} " +
                    $" values ('{referee.Name}', '{referee.Surname}', '{referee.Experience}');");
                command.ExecuteNonQuery();


                var idCommand = CreateCommand($"select Max(ID) from {REFEREE_TABLE_NAME};");
                var id = (int)idCommand.ExecuteScalar();

                referee.Id = id;
                return (id, "All Good");
            }
            catch (Exception e)
            {
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeleteReferee(int id)
        {
            if (id == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {REFEREE_TABLE_NAME} WHERE ID={id}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<Referee>, string) GetReferees()
        {
            List<Referee> referees = new List<Referee>();
            try
            {
                var command = CreateCommand($"select * from {REFEREE_TABLE_NAME};");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Referee referee = GetRefereeFromReader(reader);
                        referees.Add(referee);
                    }
                }

                return (referees, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<Referee>, string) SearchReferees(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters, and);
            if (string.IsNullOrEmpty(conditions))
                return GetReferees();

            try
            {
                var referees = new List<Referee>();
                var command = CreateCommand($"select * from {REFEREE_TABLE_NAME} where {conditions};");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var referee = GetRefereeFromReader(reader);
                        referees.Add(referee);
                    }
                }
                return (referees, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateReferee(Referee referee)
        {
            if (referee == null)
                return (false, "Referee is null");

            var validate = ValueValidator.ValidateReferee(referee);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {REFEREE_TABLE_NAME} SET " +
                    $"Name = '{referee.Name}', " +
                    $"Surname = '{referee.Surname}', " +
                    $"Experience = {referee.Experience} " +
                    $"where ID={referee.Id};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        private Referee GetRefereeFromReader(SqlDataReader reader)
        {
            Referee referee = new Referee();
            referee.Id = (int)reader["Id"];
            referee.Name = (string)reader["Name"];
            referee.Surname = (string)reader["Surname"];
            referee.Experience = (int)reader["Experience"];
            return referee;
        }

        #endregion
    }
}
