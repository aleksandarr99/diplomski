﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using TournamentModels;

namespace DatabaseCommunication.Tournament
{
    partial class TournamentDatabase
    {
        public (int, string) CreateCountry(Country country)
        {
            var valid = ValueValidator.ValidateCountry(country);

            if (!valid.Item1)
                return (-1, valid.Item2);

            try
            {
                var command = CreateCommand($"insert into {COUNTRY_TABLE_NAME} " +
                    $" values ('{country.Name}');");
                command.ExecuteNonQuery();

                var idCommand = CreateCommand($"select Max(ID) from {COUNTRY_TABLE_NAME};");
                var id = (int)idCommand.ExecuteScalar();

                country.Id = id;
                return (id, "All Good");
            }
            catch (Exception e)
            {
                return (-1, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) DeleteCountry(int id)
        {
            // use transaction and first delete all players related to current country

            if (id == -1)
                return (false, "Id cannot be -1");
            try
            {
                var command = CreateCommand($"delete from {COUNTRY_TABLE_NAME} WHERE ID={id}");
                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (List<Country>, string) GetCountries()
        {
            List<Country> countries = new List<Country>();
            try
            {
                var command = CreateCommand($"select * from {COUNTRY_TABLE_NAME}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Country country = GetCountryFromReader(reader);
                        countries.Add(country);
                    }
                }

                return (countries, "All good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }

            finally
            {
                CloseConnection();
            }
        }

        public (List<Country>, string) SearchCountries(Dictionary<string, string> parameters, bool and = true)
        {
            var conditions = CreateConditionString(parameters, and);
            if (string.IsNullOrEmpty(conditions))
                return GetCountries();

            try
            {
                var countries = new List<Country>();
                var command = CreateCommand($"select * from {COUNTRY_TABLE_NAME} where {conditions}");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var country = GetCountryFromReader(reader);
                        countries.Add(country);
                    }
                }
                return (countries, "All Good");
            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        public (bool, string) UpdateCountry(Country country)
        {
            if (country == null)
                return (false, "Country is null");

            var validate = ValueValidator.ValidateCountry(country);

            if (!validate.Item1)
                return validate;

            try
            {
                string commandString =
                    $"update {COUNTRY_TABLE_NAME} SET " +
                    $"Name = '{country.Name}' " +
                    $"where ID={country.Id};";
                var command = CreateCommand(commandString);

                command.ExecuteNonQuery();
                return (true, "All Good");
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        private Country GetCountryFromReader(SqlDataReader reader)
        {
            Country country = new Country();
            country.Id = (int)reader["Id"];
            country.Name = (string)reader["Name"];
            return country;
        }
    }
}
