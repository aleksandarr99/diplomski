﻿using System.Collections.Generic;
using System.Runtime.InteropServices;
using TournamentModels;

namespace DatabaseCommunication
{
    public interface ITournamentDatabase
    {
        #region Admin
        (Admin, string) Login(string username, string password);

        (List<Admin>, string) GetAdmins();
        (List<Admin>, string) SearchAdmins(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeleteAdmin(int id);
        (bool, string) UpdateAdmin(Admin admin);
        (int, string) CreateAdmin(Admin admin);

        #endregion

        #region Player

        (List<Player>, string) GetPlayers();
        (List<Player>, string) SearchPlayers(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeletePlayer(Player player);
        (bool, string) UpdatePlayer(Player player);
        (bool, string) CreatePlayer(Player player);

        #endregion

        #region Country

        (List<Country>, string) GetCountries();
        (List<Country>, string) SearchCountries(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeleteCountry(int id);
        (bool, string) UpdateCountry(Country country);
        (int, string) CreateCountry(Country country);

        #endregion

        #region Referee
        (List<Referee>, string) GetReferees();
        (List<Referee>, string) SearchReferees(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeleteReferee(int id);
        (bool, string) UpdateReferee(Referee referee);
        (int, string) CreateReferee(Referee referee);
        #endregion

        #region Tournament
        (int, string) CreateTournament(TournamentModels.Tournament tournament);
        (List<TournamentModels.Tournament>, string) GetTournaments();
        (List<TournamentModels.Tournament>, string) SearchTournaments(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeleteTournament(int id);
        (bool, string) UpdateTournament(TournamentModels.Tournament tournament);
        #endregion

        #region Game

        (List<int>, string) CreateGames(List<Game> games);
        (List<Game>, string) GetGames();
        (List<Game>, string) SearchGames(Dictionary<string, string> parameters, bool and = true);
        (bool, string) DeleteGame(int id);
        (bool, string) UpdateGame(Game game);
        (bool, string) UpdateGames(List<Game> games);

        #endregion

        #region Participation
        (int, string) CreateParticipation(int tournamentId, int countryId, int stage);
        (List<KeyValuePair<int, int>>, string) GetTournamentParticipants(int tournamentId);
        (List<KeyValuePair<int, int>>, string) GetCountryParticipations(int countryId);
        (bool, string) DeleteParticipation(int tournamentId, int countryId);
        (bool, string) UpdateParticipation(int tournamentId, int countryId, int stage);

        #endregion

        #region Engagements
        (int, string) CreateEngagement(int tournamentId, int refereeId);
        (List<int>, string) GetTournamentReferees(int tournamentId);
        (List<int>, string) GetRefereeEngagements(int refereeId);
        (bool, string) DeleteEngagement(int tournamentId, int refereeId);
        #endregion

        #region Odds

        (List<Odds>, string) SearchOdds(int homeId = -1, int awayId = -1);
        #endregion
    }
}
