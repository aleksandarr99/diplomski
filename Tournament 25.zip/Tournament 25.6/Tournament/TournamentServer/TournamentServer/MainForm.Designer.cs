﻿
namespace TournamentServer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.requestsLbl = new MetroFramework.Controls.MetroLabel();
            this.receivedMessageLbx = new System.Windows.Forms.ListBox();
            this.selectedItemTbx = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // requestsLbl
            // 
            this.requestsLbl.AutoSize = true;
            this.requestsLbl.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.requestsLbl.Location = new System.Drawing.Point(23, 54);
            this.requestsLbl.Name = "requestsLbl";
            this.requestsLbl.Size = new System.Drawing.Size(79, 25);
            this.requestsLbl.TabIndex = 9;
            this.requestsLbl.Text = "Requests";
            // 
            // receivedMessageLbx
            // 
            this.receivedMessageLbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.receivedMessageLbx.FormattingEnabled = true;
            this.receivedMessageLbx.Location = new System.Drawing.Point(23, 82);
            this.receivedMessageLbx.Name = "receivedMessageLbx";
            this.receivedMessageLbx.Size = new System.Drawing.Size(211, 381);
            this.receivedMessageLbx.TabIndex = 6;
            this.receivedMessageLbx.SelectedValueChanged += new System.EventHandler(this.receivedMessageLbx_SelectedValueChanged);
            // 
            // selectedItemTbx
            // 
            this.selectedItemTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.selectedItemTbx.Location = new System.Drawing.Point(240, 82);
            this.selectedItemTbx.Multiline = true;
            this.selectedItemTbx.Name = "selectedItemTbx";
            this.selectedItemTbx.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.selectedItemTbx.Size = new System.Drawing.Size(474, 381);
            this.selectedItemTbx.TabIndex = 10;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 494);
            this.Controls.Add(this.selectedItemTbx);
            this.Controls.Add(this.requestsLbl);
            this.Controls.Add(this.receivedMessageLbx);
            this.MinimumSize = new System.Drawing.Size(746, 494);
            this.Name = "MainForm";
            this.Text = "Server Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel requestsLbl;
        private System.Windows.Forms.ListBox receivedMessageLbx;
        private System.Windows.Forms.TextBox selectedItemTbx;
    }
}

