﻿using CommunicationModule.Requests;
using CommunicationModule.Server;
using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TournamentServer
{
    public partial class MainForm : MetroForm
    {
        private SocketServer _socket;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _socket = new SocketServer("localhost", 1234);
            _socket.RequestReceived += _simpleServer_RequestReceived;
            _socket.Start();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            _socket.Stop();
        }

        private void _simpleServer_RequestReceived(object sender, CommunicationModule.MessageEventArgs e)
        {
            WriteTextSafe(e.Message);
        }

        private void receivedMessageLbx_SelectedValueChanged(object sender, EventArgs e)
        {
            int selectedIndex = receivedMessageLbx.SelectedIndex;
            if (selectedIndex < 0 || selectedIndex >= _requests.Count)
            {
                selectedItemTbx.Text = string.Empty;
                return;
            }

            selectedItemTbx.Text = _requests[selectedIndex];
        }

        List<string> _requests = new List<string>();

        public void WriteTextSafe(string text)
        {
            var message = "[" + DateTime.Now.ToShortTimeString() + "]";
            var request = Request.GetRequest(text);
            if (request == null)
                message += " invalid request";
            else
                message += " " + request.ToString();



            if (receivedMessageLbx.InvokeRequired)
            {
                MethodInvoker safeWrite = delegate
                {
                    receivedMessageLbx.Items.Add(message);
                    _requests.Add(text);
                };

                receivedMessageLbx.BeginInvoke(safeWrite);
            }
            else
            {
                receivedMessageLbx.Items.Add(message);
                _requests.Add(text);
            }
        }
    }
}
