﻿using CommunicationModule.Requests;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace CommunicationModule
{
    public class SocketClient
    {
        protected IPEndPoint remoteEP;
        protected IPAddress _ipAddress;
        protected Socket _socket;

        public SocketClient(string ipAddress, int port)
        {
            var host = Dns.GetHostEntry(ipAddress);
            if (host.AddressList.Length == 0)
                return;

            if (port > 65535 || port < 0)
                throw new Exception("Port should be less than 65536 and greater than 0");

            _ipAddress = host.AddressList[0];
            remoteEP = new IPEndPoint(_ipAddress, port);
        }

        public bool Connect()
        {
            // Create a TCP/IP  socket.
            _socket = new Socket(_ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Connect the socket to the remote endpoint. Catch any errors.
            try
            {
                // Connect to Remote EndPoint
                _socket.Connect(remoteEP);

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool Disconnect()
        {
            try
            {
                byte[] lastMessage = Encoding.ASCII.GetBytes(MessageEventArgs.EXIT_MESSAGE);
                _socket.Send(lastMessage);

                _socket.Shutdown(SocketShutdown.Both);
                _socket.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine($"Discoonecting exception: {e.Message}");
                return false;
            }
        }

        private string SendMessage(string message)
        {
            if (!_socket.Connected)
                return string.Empty;

            byte[] msg = Encoding.ASCII.GetBytes(message);
            int bytesSend = _socket.Send(msg);

            byte[] response = new byte[1024 * 24];
            int bytesRec = _socket.Receive(response);

            var responseString = Encoding.ASCII.GetString(response, 0, bytesRec);
            return responseString;
        }

        public LoginRequest Login(LoginRequest loginRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(loginRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<LoginRequest>(response);
            return result;
        }

        public SearchRequest<T> Search<T>(SearchRequest<T> searchRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(searchRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<SearchRequest<T>>(response);
            return result;
        }

        public UpdateRequest<T> Update<T>(UpdateRequest<T> updateRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(updateRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<UpdateRequest<T>>(response);
            return result;
        }

        public CreateRequest<T> Create<T>(CreateRequest<T> createRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(createRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<CreateRequest<T>>(response);
            return result;
        }

        public MultiCreateRequest<T> MultiCreate<T>(MultiCreateRequest<T> multiCreateRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(multiCreateRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<MultiCreateRequest<T>>(response);
            return result;
        }

        public MultiUpdateRequest<T> MultiUpdate<T>(MultiUpdateRequest<T> multiUpdateRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(multiUpdateRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<MultiUpdateRequest<T>>(response);
            return result;
        }

        public DeleteRequest Delete(DeleteRequest deleteRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(deleteRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<DeleteRequest>(response);
            return result;
        }

        public PlayerDeleteRequest PlayerDelete(PlayerDeleteRequest deleteRequest)
        {
            var jsonRequest = JsonConvert.SerializeObject(deleteRequest, Formatting.None, new JsonSerializerSettings()
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
            });
            var response = SendMessage(jsonRequest);

            var result = JsonConvert.DeserializeObject<PlayerDeleteRequest>(response);
            return result;
        }

    }
}
