﻿using TournamentModels;

namespace CommunicationModule.Requests
{
    public class UpdateRequest<T> : Request
    {
        public T Value { get; set; }

        public UpdateRequest(T value)
        {
            Value = value;
            RequestType = RequestType.Update;
        }

        public UpdateRequest()
        {
            RequestType = RequestType.Update;
        }
    }

    public class AdminUpdateRequest : UpdateRequest<Admin>
    {
        public AdminUpdateRequest()
        {
            ObjectType = ObjectType.Admin;
        }
    }

    public class CountryUpdateRequest : UpdateRequest<Country>
    {
        public CountryUpdateRequest()
        {
            ObjectType = ObjectType.Country;
        }
    }

    public class GameUpdateRequest : UpdateRequest<Game>
    {
        public GameUpdateRequest()
        {
            ObjectType = ObjectType.Game;
        }
    }

    public class PlayerUpdateRequest : UpdateRequest<Player>
    {
        public PlayerUpdateRequest()
        {
            ObjectType = ObjectType.Player;
        }
    }

    public class RefereeUpdateRequest : UpdateRequest<Referee>
    {
        public RefereeUpdateRequest()
        {
            ObjectType = ObjectType.Referee;
        }
    }

    public class TournamentUpdateRequest : UpdateRequest<Tournament>
    {
        public TournamentUpdateRequest()
        {
            ObjectType = ObjectType.Tournament;
        }
    }
}
