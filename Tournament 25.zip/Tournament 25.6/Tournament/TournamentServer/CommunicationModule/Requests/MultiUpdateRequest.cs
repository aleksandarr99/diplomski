﻿using System.Collections.Generic;
using TournamentModels;

namespace CommunicationModule.Requests
{
    public class MultiUpdateRequest<T> : Request
    {
        public List<T> Values { get; set; }
        public MultiUpdateRequest(List<T> values)
        {
            RequestType = RequestType.MultiUpdate;
            Values = values;
        }

        public MultiUpdateRequest()
        {
            RequestType = RequestType.MultiUpdate;
        }
    }

    public class GameMultiUpdateRequest : MultiUpdateRequest<Game>
    {
        public GameMultiUpdateRequest() : base()
        {
            ObjectType = ObjectType.Game;
        }
    }
}
