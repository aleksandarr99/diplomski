﻿using System.Collections.Generic;
using TournamentModels;

namespace CommunicationModule.Requests
{
    public enum LogicalOperation
    {
        And,
        Or
    }

    public class SearchRequest<T> : Request
    {
        public Dictionary<string, string> Parameters { get; set; }
        public LogicalOperation Operation { get; set; }
        public List<T> Result { get; set; }

        public SearchRequest()
        {
            RequestType = RequestType.Search;
            Parameters = new Dictionary<string, string>();
            Result = new List<T>();
        }

        public SearchRequest(Dictionary<string, string> parameters)
        {
            RequestType = RequestType.Search;
            Parameters = parameters;
            Result = new List<T>();
        }
    }

    public class AdminSearchRequest : SearchRequest<Admin>
    {
        public AdminSearchRequest() : base()
        {
            ObjectType = ObjectType.Admin;
        }

        public AdminSearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Admin;
        }
    }

    public class LoginRequest : Request
    {
        public Admin Admin { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public LoginRequest()
        {
            RequestType = RequestType.Login;
        }
    }

    public class OddsSearchRequest : SearchRequest<Odds>
    {
        public Odds Odds { get; set; }

        public int HomeId { get; set; } = -1;
        public int AwayId { get; set; } = -1;
        public OddsSearchRequest()
        {
            RequestType = RequestType.Search;
            ObjectType = ObjectType.Odds;
        }
    }

    public class CountrySearchRequest : SearchRequest<Country>
    {
        public CountrySearchRequest() : base()
        {
            ObjectType = ObjectType.Country;
        }

        public CountrySearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Country;
        }
    }

    public class GameSearchRequest : SearchRequest<Game>
    {
        public GameSearchRequest() : base()
        {
            ObjectType = ObjectType.Game;
        }

        public GameSearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Game;
        }
    }

    public class PlayerSearchRequest : SearchRequest<Player>
    {
        public PlayerSearchRequest() : base()
        {
            ObjectType = ObjectType.Player;
        }

        public PlayerSearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Player;
        }
    }

    public class RefereeSearchRequest : SearchRequest<Referee>
    {
        public RefereeSearchRequest() : base()
        {
            ObjectType = ObjectType.Referee;
        }

        public RefereeSearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Referee;
        }
    }

    public class TournamentSearchRequest : SearchRequest<Tournament>
    {
        public TournamentSearchRequest() : base()
        {
            ObjectType = ObjectType.Tournament;
        }

        public TournamentSearchRequest(Dictionary<string, string> parameters) : base(parameters)
        {
            ObjectType = ObjectType.Tournament;
        }
    }

}
