﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace CommunicationModule.Requests
{
    public enum RequestType
    {
        Unknown,
        Create,
        MultiCreate,
        Update,
        MultiUpdate,
        Delete,
        Search,
        Login
    }

    public enum ObjectType
    {
        Unknown,
        Player,
        Admin,
        Referee,
        Game,
        Tournament,
        Country,
        Odds
    }

    public class Request
    {
        public RequestType RequestType { get; set; } = RequestType.Unknown;
        public ObjectType ObjectType { get; set; } = ObjectType.Unknown;
        public bool Success { get; set; } = false;
        public string ResultMessage { get; set; } = string.Empty;

        public Request()
        {
        }

        public static (RequestType, ObjectType) GetRequestTypes(string jsonString)
        {
            JObject json = JObject.Parse(jsonString);

            RequestType requestType = RequestType.Unknown;
            ObjectType objectType = ObjectType.Unknown;

            var req = (string)json[nameof(RequestType)];  // nameof(RequestType) <=> "RequestType"
            var obj = (string)json[nameof(ObjectType)];

            if (Enum.TryParse(req, out RequestType type))
                requestType = type;

            if (Enum.TryParse(obj, out ObjectType objType))
                objectType = objType;
            return (requestType, objectType);
        }

        public static Request GetRequest(string jsonString)
        {
            return JsonConvert.DeserializeObject<Request>(jsonString);
        }

        public override string ToString()
        {
            return $"[{RequestType}, {ObjectType}] - {ResultMessage}";
        }

    }
}
