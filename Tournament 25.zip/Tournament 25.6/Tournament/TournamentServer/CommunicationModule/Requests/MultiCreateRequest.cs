﻿using System.Collections.Generic;
using TournamentModels;

namespace CommunicationModule.Requests
{
    public class MultiCreateRequest<T> : Request
    {
        public List<T> Values { get; set; }
        public MultiCreateRequest(List<T> values)
        {
            RequestType = RequestType.MultiCreate;
            Values = values;
        }

        public MultiCreateRequest()
        {
            RequestType = RequestType.MultiCreate;
        }
    }

    public class GameMultiCreateRequest : MultiCreateRequest<Game>
    {
        public GameMultiCreateRequest() : base()
        {
            ObjectType = ObjectType.Game;
        }
    }
}
