﻿using TournamentModels;

namespace CommunicationModule.Requests
{
    public class DeleteRequest : Request
    {
        public int ID { get; set; }

        public DeleteRequest(int id)
        {
            ID = id;
            RequestType = RequestType.Delete;
        }

        public DeleteRequest()
        {
            ID = -1;
            RequestType = RequestType.Delete;
        }
    }

    public class PlayerDeleteRequest : Request
    {
        public Player Player { get; set; }
        public PlayerDeleteRequest(Player player)
        {
            Player= player;
            ObjectType = ObjectType.Player;
            RequestType = RequestType.Delete;
        }

        public PlayerDeleteRequest()
        {
            ObjectType = ObjectType.Player;
            RequestType = RequestType.Delete;
        }

    }
}
