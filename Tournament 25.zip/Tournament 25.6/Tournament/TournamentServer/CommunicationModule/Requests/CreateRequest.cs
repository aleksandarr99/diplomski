﻿using System.Collections.Generic;
using TournamentModels;

namespace CommunicationModule.Requests
{
    public class CreateRequest<T> : Request
    {
        public T Value { get; set; }
        public CreateRequest(T value)
        {
            RequestType = RequestType.Create;
            Value = value;
        }

        public CreateRequest()
        {
            RequestType = RequestType.Create;
        }
    }

    public class AdminCreateRequest : CreateRequest<Admin>
    {
        public AdminCreateRequest() : base()
        {
            ObjectType = ObjectType.Admin;
        }
    }

    public class CountryCreateRequest : CreateRequest<Country>
    {
        public CountryCreateRequest()
        {
            ObjectType = ObjectType.Country;
        }
    }

    public class GameCreateRequest : CreateRequest<Game>
    {
        public GameCreateRequest()
        {
            ObjectType = ObjectType.Game;
        }
    }

    public class PlayerCreateRequest : CreateRequest<Player>
    {
        public PlayerCreateRequest()
        {
            ObjectType = ObjectType.Player;
        }
    }

    public class RefereeCreateRequest: CreateRequest<Referee>
    {
        public RefereeCreateRequest()
        {
            ObjectType = ObjectType.Referee;
        }
    }

    public class TournamentCreateRequest : CreateRequest<Tournament>
    {
        public TournamentCreateRequest()
        {
            ObjectType = ObjectType.Tournament;
        }
    }
}
