﻿using System;

namespace CommunicationModule
{
    public delegate void MessageEventHandler(object sender, MessageEventArgs e);
    public delegate void DisconnectEventHandler(object sender, MessageEventArgs e);

    public class MessageEventArgs : EventArgs
    {
        public string Message { get; private set; }

        public MessageEventArgs(string message)
        {
            Message = message;
        }

        public static string EXIT_MESSAGE = "<<EOF>>";
    }

}
