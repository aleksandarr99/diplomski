﻿using CommunicationModule.Requests;
using DatabaseCommunication;
using DatabaseCommunication.Tournament;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using TournamentModels;

namespace CommunicationModule.Server
{
    public class SocketServer
    {
        private ITournamentDatabase database = new TournamentDatabase();

        public event MessageEventHandler RequestReceived;
        public event DisconnectEventHandler Disconnected;

        private int         _port;
        private IPAddress   _ipAddress;
        private TcpListener _serverSocket;

        public SocketServer(string ipAdr, int port)
        {
            var host = Dns.GetHostEntry(ipAdr);
            if (host.AddressList.Length == 0)
                return;

            if (port > 65535 || port < 0)
                throw new Exception("Port should be less than 65536 and greater than 0");

            _port = port;
            _ipAddress = host.AddressList[0];
        }

        public void Start()
        {
            Thread thread = new Thread(Run);
            thread.Start();
        }

        public void Stop()
        {
            _serverSocket.Stop();
        }

        public void Run()
        {
            _serverSocket = new TcpListener(_ipAddress, _port);
            _serverSocket.Start();
            try
            {
                while (true)
                {
                    var socket = _serverSocket.AcceptTcpClient();
                    var stream = socket.GetStream();
                    var request = ReadAndExecute(stream);

                    var requestString = JsonConvert.SerializeObject(request, Formatting.Indented);
                    Send(stream, requestString);

                    RequestReceived?.Invoke(this, new MessageEventArgs(requestString));
                }
            }
            catch (Exception exc)
            {
                Disconnected?.Invoke(this, new MessageEventArgs(exc.Message));
            }
        }

        private Request ReadAndExecute(NetworkStream stream)
        {
            byte[] buffer = new byte[1024 * 24];

            int receivedBytes = stream.Read(buffer, 0, buffer.Length);
            if (receivedBytes < 1)
                return null;

            string message = Encoding.UTF8.GetString(buffer, 0, receivedBytes);

            if (message == MessageEventArgs.EXIT_MESSAGE)
                return null;

            return HandleJson(message);
        }

        public void Send(NetworkStream stream, string message)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(message);
            stream.Write(buffer, 0, buffer.Length);
        }

        private Request HandleJson(string json)
        {
            (RequestType requestType, ObjectType objectType) = Request.GetRequestTypes(json);

            if (requestType == RequestType.Login)
            {
                var loginRequest = JsonConvert.DeserializeObject<LoginRequest>(json);
                Admin admin;
                string message;
                (admin, message) = database.Login(loginRequest.Username, loginRequest.Password);

                loginRequest.ResultMessage = message;
                loginRequest.Success = admin != null;
                loginRequest.Admin = admin;
                return loginRequest;

            }

            if (requestType == RequestType.Unknown || objectType == ObjectType.Unknown)
                return null;


            if (objectType == ObjectType.Player)
            {
                return HandlePlayerRequest(json, requestType);
            }
            else if (objectType == ObjectType.Admin)
            {
                return HandleAdminRequest(json, requestType);
            }
            else if (objectType == ObjectType.Country)
            {
                return HandleCountryRequest(json, requestType);
            }
            else if (objectType == ObjectType.Referee)
            {
                return HandleRefereeRequest(json, requestType);
            }
            else if (objectType == ObjectType.Tournament)
            {
                return HandleTournamentRequest(json, requestType);
            }
            else if (objectType == ObjectType.Game)
            {
                return HandleGameRequest(json, requestType);
            }
            else if (objectType == ObjectType.Odds)
            {
                return HandleOddsRequest(json, requestType);
            }
            return null;
        }

        private Request HandlePlayerRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                PlayerCreateRequest playerRequest = JsonConvert.DeserializeObject<PlayerCreateRequest>(json);
                bool success;
                string message;
                (success, message) = database.CreatePlayer(playerRequest.Value);

                playerRequest.ResultMessage = message;
                playerRequest.Success = success;
                return playerRequest;

            }
            else if (requestType == RequestType.Update)
            {
                PlayerUpdateRequest playerRequest = JsonConvert.DeserializeObject<PlayerUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdatePlayer(playerRequest.Value);

                playerRequest.ResultMessage = message;
                playerRequest.Success = success;
                return playerRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                PlayerDeleteRequest playerRequest = JsonConvert.DeserializeObject<PlayerDeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeletePlayer(playerRequest.Player);

                playerRequest.ResultMessage = message;
                playerRequest.Success = success;
                return playerRequest;

            }
            else if (requestType == RequestType.Search)
            {
                PlayerSearchRequest playerRequest = JsonConvert.DeserializeObject<PlayerSearchRequest>(json);
                bool andOperation = playerRequest.Operation == LogicalOperation.And;

                List<Player> results;
                string message;
                (results, message) = database.SearchPlayers(playerRequest.Parameters, andOperation);

                playerRequest.ResultMessage = message;
                playerRequest.Success = results != null;
                playerRequest.Result = results;
                return playerRequest;
            }
            return null;
        }

        private Request HandleAdminRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                AdminCreateRequest adminRequest = JsonConvert.DeserializeObject<AdminCreateRequest>(json);
                int id;
                string message;
                (id, message) = database.CreateAdmin(adminRequest.Value);

                adminRequest.ResultMessage = message;
                adminRequest.Success = id != -1;
                adminRequest.Value.Id = id;
                return adminRequest;

            }
            else if (requestType == RequestType.Update)
            {
                AdminUpdateRequest adminRequest = JsonConvert.DeserializeObject<AdminUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdateAdmin(adminRequest.Value);

                adminRequest.ResultMessage = message;
                adminRequest.Success = success;
                return adminRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                DeleteRequest adminRequest = JsonConvert.DeserializeObject<DeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeleteAdmin(adminRequest.ID);

                adminRequest.ResultMessage = message;
                adminRequest.Success = success;
                return adminRequest;

            }
            else if (requestType == RequestType.Search)
            {
                AdminSearchRequest adminRequest = JsonConvert.DeserializeObject<AdminSearchRequest>(json);
                bool andOperation = adminRequest.Operation == LogicalOperation.And;

                List<Admin> results;
                string message;
                (results, message) = database.SearchAdmins(adminRequest.Parameters, andOperation);

                adminRequest.ResultMessage = message;
                adminRequest.Success = results != null;
                adminRequest.Result = results;
                return adminRequest;
            }
            return null;
        }

        private Request HandleCountryRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                CountryCreateRequest contryRequest = JsonConvert.DeserializeObject<CountryCreateRequest>(json);
                int id;
                string message;
                (id, message) = database.CreateCountry(contryRequest.Value);

                contryRequest.ResultMessage = message;
                contryRequest.Success = id != -1;
                contryRequest.Value.Id = id;
                return contryRequest;

            }
            else if (requestType == RequestType.Update)
            {
                CountryUpdateRequest contryRequest = JsonConvert.DeserializeObject<CountryUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdateCountry(contryRequest.Value);

                contryRequest.ResultMessage = message;
                contryRequest.Success = success;
                return contryRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                DeleteRequest deleteRequest = JsonConvert.DeserializeObject<DeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeleteCountry(deleteRequest.ID);

                deleteRequest.ResultMessage = message;
                deleteRequest.Success = success;
                return deleteRequest;

            }
            else if (requestType == RequestType.Search)
            {
                CountrySearchRequest countryRequest = JsonConvert.DeserializeObject<CountrySearchRequest>(json);
                bool andOperation = countryRequest.Operation == LogicalOperation.And;

                List<Country> results;
                string message;
                (results, message) = database.SearchCountries(countryRequest.Parameters, andOperation);

                countryRequest.ResultMessage = message;
                countryRequest.Success = results != null;
                countryRequest.Result = results;
                return countryRequest;
            }
            return null;
        }

        private Request HandleRefereeRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                RefereeCreateRequest refereeRequest = JsonConvert.DeserializeObject<RefereeCreateRequest>(json);
                int id;
                string message;
                (id, message) = database.CreateReferee(refereeRequest.Value);

                refereeRequest.ResultMessage = message;
                refereeRequest.Success = id != -1;
                refereeRequest.Value.Id = id;
                return refereeRequest;

            }
            else if (requestType == RequestType.Update)
            {
                RefereeUpdateRequest refereeRequest = JsonConvert.DeserializeObject<RefereeUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdateReferee(refereeRequest.Value);

                refereeRequest.ResultMessage = message;
                refereeRequest.Success = success;
                return refereeRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                DeleteRequest deleteRequest = JsonConvert.DeserializeObject<DeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeleteReferee(deleteRequest.ID);

                deleteRequest.ResultMessage = message;
                deleteRequest.Success = success;
                return deleteRequest;

            }
            else if (requestType == RequestType.Search)
            {
                RefereeSearchRequest refereeRequest = JsonConvert.DeserializeObject<RefereeSearchRequest>(json);
                bool andOperation = refereeRequest.Operation == LogicalOperation.And;

                List<Referee> results;
                string message;
                (results, message) = database.SearchReferees(refereeRequest.Parameters, andOperation);

                refereeRequest.ResultMessage = message;
                refereeRequest.Success = results != null;
                refereeRequest.Result = results;
                return refereeRequest;
            }
            return null;
        }

        private Request HandleTournamentRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                TournamentCreateRequest tournamentRequest = JsonConvert.DeserializeObject<TournamentCreateRequest>(json);
                int id;
                string message;
                (id, message) = database.CreateTournament(tournamentRequest.Value);

                tournamentRequest.ResultMessage = message;
                tournamentRequest.Success = id != -1;
                tournamentRequest.Value.Id = id;
                return tournamentRequest;

            }
            else if (requestType == RequestType.Update)
            {
                TournamentUpdateRequest tournamentRequest = JsonConvert.DeserializeObject<TournamentUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdateTournament(tournamentRequest.Value);

                tournamentRequest.ResultMessage = message;
                tournamentRequest.Success = success;
                return tournamentRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                DeleteRequest deleteRequest = JsonConvert.DeserializeObject<DeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeleteTournament(deleteRequest.ID);

                deleteRequest.ResultMessage = message;
                deleteRequest.Success = success;
                return deleteRequest;

            }
            else if (requestType == RequestType.Search)
            {
                TournamentSearchRequest tournamentRequest = JsonConvert.DeserializeObject<TournamentSearchRequest>(json);
                bool andOperation = tournamentRequest.Operation == LogicalOperation.And;

                List<Tournament> results;
                string message;
                (results, message) = database.SearchTournaments(tournamentRequest.Parameters, andOperation);

                tournamentRequest.ResultMessage = message;
                tournamentRequest.Success = results != null;
                tournamentRequest.Result = results;
                return tournamentRequest;
            }
            return null;
        }

        private Request HandleGameRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Create)
            {
                GameCreateRequest gameRequest = JsonConvert.DeserializeObject<GameCreateRequest>(json);
                List<int> ids;
                string message;

                (ids, message) = database.CreateGames(new List<Game>() { gameRequest.Value });

                gameRequest.ResultMessage = message;
                gameRequest.Success = ids != null && ids.Count == 1;
                //if (gameRequest.Success)
                //    gameRequest.Value.Id = ids[0];
                return gameRequest;
            }

            else if (requestType == RequestType.MultiCreate)
            {
                GameMultiCreateRequest gameRequest = JsonConvert.DeserializeObject<GameMultiCreateRequest>(json);
                List<int> ids;
                string message;

                (ids, message) = database.CreateGames(gameRequest.Values);

                gameRequest.ResultMessage = message;
                gameRequest.Success = ids != null && ids.Count == gameRequest.Values.Count;
                return gameRequest;
            }

            else if (requestType == RequestType.MultiUpdate)
            {
                GameMultiUpdateRequest gameRequest = JsonConvert.DeserializeObject<GameMultiUpdateRequest>(json);
                bool result;
                string message;

                (result, message) = database.UpdateGames(gameRequest.Values);

                gameRequest.ResultMessage = message;
                gameRequest.Success = result;
                return gameRequest;
            }

            else if (requestType == RequestType.Update)
            {
                GameUpdateRequest gameRequest = JsonConvert.DeserializeObject<GameUpdateRequest>(json);

                bool success;
                string message;
                (success, message) = database.UpdateGame(gameRequest.Value);

                gameRequest.ResultMessage = message;
                gameRequest.Success = success;
                return gameRequest;

            }
            else if (requestType == RequestType.Delete)
            {
                DeleteRequest deleteRequest = JsonConvert.DeserializeObject<DeleteRequest>(json);

                bool success;
                string message;
                (success, message) = database.DeleteTournament(deleteRequest.ID);

                deleteRequest.ResultMessage = message;
                deleteRequest.Success = success;
                return deleteRequest;

            }
            else if (requestType == RequestType.Search)
            {
                GameSearchRequest gameRequest = JsonConvert.DeserializeObject<GameSearchRequest>(json);
                bool andOperation = gameRequest.Operation == LogicalOperation.And;

                List<Game> results;
                string message;
                (results, message) = database.SearchGames(gameRequest.Parameters, andOperation);

                gameRequest.ResultMessage = message;
                gameRequest.Success = results != null;
                gameRequest.Result = results;
                return gameRequest;
            }
            return null;
        }

        private Request HandleOddsRequest(string json, RequestType requestType)
        {
            if (requestType == RequestType.Search)
            {
                OddsSearchRequest oddsRequest = JsonConvert.DeserializeObject<OddsSearchRequest>(json);

                List<Odds> results;
                string message;
                (results, message) = database.SearchOdds(oddsRequest.HomeId, oddsRequest.AwayId);

                oddsRequest.ResultMessage = message;
                oddsRequest.Success = results != null;
                oddsRequest.Result = results;
                return oddsRequest;
            }
            return null;
        }
    }
}
