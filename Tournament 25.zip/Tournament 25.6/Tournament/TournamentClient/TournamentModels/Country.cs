﻿using System;
using System.Collections.Generic;

namespace TournamentModels
{
    public class Country : IComparable
    {
        public List<Player> Players { get; set; }

        public string Name { get; set; }
        public int Id { get; set; }

        public Country()
        {
            Players = new List<Player>();
        }

        public override string ToString()
        {
            return Name;
        }

        public int CompareTo(object obj)
        {
            if (obj is Country country)
                return Name.CompareTo(country.Name);
            return -1;
        }
    }
}
