﻿namespace TournamentModels
{
    public class Referee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Experience { get; set; }

        public override string ToString()
        {
            return $"{Name} {Surname}";
        }
    }
}
