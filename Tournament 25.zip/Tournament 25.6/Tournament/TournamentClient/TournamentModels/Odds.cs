﻿namespace TournamentModels
{
    public class Odds
    {
        public int Id{ get; set; }
        public int HomeId { get; set; }
        public int AwayId { get; set; }
        public double HomeWinOdds { get; set; }
        public double AwayWinOdds { get; set; }
        public double DrawOdds { get; set; }
    }
}
