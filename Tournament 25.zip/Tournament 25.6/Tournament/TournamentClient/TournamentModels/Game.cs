﻿namespace TournamentModels
{
    public class Game
    {
        public int Id { get; set; }

        public int TournamentID { get; set; }
        public Tournament Tournament { get; set; }

        public int FirstTeamID { get; set; }
        public Country FirstTeam { get; set; }
        public int FirstTeamScore { get; set; } = -1;

        public int SecondTeamScore { get; set; } = -1;
        public int SecondTeamID { get; set; }
        public Country SecondTeam { get; set; }

        public int RefereeID { get; set; }
        public Referee Referee { get; set; }

        public int Stage { get; set; }

        public Country Winner
        {
            get
            {
                if (FirstTeam == null || SecondTeam == null)
                    return null;

                return FirstTeamScore > SecondTeamScore ? FirstTeam : SecondTeam;
            }
        }

        public Odds Odds { get; set; }
    }
}
