﻿namespace TournamentModels
{
    public class Player
    {
        public int Number { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }

        public int CountryID { get; set; }
        public Country Country { get; set; }

        public override string ToString()
        {
            return $"{Number} {Name} {Surname} ";
        }
    }
}
