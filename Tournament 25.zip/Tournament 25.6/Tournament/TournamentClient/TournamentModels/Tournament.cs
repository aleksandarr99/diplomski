﻿using System;
using System.Collections.Generic;

namespace TournamentModels
{
    public enum TournamentCapacity
    {
        Four = 4,
        Eight = 8,
        Sixteen = 16,
        ThirtyTwo = 32
    }

    public class Tournament
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string City { get; set; }
        public string Description { get; set; }
        public Admin Admin { get; set; }
        public int AdminID { get; set; }
        public TournamentCapacity Capacity { get; set; }

        public List<Referee> Referees { get; set; } = new List<Referee>();
        public List<Country> Countries { get; set; } = new List<Country>();
        public List<Game> Games { get; set; } = new List<Game>();

        public List<int> RefereeIds { get; set; } = new List<int>();
        public List<int> CountryIds { get; set; } = new List<int>();

        public string WinnerName { get; set; } = "Unknown";
    }
}
