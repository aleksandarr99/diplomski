﻿using System.Drawing;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Controls
{
    public delegate void ResultChanged(GameControl sender);

    public partial class GameControl : UserControl
    {
        public event ResultChanged ResultChanged;

        public static int ControlWidth = 330;
        public static int ControlHeight = 156;

        private static readonly string colorTie = "#fcfde2";
        private static readonly string colorWin = "#d8fcd2";
        private static readonly string colorDefeat = "#fcd2d2";
        public Game Game { get; set; }

        public int FirstScore { get; set; }
        public int SecondScore { get; set; }
        public bool Valid => FirstScore >= 0 && SecondScore >= 0 && FirstScore != SecondScore;

        public GameControl(Game game)
        {
            Game = game;

            InitializeComponent();
            AppController.Instance.FillGame(game);

            team1lbl.Text = game.FirstTeam.Name;
            team2lbl.Text = game.SecondTeam.Name;
            team1ScoreTbx.Enabled = team2ScoreTbx.Enabled = game.FirstTeamScore < 0 || game.SecondTeamScore < 0;

            team1ScoreTbx.Text = game.FirstTeamScore == -1 ? "" : game.FirstTeamScore.ToString();
            team2ScoreTbx.Text = game.SecondTeamScore == -1 ? "" : game.SecondTeamScore.ToString();

            if (game.Odds == null)
            {
                homeOddsLbl.Text = awayOddsLbl.Text = drawOddsLbl.Text = string.Empty;
            }
            else
            {
                homeOddsLbl.Text = game.Odds.HomeWinOdds.ToString();
                awayOddsLbl.Text = game.Odds.AwayWinOdds.ToString();
                drawOddsLbl.Text = game.Odds.DrawOdds.ToString();
            }

            refereeLbl.Text = $"Referee: { game.Referee.Name + " " +game.Referee.Surname }";
        }

        private void table_CellPaint(object sender, TableLayoutCellPaintEventArgs e)
        {
            var winnerColor = ColorTranslator.FromHtml(colorWin);
            var loserColor = ColorTranslator.FromHtml(colorDefeat);
            var tieColor = ColorTranslator.FromHtml(colorTie);

            int winnerIndex = Game.FirstTeamScore > Game.SecondTeamScore ? 0 : 1;

            if (Game.FirstTeamScore == Game.SecondTeamScore)
                e.Graphics.FillRectangle(new SolidBrush(tieColor), e.CellBounds);
            else if (e.Row == winnerIndex)
                e.Graphics.FillRectangle(new SolidBrush(winnerColor), e.CellBounds);
            //else
            //    e.Graphics.FillRectangle(new SolidBrush(loserColor), e.CellBounds);
        }

        private void maskedTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void team1ScoreTbx_TextChanged(object sender, System.EventArgs e)
        {
            if (!int.TryParse(team1ScoreTbx.Text, out int firstScore))
                firstScore = -1;
            if (!int.TryParse(team2ScoreTbx.Text, out int secondScore))
                secondScore = -1;

            FirstScore = firstScore;
            SecondScore = secondScore;
            ResultChanged?.Invoke(this);
        }
    }
}
