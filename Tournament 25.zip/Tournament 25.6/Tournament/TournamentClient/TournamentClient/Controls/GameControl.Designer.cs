﻿
namespace FootballTournament.Controls
{
    partial class GameControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.table = new System.Windows.Forms.TableLayoutPanel();
            this.team1lbl = new System.Windows.Forms.Label();
            this.team2lbl = new System.Windows.Forms.Label();
            this.team1ScoreTbx = new System.Windows.Forms.TextBox();
            this.team2ScoreTbx = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.refereeLbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.oddsLbl = new System.Windows.Forms.Label();
            this.awayOddsLbl = new System.Windows.Forms.Label();
            this.AwayPnl = new System.Windows.Forms.Panel();
            this.drawPnl = new System.Windows.Forms.Panel();
            this.labelX = new System.Windows.Forms.Label();
            this.homePnl = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.homeOddsLbl = new System.Windows.Forms.Label();
            this.drawOddsLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.table.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.AwayPnl.SuspendLayout();
            this.drawPnl.SuspendLayout();
            this.homePnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // table
            // 
            this.table.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.table.ColumnCount = 2;
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.table.Controls.Add(this.team1lbl, 0, 0);
            this.table.Controls.Add(this.team2lbl, 0, 1);
            this.table.Controls.Add(this.team1ScoreTbx, 1, 0);
            this.table.Controls.Add(this.team2ScoreTbx, 1, 1);
            this.table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.table.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table.Location = new System.Drawing.Point(3, 32);
            this.table.Name = "table";
            this.table.RowCount = 2;
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.Size = new System.Drawing.Size(324, 85);
            this.table.TabIndex = 0;
            this.table.CellPaint += new System.Windows.Forms.TableLayoutCellPaintEventHandler(this.table_CellPaint);
            // 
            // team1lbl
            // 
            this.team1lbl.AutoSize = true;
            this.team1lbl.BackColor = System.Drawing.Color.Transparent;
            this.team1lbl.Dock = System.Windows.Forms.DockStyle.Left;
            this.team1lbl.Location = new System.Drawing.Point(6, 3);
            this.team1lbl.Name = "team1lbl";
            this.team1lbl.Size = new System.Drawing.Size(56, 38);
            this.team1lbl.TabIndex = 0;
            this.team1lbl.Text = "Serbia";
            this.team1lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // team2lbl
            // 
            this.team2lbl.AutoSize = true;
            this.team2lbl.BackColor = System.Drawing.Color.Transparent;
            this.team2lbl.Dock = System.Windows.Forms.DockStyle.Left;
            this.team2lbl.Location = new System.Drawing.Point(6, 44);
            this.team2lbl.Name = "team2lbl";
            this.team2lbl.Size = new System.Drawing.Size(76, 38);
            this.team2lbl.TabIndex = 1;
            this.team2lbl.Text = "Germany";
            this.team2lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // team1ScoreTbx
            // 
            this.team1ScoreTbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.team1ScoreTbx.Location = new System.Drawing.Point(261, 13);
            this.team1ScoreTbx.Margin = new System.Windows.Forms.Padding(5, 10, 5, 0);
            this.team1ScoreTbx.Name = "team1ScoreTbx";
            this.team1ScoreTbx.Size = new System.Drawing.Size(55, 24);
            this.team1ScoreTbx.TabIndex = 2;
            this.team1ScoreTbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.team1ScoreTbx.TextChanged += new System.EventHandler(this.team1ScoreTbx_TextChanged);
            this.team1ScoreTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.maskedTextBox1_KeyPress);
            // 
            // team2ScoreTbx
            // 
            this.team2ScoreTbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.team2ScoreTbx.Location = new System.Drawing.Point(261, 54);
            this.team2ScoreTbx.Margin = new System.Windows.Forms.Padding(5, 10, 5, 0);
            this.team2ScoreTbx.Name = "team2ScoreTbx";
            this.team2ScoreTbx.Size = new System.Drawing.Size(55, 24);
            this.team2ScoreTbx.TabIndex = 3;
            this.team2ScoreTbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.team2ScoreTbx.TextChanged += new System.EventHandler(this.team1ScoreTbx_TextChanged);
            this.team2ScoreTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.maskedTextBox1_KeyPress);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.table, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.refereeLbl, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(330, 140);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // refereeLbl
            // 
            this.refereeLbl.AutoSize = true;
            this.refereeLbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.refereeLbl.Location = new System.Drawing.Point(3, 120);
            this.refereeLbl.Name = "refereeLbl";
            this.refereeLbl.Size = new System.Drawing.Size(324, 20);
            this.refereeLbl.TabIndex = 1;
            this.refereeLbl.Text = "Referee: Miroslav Mazic";
            this.refereeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel2.Controls.Add(this.homePnl, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.drawPnl, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.oddsLbl, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.AwayPnl, 3, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(324, 23);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // oddsLbl
            // 
            this.oddsLbl.AutoSize = true;
            this.oddsLbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oddsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oddsLbl.ForeColor = System.Drawing.Color.DimGray;
            this.oddsLbl.Location = new System.Drawing.Point(3, 0);
            this.oddsLbl.Name = "oddsLbl";
            this.oddsLbl.Size = new System.Drawing.Size(44, 23);
            this.oddsLbl.TabIndex = 0;
            this.oddsLbl.Text = "Odds:";
            this.oddsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // awayOddsLbl
            // 
            this.awayOddsLbl.AutoSize = true;
            this.awayOddsLbl.Dock = System.Windows.Forms.DockStyle.Right;
            this.awayOddsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.awayOddsLbl.ForeColor = System.Drawing.Color.DimGray;
            this.awayOddsLbl.Location = new System.Drawing.Point(54, 0);
            this.awayOddsLbl.Name = "awayOddsLbl";
            this.awayOddsLbl.Size = new System.Drawing.Size(31, 15);
            this.awayOddsLbl.TabIndex = 1;
            this.awayOddsLbl.Text = "1.65";
            this.awayOddsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AwayPnl
            // 
            this.AwayPnl.Controls.Add(this.label2);
            this.AwayPnl.Controls.Add(this.awayOddsLbl);
            this.AwayPnl.Location = new System.Drawing.Point(236, 3);
            this.AwayPnl.Name = "AwayPnl";
            this.AwayPnl.Size = new System.Drawing.Size(85, 17);
            this.AwayPnl.TabIndex = 4;
            // 
            // drawPnl
            // 
            this.drawPnl.Controls.Add(this.drawOddsLbl);
            this.drawPnl.Controls.Add(this.labelX);
            this.drawPnl.Location = new System.Drawing.Point(143, 3);
            this.drawPnl.Name = "drawPnl";
            this.drawPnl.Size = new System.Drawing.Size(85, 17);
            this.drawPnl.TabIndex = 5;
            // 
            // labelX
            // 
            this.labelX.AutoSize = true;
            this.labelX.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelX.ForeColor = System.Drawing.Color.DimGray;
            this.labelX.Location = new System.Drawing.Point(0, 0);
            this.labelX.Name = "labelX";
            this.labelX.Size = new System.Drawing.Size(29, 15);
            this.labelX.TabIndex = 1;
            this.labelX.Text = "X - ";
            this.labelX.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // homePnl
            // 
            this.homePnl.Controls.Add(this.homeOddsLbl);
            this.homePnl.Controls.Add(this.label1);
            this.homePnl.Location = new System.Drawing.Point(53, 3);
            this.homePnl.Name = "homePnl";
            this.homePnl.Size = new System.Drawing.Size(84, 17);
            this.homePnl.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "1 - ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // homeOddsLbl
            // 
            this.homeOddsLbl.AutoSize = true;
            this.homeOddsLbl.Dock = System.Windows.Forms.DockStyle.Left;
            this.homeOddsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeOddsLbl.ForeColor = System.Drawing.Color.DimGray;
            this.homeOddsLbl.Location = new System.Drawing.Point(28, 0);
            this.homeOddsLbl.Name = "homeOddsLbl";
            this.homeOddsLbl.Size = new System.Drawing.Size(31, 15);
            this.homeOddsLbl.TabIndex = 2;
            this.homeOddsLbl.Text = "14.5";
            this.homeOddsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // drawOddsLbl
            // 
            this.drawOddsLbl.AutoSize = true;
            this.drawOddsLbl.Dock = System.Windows.Forms.DockStyle.Left;
            this.drawOddsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drawOddsLbl.ForeColor = System.Drawing.Color.DimGray;
            this.drawOddsLbl.Location = new System.Drawing.Point(29, 0);
            this.drawOddsLbl.Name = "drawOddsLbl";
            this.drawOddsLbl.Size = new System.Drawing.Size(31, 15);
            this.drawOddsLbl.TabIndex = 2;
            this.drawOddsLbl.Text = "8.75";
            this.drawOddsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(26, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "2 - ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GameControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximumSize = new System.Drawing.Size(330, 140);
            this.MinimumSize = new System.Drawing.Size(330, 140);
            this.Name = "GameControl";
            this.Size = new System.Drawing.Size(330, 140);
            this.table.ResumeLayout(false);
            this.table.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.AwayPnl.ResumeLayout(false);
            this.AwayPnl.PerformLayout();
            this.drawPnl.ResumeLayout(false);
            this.drawPnl.PerformLayout();
            this.homePnl.ResumeLayout(false);
            this.homePnl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel table;
        private System.Windows.Forms.Label team1lbl;
        private System.Windows.Forms.Label team2lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label refereeLbl;
        private System.Windows.Forms.TextBox team1ScoreTbx;
        private System.Windows.Forms.MaskedTextBox team2ScoreTbx;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label awayOddsLbl;
        private System.Windows.Forms.Label oddsLbl;
        private System.Windows.Forms.Panel AwayPnl;
        private System.Windows.Forms.Panel homePnl;
        private System.Windows.Forms.Label homeOddsLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel drawPnl;
        private System.Windows.Forms.Label drawOddsLbl;
        private System.Windows.Forms.Label labelX;
        private System.Windows.Forms.Label label2;
    }
}
