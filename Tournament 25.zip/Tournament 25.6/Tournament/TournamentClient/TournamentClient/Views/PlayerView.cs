﻿using FootballTournament.Forms;
using FootballTournament.HelperClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Views
{
    public partial class PlayerView : UserControl
    {
        private Player _selectedPlayer;
        Action _action;
        public Action Action
        {
            get => _action;
            set
            {
                _action = value;
                if (value == Action.Create)
                    ClearValues();

                applyBtn.Text = value.ToString();
                createCbx.Checked = value == Action.Create;
                countryCbx.Enabled = value == Action.Create;
                numberTbx.Enabled = value == Action.Create;
            }

        }

        private BindingList<Player> _players;
        public BindingList<Player> Players
        {
            set
            {
                _players = value;

                if (value == null)
                    return;

                InitializeComboBox();
                playersGrid.DataSource = value;
                playersGrid.Columns[nameof(Player.CountryID)].Visible = false;
                playersGrid.Columns[nameof(Player.Country)].SortMode = DataGridViewColumnSortMode.Automatic;
                playersGrid.Columns[nameof(Player.Surname)].SortMode = DataGridViewColumnSortMode.Automatic;
                playersGrid.Columns[nameof(Player.Name)].SortMode = DataGridViewColumnSortMode.Automatic;
                playersGrid.Columns[nameof(Player.Number)].SortMode = DataGridViewColumnSortMode.Automatic;
            }
            get
            {
                return _players;
            }
        }

        public PlayerView()
        {
            InitializeComponent();
            InitializeComboBox();

            Action = Action.Create;
        }

        private void InitializeComboBox()
        {
            countryCbx.Items.Clear();
            if (AppController.Instance.Countries == null)
                return;
            foreach (var x in AppController.Instance.Countries)
            {
                countryCbx.Items.Add(x);
            }
        }

        private void playersGrid_SelectionChanged(object sender, EventArgs e)
        {
            _selectedPlayer = null;
            deleteBtn.Enabled = playersGrid.SelectedRows.Count != 0;

            if (playersGrid.SelectedRows.Count == 0)
            {
                nameTbx.Text = string.Empty;
                surnameTbx.Text = string.Empty;
                numberTbx.Text = string.Empty;
                Action = Action.Create;
                return;
            }

            if (!(playersGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Player player))
                return;

            _selectedPlayer = player;

            nameTbx.Text = player.Name;
            surnameTbx.Text = player.Surname;
            numberTbx.Text = player.Number.ToString();
            List<Country> countries = new List<Country>(AppController.Instance.Countries);
            int index = countries.FindIndex(x => x.Id == player.CountryID);
            countryCbx.SelectedIndex = index;

            Action = Action.Update;
        }

        private bool UpdatePlayer()
        {
            if (!int.TryParse(numberTbx.Text, out int number))
            {
                MessageBox.Show("Number must be number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var country = (Country)countryCbx.SelectedItem;
            var tmp = new Player()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Country = country,
                CountryID = country.Id,
                Number = number
            };

            var result = AppController.Instance.UpdatePlayer(tmp);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully updated player" : result.Item2;
            string title = result.Item1 ? "Player update successful" : "Player update failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool CreateNewPlayer()
        {
            if (!int.TryParse(numberTbx.Text, out int number))
            {
                MessageBox.Show("Number must be number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            };

            var country = (Country)countryCbx.SelectedItem;

            if (country == null)
            {
                MessageBox.Show("Please select a country", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }



            var player = new Player()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Number = number,
                CountryID = country.Id,
                Country = country
            };

            var result = AppController.Instance.CreateNewPlayer(player);

            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully created a new player" : result.Item2;
            string title = result.Item1 ? "Player creation successful" : "Player creation failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private void ClearValues()
        {
            playersGrid.ClearSelection();
            nameTbx.Text = string.Empty;
            surnameTbx.Text = string.Empty;
            numberTbx.Text = string.Empty;
        }

        private void applyBtn_Click(object sender, System.EventArgs e)
        {
            bool success = true;
            if (Action == Action.Update)
                success = UpdatePlayer();
            else if (Action == Action.Create)
                success = CreateNewPlayer();


            if (!success)
                return;
            ClearValues();
        }

        private void playersGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Player>(playersGrid, e.ColumnIndex, Players);
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            playersGrid.ClearSelection();
            ClearValues();
        }

        private void createBtn_Click(object sender, EventArgs e)
        {
            Action = Action.Create;
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string playerName = $"{_selectedPlayer.Name} {_selectedPlayer.Surname }";
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {playerName}?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            (success, message) = AppController.Instance.DeletePlayer(_selectedPlayer);
            if (success)
                MessageBox.Show($"{playerName} successfully deleted!");
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void createCbx_CheckedChanged(object sender, EventArgs e)
        {
            Action = createCbx.Checked ? Action.Create : Action.Update;
        }
    }
}
