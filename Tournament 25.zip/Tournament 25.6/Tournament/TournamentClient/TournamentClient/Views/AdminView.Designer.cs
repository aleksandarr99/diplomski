﻿
namespace FootballTournament.Views
{
    partial class AdminView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.applyBtn = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearBtn = new MetroFramework.Controls.MetroButton();
            this.nameLbl = new System.Windows.Forms.Label();
            this.surnameLbl = new System.Windows.Forms.Label();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.nameTbx = new System.Windows.Forms.TextBox();
            this.surnameTbx = new System.Windows.Forms.TextBox();
            this.deleteBtn = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.usernameTbx = new System.Windows.Forms.TextBox();
            this.adminsGrid = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.passwordlbl = new System.Windows.Forms.Label();
            this.passwordTbx = new System.Windows.Forms.TextBox();
            this.allAdminsLbl = new System.Windows.Forms.Label();
            this.createCbx = new MetroFramework.Controls.MetroCheckBox();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminsGrid)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // applyBtn
            // 
            this.applyBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.applyBtn.Location = new System.Drawing.Point(55, 3);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(75, 20);
            this.applyBtn.TabIndex = 11;
            this.applyBtn.Text = "Apply";
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 2);
            this.panel1.Controls.Add(this.clearBtn);
            this.panel1.Controls.Add(this.applyBtn);
            this.panel1.Location = new System.Drawing.Point(3, 123);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(269, 28);
            this.panel1.TabIndex = 23;
            // 
            // clearBtn
            // 
            this.clearBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clearBtn.Location = new System.Drawing.Point(136, 3);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 20);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "Clear";
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // nameLbl
            // 
            this.nameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nameLbl.Location = new System.Drawing.Point(56, 7);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(41, 15);
            this.nameLbl.TabIndex = 3;
            this.nameLbl.Text = "Name";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // surnameLbl
            // 
            this.surnameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.surnameLbl.AutoSize = true;
            this.surnameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surnameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.surnameLbl.Location = new System.Drawing.Point(39, 37);
            this.surnameLbl.Name = "surnameLbl";
            this.surnameLbl.Size = new System.Drawing.Size(58, 15);
            this.surnameLbl.TabIndex = 4;
            this.surnameLbl.Text = "Surname";
            this.surnameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // usernameLbl
            // 
            this.usernameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.usernameLbl.Location = new System.Drawing.Point(32, 67);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(65, 15);
            this.usernameLbl.TabIndex = 5;
            this.usernameLbl.Text = "Username";
            this.usernameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTbx
            // 
            this.nameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.nameTbx.Location = new System.Drawing.Point(103, 5);
            this.nameTbx.Name = "nameTbx";
            this.nameTbx.Size = new System.Drawing.Size(169, 20);
            this.nameTbx.TabIndex = 7;
            // 
            // surnameTbx
            // 
            this.surnameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.surnameTbx.Location = new System.Drawing.Point(103, 35);
            this.surnameTbx.Name = "surnameTbx";
            this.surnameTbx.Size = new System.Drawing.Size(169, 20);
            this.surnameTbx.TabIndex = 8;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deleteBtn.Location = new System.Drawing.Point(201, 3);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(71, 20);
            this.deleteBtn.TabIndex = 11;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.createCbx, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.deleteBtn, 2, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(384, 43);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(275, 26);
            this.tableLayoutPanel2.TabIndex = 22;
            // 
            // usernameTbx
            // 
            this.usernameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.usernameTbx.Location = new System.Drawing.Point(103, 65);
            this.usernameTbx.Name = "usernameTbx";
            this.usernameTbx.Size = new System.Drawing.Size(169, 20);
            this.usernameTbx.TabIndex = 9;
            // 
            // adminsGrid
            // 
            this.adminsGrid.AllowUserToAddRows = false;
            this.adminsGrid.AllowUserToDeleteRows = false;
            this.adminsGrid.AllowUserToResizeRows = false;
            this.adminsGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminsGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.adminsGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.adminsGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.adminsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminsGrid.Location = new System.Drawing.Point(17, 46);
            this.adminsGrid.MultiSelect = false;
            this.adminsGrid.Name = "adminsGrid";
            this.adminsGrid.ReadOnly = true;
            this.adminsGrid.RowHeadersVisible = false;
            this.adminsGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.adminsGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.adminsGrid.Size = new System.Drawing.Size(361, 376);
            this.adminsGrid.TabIndex = 21;
            this.adminsGrid.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.adminsGrid_ColumnHeaderMouseClick);
            this.adminsGrid.SelectionChanged += new System.EventHandler(this.adminsGrid_SelectionChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.nameLbl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.surnameLbl, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.usernameLbl, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.nameTbx, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.surnameTbx, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.usernameTbx, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.passwordlbl, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.passwordTbx, 1, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(384, 78);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(275, 154);
            this.tableLayoutPanel1.TabIndex = 20;
            // 
            // passwordlbl
            // 
            this.passwordlbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.passwordlbl.AutoSize = true;
            this.passwordlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordlbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.passwordlbl.Location = new System.Drawing.Point(36, 97);
            this.passwordlbl.Name = "passwordlbl";
            this.passwordlbl.Size = new System.Drawing.Size(61, 15);
            this.passwordlbl.TabIndex = 10;
            this.passwordlbl.Text = "Password";
            this.passwordlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // passwordTbx
            // 
            this.passwordTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.passwordTbx.Location = new System.Drawing.Point(103, 95);
            this.passwordTbx.Name = "passwordTbx";
            this.passwordTbx.PasswordChar = '*';
            this.passwordTbx.Size = new System.Drawing.Size(169, 20);
            this.passwordTbx.TabIndex = 11;
            // 
            // allAdminsLbl
            // 
            this.allAdminsLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.allAdminsLbl.AutoSize = true;
            this.allAdminsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allAdminsLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allAdminsLbl.Location = new System.Drawing.Point(22, 14);
            this.allAdminsLbl.Name = "allAdminsLbl";
            this.allAdminsLbl.Size = new System.Drawing.Size(76, 18);
            this.allAdminsLbl.TabIndex = 19;
            this.allAdminsLbl.Text = "All Admins";
            this.allAdminsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createCbx
            // 
            this.createCbx.AutoSize = true;
            this.createCbx.Dock = System.Windows.Forms.DockStyle.Left;
            this.createCbx.Location = new System.Drawing.Point(3, 3);
            this.createCbx.Name = "createCbx";
            this.createCbx.Size = new System.Drawing.Size(57, 20);
            this.createCbx.TabIndex = 23;
            this.createCbx.Text = "Create";
            this.createCbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.createCbx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.createCbx.UseVisualStyleBackColor = true;
            this.createCbx.CheckedChanged += new System.EventHandler(this.createCbx_CheckedChanged);
            // 
            // AdminView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.adminsGrid);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.allAdminsLbl);
            this.Name = "AdminView";
            this.Size = new System.Drawing.Size(676, 436);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminsGrid)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton applyBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label surnameLbl;
        private System.Windows.Forms.Label usernameLbl;
        private System.Windows.Forms.TextBox nameTbx;
        private System.Windows.Forms.TextBox surnameTbx;
        private System.Windows.Forms.TextBox usernameTbx;
        private System.Windows.Forms.Label passwordlbl;
        private System.Windows.Forms.TextBox passwordTbx;
        private MetroFramework.Controls.MetroButton clearBtn;
        private MetroFramework.Controls.MetroButton deleteBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView adminsGrid;
        private System.Windows.Forms.Label allAdminsLbl;
        private MetroFramework.Controls.MetroCheckBox createCbx;
    }
}
