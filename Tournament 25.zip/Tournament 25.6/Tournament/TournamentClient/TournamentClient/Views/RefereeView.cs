﻿using System.ComponentModel;
using System.Windows.Forms;
using TournamentModels;
using FootballTournament.HelperClasses;

namespace FootballTournament.Views
{
    public partial class RefereeView : UserControl
    {
        private Referee _selectedReferee;
        Action _action;
        public Action Action
        {
            get => _action;
            set
            {
                _action = value;
                if (value == Action.Create)
                    ClearValues();

                applyBtn.Text = value.ToString();
                createCbx.Checked = value == Action.Create;
            }
        }

        private BindingList<Referee> _referees;
        public BindingList<Referee> Referees
        {
            set
            {
                _referees = value;

                if (value == null)
                    return;

                refereesGrid.DataSource = value;
                refereesGrid.Columns[nameof(Referee.Id)].Visible = false;
                refereesGrid.Columns[nameof(Referee.Name)].SortMode = DataGridViewColumnSortMode.Automatic;
                refereesGrid.Columns[nameof(Referee.Surname)].SortMode = DataGridViewColumnSortMode.Automatic;
                refereesGrid.Columns[nameof(Referee.Experience)].SortMode = DataGridViewColumnSortMode.Automatic;
            }
            get
            {
                return _referees;
            }
        }

        public RefereeView()
        {
            InitializeComponent();

            Action = Action.Create;
        }

        private bool UpdateReferee()
        {
            if (!int.TryParse(experianceTbx.Text, out int experience))
            {
                MessageBox.Show("Experience must be number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var tmp = new Referee()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Experience = experience,
                Id = _selectedReferee.Id,
            };

            var result = AppController.Instance.UpdateReferee(tmp);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully updated referee" : result.Item2;
            string title = result.Item1 ? "Referee update successful" : "Referee update failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool CreateNewReferee()
        {
            if (!int.TryParse(experianceTbx.Text, out int experiance))
            {
                MessageBox.Show("Experience must be number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            };

            var referee = new Referee()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Experience = experiance
            };

            var result = AppController.Instance.CreateNewReferee(referee);

            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully created a new referee" : result.Item2;
            string title = result.Item1 ? "Referee creation successful" : "Referee creation failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private void ClearValues()
        {
            refereesGrid.ClearSelection();
            nameTbx.Text = string.Empty;
            surnameTbx.Text = string.Empty;
            experianceTbx.Text = string.Empty;
        }

        private void deleteBtn_Click(object sender, System.EventArgs e)
        {
            string refereeName = $"{_selectedReferee.Name} {_selectedReferee.Surname }";
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {refereeName}?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            (success, message) = AppController.Instance.DeleteReferee(_selectedReferee);
            if (success)
                MessageBox.Show($"{refereeName} successfully deleted!");
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void applyBtn_Click(object sender, System.EventArgs e)
        {
            bool success = true;
            if (Action == Action.Update)
                success = UpdateReferee();
            else if (Action == Action.Create)
                success = CreateNewReferee();


            if (!success)
                return;
            ClearValues();
        }

        private void clearBtn_Click(object sender, System.EventArgs e)
        {
            refereesGrid.ClearSelection();
            ClearValues();
        }

        private void refereesGrid_SelectionChanged(object sender, System.EventArgs e)
        {
            _selectedReferee = null;
            deleteBtn.Enabled = refereesGrid.SelectedRows.Count != 0;

            if (refereesGrid.SelectedRows.Count == 0)
            {
                nameTbx.Text = string.Empty;
                surnameTbx.Text = string.Empty;
                experianceTbx.Text = string.Empty;
                Action = Action.Create;
                return;
            }


            if (!(refereesGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Referee referee))
                return;

            _selectedReferee = referee;


            nameTbx.Text = referee.Name;
            surnameTbx.Text = referee.Surname;
            experianceTbx.Text = referee.Experience.ToString();
            Action = Action.Update;
        }

        private void refereesGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Referee>(refereesGrid, e.ColumnIndex, Referees);
        }

        private void createCbx_CheckedChanged(object sender, System.EventArgs e)
        {
            Action = createCbx.Checked ? Action.Create : Action.Update;
        }
    }
}
