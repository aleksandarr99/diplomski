﻿using FootballTournament.HelperClasses;
using MetroFramework.Controls;
using System;
using System.ComponentModel;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Views
{
    public partial class AdminView : UserControl
    {
        private Admin _selectedAdmin;

        Action _action;
        public Action Action
        {
            get => _action;
            set
            {
                _action = value;
                if (value == Action.Create)
                    ClearValues();

                applyBtn.Text = value.ToString();
                createCbx.Checked = value == Action.Create;
            }
        }

        private BindingList<Admin> _admins;
        public BindingList<Admin> Admins
        {
            set
            {
                _admins = value;

                if (value == null)
                    return;

                adminsGrid.DataSource = value;
                adminsGrid.Columns[nameof(Admin.Id)].Visible = false;
                adminsGrid.Columns[nameof(Admin.Password)].Visible = false;

                adminsGrid.Columns[nameof(Admin.Surname)].SortMode = DataGridViewColumnSortMode.Automatic;
                adminsGrid.Columns[nameof(Admin.Name)].SortMode = DataGridViewColumnSortMode.Automatic;
                adminsGrid.Columns[nameof(Admin.Username)].SortMode = DataGridViewColumnSortMode.Automatic;
            }
            get
            {
                return _admins;
            }
        }

        public AdminView()
        {
            InitializeComponent();

            tableLayoutPanel1.Enabled = AppController.Instance.RootAdmin;
            tableLayoutPanel2.Enabled = AppController.Instance.RootAdmin;

            Action = Action.Create;
        }

        private void ClearValues()
        {
            adminsGrid.ClearSelection();
            nameTbx.Text = string.Empty;
            surnameTbx.Text = string.Empty;
            usernameTbx.Text = string.Empty;
            passwordTbx.Text = string.Empty;
        }

        private bool UpdateAdmin()
        {
            if (passwordTbx.Text.Length < 4 || usernameTbx.Text.Length < 4)
            {
                MessageBox.Show("Username and password should be at least 8 characters.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            var tmp = new Admin()
            {
                Id = _selectedAdmin.Id,
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Username = usernameTbx.Text,
                Password = passwordTbx.Text
            };

            var result = AppController.Instance.UpdateAdmin(tmp);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully updated admin" : result.Item2;
            string title = result.Item1 ? "Admin update successful" : "Admin update failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool CreateNewAdmin()
        {
            if (passwordTbx.Text.Length < 4 || usernameTbx.Text.Length < 4)
            {
                MessageBox.Show("Username and password should be at least 8 characters.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            //inspect is there a admin with a same username


            var admin = new Admin()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Password = passwordTbx.Text,
                Username = usernameTbx.Text
            };

            var result = AppController.Instance.CreateNewAdmin(admin);

            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully created a new admin" : result.Item2;
            string title = result.Item1 ? "Admin creation successful" : "Admin creation failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private void adminsGrid_SelectionChanged(object sender, EventArgs e)
        {
            _selectedAdmin = null;
            deleteBtn.Enabled = adminsGrid.SelectedRows.Count != 0;

            if (adminsGrid.SelectedRows.Count == 0)
            {
                nameTbx.Text = string.Empty;
                surnameTbx.Text = string.Empty;
                usernameTbx.Text = string.Empty;
                passwordTbx.Text = string.Empty;
                Action = Action.Create;
                return;
            }


            if (!(adminsGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Admin admin))
                return;

            _selectedAdmin = admin;


            nameTbx.Text = admin.Name;
            surnameTbx.Text = admin.Surname;
            passwordTbx.Text = admin.Password;
            usernameTbx.Text = admin.Username;
            Action = Action.Update;
        }

        private void adminsGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Admin>(adminsGrid, e.ColumnIndex, Admins);
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string refereeName = $"{_selectedAdmin.Name} {_selectedAdmin.Surname }";
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {refereeName}?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            (success, message) = AppController.Instance.DeleteAdmin(_selectedAdmin);
            if (success)
                MessageBox.Show($"{refereeName} successfully deleted!");
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void applyBtn_Click(object sender, EventArgs e)
        {
            bool success = true;
            if (Action == Action.Update)
                success = UpdateAdmin();
            else if (Action == Action.Create)
                success = CreateNewAdmin();


            if (!success)
                return;
            ClearValues();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            adminsGrid.ClearSelection();
            ClearValues();
        }

        private void createCbx_CheckedChanged(object sender, EventArgs e)
        {
            Action = createCbx.Checked ? Action.Create : Action.Update;
        }
    }
}
