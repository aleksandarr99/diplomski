﻿namespace FootballTournament.Views
{
    partial class RefereeView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.applyBtn = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearBtn = new MetroFramework.Controls.MetroButton();
            this.nameLbl = new System.Windows.Forms.Label();
            this.surnameLbl = new System.Windows.Forms.Label();
            this.experianceLbl = new System.Windows.Forms.Label();
            this.nameTbx = new System.Windows.Forms.TextBox();
            this.surnameTbx = new System.Windows.Forms.TextBox();
            this.deleteBtn = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.experianceTbx = new System.Windows.Forms.TextBox();
            this.refereesGrid = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.allRefereesLbl = new System.Windows.Forms.Label();
            this.createCbx = new MetroFramework.Controls.MetroCheckBox();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.refereesGrid)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // applyBtn
            // 
            this.applyBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.applyBtn.Location = new System.Drawing.Point(58, 3);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(75, 20);
            this.applyBtn.TabIndex = 11;
            this.applyBtn.Text = "Apply";
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.clearBtn);
            this.panel1.Controls.Add(this.applyBtn);
            this.panel1.Location = new System.Drawing.Point(384, 398);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(275, 24);
            this.panel1.TabIndex = 18;
            // 
            // clearBtn
            // 
            this.clearBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clearBtn.Location = new System.Drawing.Point(139, 3);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 20);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "Clear";
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // nameLbl
            // 
            this.nameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nameLbl.Location = new System.Drawing.Point(56, 7);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(41, 15);
            this.nameLbl.TabIndex = 3;
            this.nameLbl.Text = "Name";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // surnameLbl
            // 
            this.surnameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.surnameLbl.AutoSize = true;
            this.surnameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surnameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.surnameLbl.Location = new System.Drawing.Point(39, 37);
            this.surnameLbl.Name = "surnameLbl";
            this.surnameLbl.Size = new System.Drawing.Size(58, 15);
            this.surnameLbl.TabIndex = 4;
            this.surnameLbl.Text = "Surname";
            this.surnameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // experianceLbl
            // 
            this.experianceLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.experianceLbl.AutoSize = true;
            this.experianceLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.experianceLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.experianceLbl.Location = new System.Drawing.Point(28, 67);
            this.experianceLbl.Name = "experianceLbl";
            this.experianceLbl.Size = new System.Drawing.Size(69, 15);
            this.experianceLbl.TabIndex = 5;
            this.experianceLbl.Text = "Experiance";
            this.experianceLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTbx
            // 
            this.nameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.nameTbx.Location = new System.Drawing.Point(103, 5);
            this.nameTbx.Name = "nameTbx";
            this.nameTbx.Size = new System.Drawing.Size(169, 20);
            this.nameTbx.TabIndex = 7;
            // 
            // surnameTbx
            // 
            this.surnameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.surnameTbx.Location = new System.Drawing.Point(103, 35);
            this.surnameTbx.Name = "surnameTbx";
            this.surnameTbx.Size = new System.Drawing.Size(169, 20);
            this.surnameTbx.TabIndex = 8;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deleteBtn.Location = new System.Drawing.Point(201, 3);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(71, 20);
            this.deleteBtn.TabIndex = 11;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel2.Controls.Add(this.createCbx, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.deleteBtn, 2, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(384, 43);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(275, 26);
            this.tableLayoutPanel2.TabIndex = 17;
            // 
            // experianceTbx
            // 
            this.experianceTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.experianceTbx.Location = new System.Drawing.Point(103, 65);
            this.experianceTbx.Name = "experianceTbx";
            this.experianceTbx.Size = new System.Drawing.Size(169, 20);
            this.experianceTbx.TabIndex = 9;
            // 
            // refereesGrid
            // 
            this.refereesGrid.AllowUserToAddRows = false;
            this.refereesGrid.AllowUserToDeleteRows = false;
            this.refereesGrid.AllowUserToResizeRows = false;
            this.refereesGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.refereesGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.refereesGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.refereesGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.refereesGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.refereesGrid.Location = new System.Drawing.Point(17, 46);
            this.refereesGrid.MultiSelect = false;
            this.refereesGrid.Name = "refereesGrid";
            this.refereesGrid.ReadOnly = true;
            this.refereesGrid.RowHeadersVisible = false;
            this.refereesGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.refereesGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.refereesGrid.Size = new System.Drawing.Size(361, 376);
            this.refereesGrid.TabIndex = 16;
            this.refereesGrid.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.refereesGrid_ColumnHeaderMouseClick);
            this.refereesGrid.SelectionChanged += new System.EventHandler(this.refereesGrid_SelectionChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.nameLbl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.surnameLbl, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.experianceLbl, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.nameTbx, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.surnameTbx, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.experianceTbx, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(384, 78);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(275, 313);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // allRefereesLbl
            // 
            this.allRefereesLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.allRefereesLbl.AutoSize = true;
            this.allRefereesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allRefereesLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allRefereesLbl.Location = new System.Drawing.Point(22, 14);
            this.allRefereesLbl.Name = "allRefereesLbl";
            this.allRefereesLbl.Size = new System.Drawing.Size(79, 18);
            this.allRefereesLbl.TabIndex = 14;
            this.allRefereesLbl.Text = "All Referee";
            this.allRefereesLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createCbx
            // 
            this.createCbx.AutoSize = true;
            this.createCbx.Dock = System.Windows.Forms.DockStyle.Left;
            this.createCbx.Location = new System.Drawing.Point(3, 3);
            this.createCbx.Name = "createCbx";
            this.createCbx.Size = new System.Drawing.Size(57, 20);
            this.createCbx.TabIndex = 24;
            this.createCbx.Text = "Create";
            this.createCbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.createCbx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.createCbx.UseVisualStyleBackColor = true;
            this.createCbx.CheckedChanged += new System.EventHandler(this.createCbx_CheckedChanged);
            // 
            // RefereeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.refereesGrid);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.allRefereesLbl);
            this.Name = "RefereeView";
            this.Size = new System.Drawing.Size(676, 436);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.refereesGrid)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton applyBtn;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroButton clearBtn;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label surnameLbl;
        private System.Windows.Forms.Label experianceLbl;
        private System.Windows.Forms.TextBox nameTbx;
        private System.Windows.Forms.TextBox surnameTbx;
        private MetroFramework.Controls.MetroButton deleteBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox experianceTbx;
        private System.Windows.Forms.DataGridView refereesGrid;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label allRefereesLbl;
        private MetroFramework.Controls.MetroCheckBox createCbx;
    }
}
