﻿using FootballTournament.Forms;
using FootballTournament.HelperClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Views
{
    public partial class TournamentView : UserControl
    {
        private static readonly string dateTimeUIFormat = "dd.MMMM.yyyy";

        private Tournament _selectedTournament;

        private BindingList<Referee> _selectedReferees = new BindingList<Referee>();
        private BindingList<Country> _selectedCoutries = new BindingList<Country>();

        Action _action;
        public Action Action
        {
            get => _action;
            set
            {
                _action = value;
                if (value == Action.Create)
                    ClearValues();

                applyBtn.Text = value.ToString();
                createCbx.Checked = value == Action.Create;
                refereesBtn.Enabled = value == Action.Create;
                countriesBtn.Enabled = value == Action.Create;
                capacityCbx.Enabled = value == Action.Create;
            }
        }

        private BindingList<Tournament> _tournaments;
        public BindingList<Tournament> Tournaments
        {
            set
            {
                _tournaments = value;

                if (value == null)
                    return;

                tournamentsDG.DataSource = value;
                tournamentsDG.Columns[nameof(Tournament.Id)].Visible = false;
                tournamentsDG.Columns[nameof(Tournament.AdminID)].Visible = false;
                tournamentsDG.Columns[nameof(Tournament.Admin)].Visible = false;

                tournamentsDG.Columns[nameof(Tournament.Name)].SortMode = DataGridViewColumnSortMode.Automatic;
                tournamentsDG.Columns[nameof(Tournament.City)].SortMode = DataGridViewColumnSortMode.Automatic;
                tournamentsDG.Columns[nameof(Tournament.Description)].SortMode = DataGridViewColumnSortMode.Automatic;
                tournamentsDG.Columns[nameof(Tournament.StartTime)].SortMode = DataGridViewColumnSortMode.Automatic;
                tournamentsDG.Columns[nameof(Tournament.EndTime)].SortMode = DataGridViewColumnSortMode.Automatic;
            }
            get
            {
                return _tournaments;
            }
        }


        public TournamentView()
        {
            InitializeComponent();

            capacityCbx.DataSource = Enum.GetValues(typeof(TournamentCapacity));

            startDateTimePicker.CustomFormat = dateTimeUIFormat;
            endDateTimePicker.CustomFormat = dateTimeUIFormat;


            refereesDG.DataSource = _selectedReferees;
            countriesDG.DataSource = _selectedCoutries;
            TryToHideIDColumn();
            tournamentsDG.ClearSelection();
            Action = Action.Create;
        }

        private void TryToHideIDColumn()
        {
            try
            {
                countriesDG.Columns["ID"].Visible = false;
                refereesDG.Columns["ID"].Visible = false;
            }
            catch
            { }
        }

        private void ClearValues()
        {
            tournamentsDG.ClearSelection();
            _selectedCoutries.Clear();
            _selectedReferees.Clear();
            nameTbx.Text = string.Empty;
            cityTbx.Text = string.Empty;
            descriptionTbx.Text = string.Empty;
            startDateTimePicker.Value = DateTime.Now;
            endDateTimePicker.Value = DateTime.Now;
        }

        private bool UpdateTournament()
        {
            if (!ValidateValues())
                return false;

            var tmp = new Tournament()
            {
                Id = _selectedTournament.Id,
                Name = nameTbx.Text,
                City = cityTbx.Text,
                Description = descriptionTbx.Text,
                StartTime = startDateTimePicker.Value,
                EndTime = endDateTimePicker.Value,
                Admin = AppController.Instance.Admin,
                AdminID = AppController.Instance.Admin.Id
            };

            var result = AppController.Instance.UpdateTournament(tmp);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully updated tournament" : result.Item2;
            string title = result.Item1 ? "Tournament update successful" : "Tournament update failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool CreateNewTournament()
        {
            if (!ValidateValues())
                return false;


            var countries = new List<Country>(_selectedCoutries);
            var referees = new List<Referee>(_selectedReferees);
            var countryIds = countries.Select(x => x.Id).ToList();
            var refereeIds = referees.Select(x => x.Id).ToList();

            var tournament = new Tournament()
            {
                Name = nameTbx.Text,
                City = cityTbx.Text,
                Description = descriptionTbx.Text,
                StartTime = startDateTimePicker.Value,
                EndTime = endDateTimePicker.Value,
                Admin = AppController.Instance.Admin,
                AdminID = AppController.Instance.Admin.Id,
                CountryIds = countryIds,
                Capacity = (TournamentCapacity)capacityCbx.SelectedItem,
                RefereeIds = refereeIds
            };

            var result = AppController.Instance.CreateNewTournament(tournament);

            if (result.Item1)
            {
                tournament.Countries = countries;
                tournament.Referees = referees;
            }

            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully created a new tournament" : result.Item2;
            string title = result.Item1 ? "Tournament creation successful" : "Tournament creation failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool ValidateValues()
        {
            if (string.IsNullOrEmpty(nameTbx.Text))
            {
                MessageBox.Show("Please add a tournament name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrEmpty(cityTbx.Text))
            {
                MessageBox.Show("Please add a tournament city.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (startDateTimePicker.Value.Date == endDateTimePicker.Value.Date)
            {
                MessageBox.Show("Please add a different start and end tournament date.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            int capacity = (int)capacityCbx.SelectedItem;
            int refereeCapacity = (int)capacityCbx.SelectedItem / 4;
            if (_selectedReferees.Count < refereeCapacity)
            {
                MessageBox.Show($"Please select {refereeCapacity} referees.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (_selectedCoutries.Count < capacity)
            {
                MessageBox.Show($"Please select {capacity} countries.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void tournamentsGrid_SelectionChanged(object sender, EventArgs e)
        {
            _selectedTournament = null;
            deleteBtn.Enabled = tournamentsDG.SelectedRows.Count != 0;
            expandBtn.Enabled = tournamentsDG.SelectedRows.Count != 0;

            if (tournamentsDG.SelectedRows.Count == 0)
            {
                nameTbx.Text = string.Empty;
                cityTbx.Text = string.Empty;
                descriptionTbx.Text = string.Empty;
                endDateTimePicker.Value = DateTime.Now;
                startDateTimePicker.Value = DateTime.Now;
                Action = Action.Create;
                return;
            }


            if (!(tournamentsDG.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Tournament tournament))
                return;

            _selectedCoutries.Clear();
            foreach (var item in tournament.Countries)
                _selectedCoutries.Add(item);

            _selectedReferees.Clear();
            foreach (var item in tournament.Referees)
                _selectedReferees.Add(item);


            _selectedTournament = tournament;
            nameTbx.Text = tournament.Name;
            cityTbx.Text = tournament.City;
            descriptionTbx.Text = tournament.Description;
            startDateTimePicker.Value = tournament.StartTime;
            endDateTimePicker.Value = tournament.EndTime;
            Action = Action.Update;
        }

        private void tournamentsGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Tournament>(tournamentsDG, e.ColumnIndex, Tournaments);
        }

        private void applyBtn_Click(object sender, EventArgs e)
        {
            bool success = true;
            if (Action == Action.Update)
                success = UpdateTournament();
            else if (Action == Action.Create)
                success = CreateNewTournament();


            if (!success)
                return;
            ClearValues();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            tournamentsDG.ClearSelection();
            ClearValues();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            string refereeName = $"{_selectedTournament.Name}";
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {refereeName}?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            (success, message) = AppController.Instance.DeleteTournament(_selectedTournament);
            if (success)
                MessageBox.Show($"{refereeName} successfully deleted!");
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void createCbx_CheckedChanged(object sender, EventArgs e)
        {
            Action = createCbx.Checked ? Action.Create : Action.Update;
        }

        private void Expand_Click(object sender, EventArgs e)
        {
            //TournamentWindow window = new TournamentWindow(_selectedTournament);
            GamesWindow window = new GamesWindow(_selectedTournament);
            window.ShowDialog();
        }

        private void tournamentsGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (tournamentsDG.Columns[e.ColumnIndex].Name != nameof(Tournament.EndTime) && tournamentsDG.Columns[e.ColumnIndex].Name != nameof(Tournament.StartTime))
                return;

            if (e.Value == null)
                return;

            DateTime date = DateTime.Parse(e.Value.ToString());

            e.Value = date.ToString(dateTimeUIFormat);
            e.FormattingApplied = true;
        }

        private void countriesBtn_Click(object sender, EventArgs e)
        {
            var capacity = (int)capacityCbx.SelectedItem;
            UniversalMultiSelectForm<Country> selection = new UniversalMultiSelectForm<Country>(capacity, _selectedCoutries);
            selection.ShowDialog();
            if (selection.DialogResult != DialogResult.OK)
                return;
            _selectedCoutries.Clear();
            foreach (var item in selection.SelectedItems)
                _selectedCoutries.Add(item);
        }

        private void refereesBtn_Click(object sender, EventArgs e)
        {
            var capacity = (int)capacityCbx.SelectedItem / 4;
            UniversalMultiSelectForm<Referee> selection = new UniversalMultiSelectForm<Referee>(capacity, _selectedReferees);
            selection.ShowDialog();
            if (selection.DialogResult != DialogResult.OK)
                return;

            _selectedReferees.Clear();
            foreach (var item in selection.SelectedItems)
                _selectedReferees.Add(item);
        }

        private void capacityCbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            var capacity = (int)capacityCbx.SelectedItem;
            var refereeCapacity = capacity / 4;

            while (_selectedCoutries.Count > capacity)
                _selectedCoutries.RemoveAt(_selectedCoutries.Count - 1);
            while(_selectedReferees.Count > refereeCapacity)
                _selectedReferees.RemoveAt(_selectedReferees.Count - 1);
        }
    }
}
