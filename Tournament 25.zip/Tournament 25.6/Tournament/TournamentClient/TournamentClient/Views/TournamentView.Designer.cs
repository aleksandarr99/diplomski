﻿
namespace FootballTournament.Views
{
    partial class TournamentView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.createCbx = new MetroFramework.Controls.MetroCheckBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.cityLbl = new System.Windows.Forms.Label();
            this.startLbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nameTbx = new System.Windows.Forms.TextBox();
            this.cityTbx = new System.Windows.Forms.TextBox();
            this.deleteBtn = new MetroFramework.Controls.MetroButton();
            this.tournamentsDG = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.capacityLbl = new System.Windows.Forms.Label();
            this.startDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.endDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.descriptionLbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearBtn = new MetroFramework.Controls.MetroButton();
            this.applyBtn = new MetroFramework.Controls.MetroButton();
            this.descriptionTbx = new System.Windows.Forms.TextBox();
            this.capacityCbx = new System.Windows.Forms.ComboBox();
            this.allTournamentsLbl = new System.Windows.Forms.Label();
            this.expandBtn = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.refereesBtn = new MetroFramework.Controls.MetroButton();
            this.countriesBtn = new MetroFramework.Controls.MetroButton();
            this.countriesDG = new System.Windows.Forms.DataGridView();
            this.refereesDG = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.tournamentsDG)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countriesDG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.refereesDG)).BeginInit();
            this.SuspendLayout();
            // 
            // createCbx
            // 
            this.createCbx.AutoSize = true;
            this.createCbx.Dock = System.Windows.Forms.DockStyle.Left;
            this.createCbx.Location = new System.Drawing.Point(3, 3);
            this.createCbx.Name = "createCbx";
            this.createCbx.Size = new System.Drawing.Size(57, 24);
            this.createCbx.TabIndex = 24;
            this.createCbx.Text = "Create";
            this.createCbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.createCbx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.createCbx.UseVisualStyleBackColor = true;
            this.createCbx.CheckedChanged += new System.EventHandler(this.createCbx_CheckedChanged);
            // 
            // nameLbl
            // 
            this.nameLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nameLbl.Location = new System.Drawing.Point(31, 7);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(46, 15);
            this.nameLbl.TabIndex = 3;
            this.nameLbl.Text = "Name*";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cityLbl
            // 
            this.cityLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.cityLbl.AutoSize = true;
            this.cityLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cityLbl.Location = new System.Drawing.Point(46, 37);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(31, 15);
            this.cityLbl.TabIndex = 4;
            this.cityLbl.Text = "City*";
            this.cityLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // startLbl
            // 
            this.startLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.startLbl.AutoSize = true;
            this.startLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.startLbl.Location = new System.Drawing.Point(11, 67);
            this.startLbl.Name = "startLbl";
            this.startLbl.Size = new System.Drawing.Size(66, 15);
            this.startLbl.TabIndex = 5;
            this.startLbl.Text = "Start Date*";
            this.startLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(14, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "End Date*";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTbx
            // 
            this.nameTbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nameTbx.Location = new System.Drawing.Point(83, 3);
            this.nameTbx.Name = "nameTbx";
            this.nameTbx.Size = new System.Drawing.Size(147, 20);
            this.nameTbx.TabIndex = 7;
            // 
            // cityTbx
            // 
            this.cityTbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cityTbx.Location = new System.Drawing.Point(83, 33);
            this.cityTbx.Name = "cityTbx";
            this.cityTbx.Size = new System.Drawing.Size(147, 20);
            this.cityTbx.TabIndex = 8;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.deleteBtn.Location = new System.Drawing.Point(679, 671);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(55, 34);
            this.deleteBtn.TabIndex = 11;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // tournamentsDG
            // 
            this.tournamentsDG.AllowUserToAddRows = false;
            this.tournamentsDG.AllowUserToDeleteRows = false;
            this.tournamentsDG.AllowUserToResizeRows = false;
            this.tournamentsDG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tournamentsDG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.tournamentsDG.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tournamentsDG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tournamentsDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tournamentsDG.Location = new System.Drawing.Point(9, 387);
            this.tournamentsDG.MultiSelect = false;
            this.tournamentsDG.Name = "tournamentsDG";
            this.tournamentsDG.ReadOnly = true;
            this.tournamentsDG.RowHeadersVisible = false;
            this.tournamentsDG.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tournamentsDG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tournamentsDG.Size = new System.Drawing.Size(725, 275);
            this.tournamentsDG.TabIndex = 14;
            this.tournamentsDG.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.tournamentsGrid_CellFormatting);
            this.tournamentsDG.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.tournamentsGrid_ColumnHeaderMouseClick);
            this.tournamentsDG.SelectionChanged += new System.EventHandler(this.tournamentsGrid_SelectionChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.capacityLbl, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.startDateTimePicker, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.endDateTimePicker, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.descriptionLbl, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.nameLbl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.cityLbl, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.startLbl, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.nameTbx, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.cityTbx, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.descriptionTbx, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.capacityCbx, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 33);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(233, 282);
            this.tableLayoutPanel1.TabIndex = 13;
            // 
            // capacityLbl
            // 
            this.capacityLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.capacityLbl.AutoSize = true;
            this.capacityLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.capacityLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.capacityLbl.Location = new System.Drawing.Point(19, 217);
            this.capacityLbl.Name = "capacityLbl";
            this.capacityLbl.Size = new System.Drawing.Size(58, 15);
            this.capacityLbl.TabIndex = 19;
            this.capacityLbl.Text = "Capacity*";
            this.capacityLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.CustomFormat = "dd.MMMM.yyyy";
            this.startDateTimePicker.Dock = System.Windows.Forms.DockStyle.Fill;
            this.startDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.startDateTimePicker.Location = new System.Drawing.Point(83, 63);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(147, 20);
            this.startDateTimePicker.TabIndex = 17;
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.CustomFormat = "dd.MMMM.yyyy";
            this.endDateTimePicker.Dock = System.Windows.Forms.DockStyle.Fill;
            this.endDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDateTimePicker.Location = new System.Drawing.Point(83, 93);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.endDateTimePicker.Size = new System.Drawing.Size(147, 20);
            this.endDateTimePicker.TabIndex = 16;
            // 
            // descriptionLbl
            // 
            this.descriptionLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.descriptionLbl.AutoSize = true;
            this.descriptionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.descriptionLbl.Location = new System.Drawing.Point(8, 127);
            this.descriptionLbl.Name = "descriptionLbl";
            this.descriptionLbl.Size = new System.Drawing.Size(69, 15);
            this.descriptionLbl.TabIndex = 14;
            this.descriptionLbl.Text = "Description";
            this.descriptionLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 2);
            this.panel1.Controls.Add(this.clearBtn);
            this.panel1.Controls.Add(this.applyBtn);
            this.panel1.Location = new System.Drawing.Point(3, 252);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(227, 27);
            this.panel1.TabIndex = 13;
            // 
            // clearBtn
            // 
            this.clearBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clearBtn.Location = new System.Drawing.Point(115, 3);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 20);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "Clear";
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // applyBtn
            // 
            this.applyBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.applyBtn.Location = new System.Drawing.Point(34, 3);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(75, 20);
            this.applyBtn.TabIndex = 11;
            this.applyBtn.Text = "Apply";
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // descriptionTbx
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.descriptionTbx, 2);
            this.descriptionTbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.descriptionTbx.Location = new System.Drawing.Point(3, 153);
            this.descriptionTbx.Multiline = true;
            this.descriptionTbx.Name = "descriptionTbx";
            this.descriptionTbx.Size = new System.Drawing.Size(227, 54);
            this.descriptionTbx.TabIndex = 18;
            // 
            // capacityCbx
            // 
            this.capacityCbx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.capacityCbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.capacityCbx.FormatString = "N2";
            this.capacityCbx.FormattingEnabled = true;
            this.capacityCbx.Location = new System.Drawing.Point(83, 213);
            this.capacityCbx.Name = "capacityCbx";
            this.capacityCbx.Size = new System.Drawing.Size(147, 21);
            this.capacityCbx.TabIndex = 20;
            this.capacityCbx.SelectedIndexChanged += new System.EventHandler(this.capacityCbx_SelectedIndexChanged);
            // 
            // allTournamentsLbl
            // 
            this.allTournamentsLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.allTournamentsLbl.AutoSize = true;
            this.allTournamentsLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allTournamentsLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allTournamentsLbl.Location = new System.Drawing.Point(22, 14);
            this.allTournamentsLbl.Name = "allTournamentsLbl";
            this.allTournamentsLbl.Size = new System.Drawing.Size(96, 18);
            this.allTournamentsLbl.TabIndex = 12;
            this.allTournamentsLbl.Text = "Tournaments";
            this.allTournamentsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // expandBtn
            // 
            this.expandBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.expandBtn.Location = new System.Drawing.Point(9, 671);
            this.expandBtn.Name = "expandBtn";
            this.expandBtn.Size = new System.Drawing.Size(94, 34);
            this.expandBtn.TabIndex = 16;
            this.expandBtn.Text = "Expand";
            this.expandBtn.Click += new System.EventHandler(this.Expand_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel3.Controls.Add(this.refereesBtn, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.countriesBtn, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.createCbx, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.countriesDG, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.refereesDG, 2, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(9, 63);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(726, 318);
            this.tableLayoutPanel3.TabIndex = 17;
            // 
            // refereesBtn
            // 
            this.refereesBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.refereesBtn.Location = new System.Drawing.Point(488, 5);
            this.refereesBtn.Name = "refereesBtn";
            this.refereesBtn.Size = new System.Drawing.Size(75, 20);
            this.refereesBtn.TabIndex = 28;
            this.refereesBtn.Text = "Referees";
            this.refereesBtn.Click += new System.EventHandler(this.refereesBtn_Click);
            // 
            // countriesBtn
            // 
            this.countriesBtn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.countriesBtn.Location = new System.Drawing.Point(242, 5);
            this.countriesBtn.Name = "countriesBtn";
            this.countriesBtn.Size = new System.Drawing.Size(75, 20);
            this.countriesBtn.TabIndex = 27;
            this.countriesBtn.Text = "Countries";
            this.countriesBtn.Click += new System.EventHandler(this.countriesBtn_Click);
            // 
            // countriesDG
            // 
            this.countriesDG.AllowUserToAddRows = false;
            this.countriesDG.AllowUserToDeleteRows = false;
            this.countriesDG.AllowUserToResizeRows = false;
            this.countriesDG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.countriesDG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.countriesDG.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.countriesDG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.countriesDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.countriesDG.Location = new System.Drawing.Point(242, 33);
            this.countriesDG.MultiSelect = false;
            this.countriesDG.Name = "countriesDG";
            this.countriesDG.ReadOnly = true;
            this.countriesDG.RowHeadersVisible = false;
            this.countriesDG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.countriesDG.Size = new System.Drawing.Size(240, 282);
            this.countriesDG.TabIndex = 25;
            // 
            // refereesDG
            // 
            this.refereesDG.AllowUserToAddRows = false;
            this.refereesDG.AllowUserToDeleteRows = false;
            this.refereesDG.AllowUserToResizeRows = false;
            this.refereesDG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.refereesDG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.refereesDG.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.refereesDG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.refereesDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.refereesDG.Location = new System.Drawing.Point(488, 33);
            this.refereesDG.MultiSelect = false;
            this.refereesDG.Name = "refereesDG";
            this.refereesDG.ReadOnly = true;
            this.refereesDG.RowHeadersVisible = false;
            this.refereesDG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.refereesDG.Size = new System.Drawing.Size(235, 282);
            this.refereesDG.TabIndex = 26;
            // 
            // TournamentView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.expandBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.tournamentsDG);
            this.Controls.Add(this.allTournamentsLbl);
            this.Name = "TournamentView";
            this.Size = new System.Drawing.Size(746, 705);
            ((System.ComponentModel.ISupportInitialize)(this.tournamentsDG)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countriesDG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.refereesDG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroCheckBox createCbx;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DateTimePicker startDateTimePicker;
        private System.Windows.Forms.DateTimePicker endDateTimePicker;
        private System.Windows.Forms.Label descriptionLbl;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label startLbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox nameTbx;
        private System.Windows.Forms.TextBox cityTbx;
        private System.Windows.Forms.TextBox descriptionTbx;
        private MetroFramework.Controls.MetroButton deleteBtn;
        private System.Windows.Forms.DataGridView tournamentsDG;
        private System.Windows.Forms.Label allTournamentsLbl;
        private MetroFramework.Controls.MetroButton expandBtn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label capacityLbl;
        private System.Windows.Forms.ComboBox capacityCbx;
        private MetroFramework.Controls.MetroButton refereesBtn;
        private MetroFramework.Controls.MetroButton countriesBtn;
        private System.Windows.Forms.DataGridView countriesDG;
        private System.Windows.Forms.DataGridView refereesDG;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroButton clearBtn;
        private MetroFramework.Controls.MetroButton applyBtn;
    }
}
