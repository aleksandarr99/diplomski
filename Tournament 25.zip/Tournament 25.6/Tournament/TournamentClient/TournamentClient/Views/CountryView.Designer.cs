﻿
namespace FootballTournament.Views
{
    partial class CountryView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.applyBtn = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.clearBtn = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.nameTbx = new System.Windows.Forms.TextBox();
            this.deleteBtn = new MetroFramework.Controls.MetroButton();
            this.countriesGrid = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.deletePlayerBtn = new MetroFramework.Controls.MetroButton();
            this.playersLbl = new System.Windows.Forms.Label();
            this.playersGrid = new System.Windows.Forms.DataGridView();
            this.allCountriesLbl = new System.Windows.Forms.Label();
            this.createCbx = new MetroFramework.Controls.MetroCheckBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.countriesGrid)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.playersGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // applyBtn
            // 
            this.applyBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.applyBtn.Location = new System.Drawing.Point(114, 3);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(75, 20);
            this.applyBtn.TabIndex = 11;
            this.applyBtn.Text = "Apply";
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.clearBtn);
            this.panel1.Controls.Add(this.applyBtn);
            this.panel1.Location = new System.Drawing.Point(273, 398);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 24);
            this.panel1.TabIndex = 18;
            // 
            // clearBtn
            // 
            this.clearBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clearBtn.Location = new System.Drawing.Point(195, 3);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 20);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "Clear";
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(56, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameTbx
            // 
            this.nameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.nameTbx.Enabled = false;
            this.nameTbx.Location = new System.Drawing.Point(103, 5);
            this.nameTbx.Name = "nameTbx";
            this.nameTbx.Size = new System.Drawing.Size(280, 20);
            this.nameTbx.TabIndex = 7;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deleteBtn.Enabled = false;
            this.deleteBtn.Location = new System.Drawing.Point(588, 46);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(71, 20);
            this.deleteBtn.TabIndex = 11;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // countriesGrid
            // 
            this.countriesGrid.AllowUserToAddRows = false;
            this.countriesGrid.AllowUserToDeleteRows = false;
            this.countriesGrid.AllowUserToResizeRows = false;
            this.countriesGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.countriesGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.countriesGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.countriesGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.countriesGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.countriesGrid.Location = new System.Drawing.Point(17, 46);
            this.countriesGrid.MultiSelect = false;
            this.countriesGrid.Name = "countriesGrid";
            this.countriesGrid.ReadOnly = true;
            this.countriesGrid.RowHeadersVisible = false;
            this.countriesGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.countriesGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.countriesGrid.Size = new System.Drawing.Size(250, 342);
            this.countriesGrid.TabIndex = 16;
            this.countriesGrid.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.countriesGrid_ColumnHeaderMouseClick);
            this.countriesGrid.SelectionChanged += new System.EventHandler(this.countriesGrid_SelectionChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.deletePlayerBtn, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.playersLbl, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.nameTbx, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.playersGrid, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(273, 78);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(386, 313);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // deletePlayerBtn
            // 
            this.deletePlayerBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.deletePlayerBtn.Location = new System.Drawing.Point(293, 35);
            this.deletePlayerBtn.Name = "deletePlayerBtn";
            this.deletePlayerBtn.Size = new System.Drawing.Size(90, 20);
            this.deletePlayerBtn.TabIndex = 19;
            this.deletePlayerBtn.Text = "Delete Player";
            this.deletePlayerBtn.Click += new System.EventHandler(this.deletePlayerBtn_Click);
            // 
            // playersLbl
            // 
            this.playersLbl.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.playersLbl.AutoSize = true;
            this.playersLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playersLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.playersLbl.Location = new System.Drawing.Point(50, 37);
            this.playersLbl.Name = "playersLbl";
            this.playersLbl.Size = new System.Drawing.Size(47, 15);
            this.playersLbl.TabIndex = 9;
            this.playersLbl.Text = "Players";
            this.playersLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playersGrid
            // 
            this.playersGrid.AllowUserToAddRows = false;
            this.playersGrid.AllowUserToDeleteRows = false;
            this.playersGrid.AllowUserToResizeRows = false;
            this.playersGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.playersGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.playersGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.playersGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.playersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.playersGrid, 2);
            this.playersGrid.Location = new System.Drawing.Point(3, 63);
            this.playersGrid.MultiSelect = false;
            this.playersGrid.Name = "playersGrid";
            this.playersGrid.ReadOnly = true;
            this.playersGrid.RowHeadersVisible = false;
            this.playersGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.playersGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.playersGrid.Size = new System.Drawing.Size(380, 247);
            this.playersGrid.TabIndex = 8;
            this.playersGrid.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.playersGrid_ColumnHeaderMouseClick);
            this.playersGrid.SelectionChanged += new System.EventHandler(this.playersGrid_SelectionChanged);
            // 
            // allCountriesLbl
            // 
            this.allCountriesLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.allCountriesLbl.AutoSize = true;
            this.allCountriesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allCountriesLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allCountriesLbl.Location = new System.Drawing.Point(22, 14);
            this.allCountriesLbl.Name = "allCountriesLbl";
            this.allCountriesLbl.Size = new System.Drawing.Size(91, 18);
            this.allCountriesLbl.TabIndex = 14;
            this.allCountriesLbl.Text = "All Countries";
            this.allCountriesLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createCbx
            // 
            this.createCbx.AutoSize = true;
            this.createCbx.Enabled = false;
            this.createCbx.Location = new System.Drawing.Point(276, 50);
            this.createCbx.Name = "createCbx";
            this.createCbx.Size = new System.Drawing.Size(57, 15);
            this.createCbx.TabIndex = 24;
            this.createCbx.Text = "Create";
            this.createCbx.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.createCbx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.createCbx.UseVisualStyleBackColor = true;
            this.createCbx.CheckedChanged += new System.EventHandler(this.createCbx_CheckedChanged);
            // 
            // CountryView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.createCbx);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.countriesGrid);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.allCountriesLbl);
            this.Name = "CountryView";
            this.Size = new System.Drawing.Size(676, 436);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.countriesGrid)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.playersGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton applyBtn;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroButton clearBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameTbx;
        private MetroFramework.Controls.MetroButton deleteBtn;
        private System.Windows.Forms.DataGridView countriesGrid;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label allCountriesLbl;
        private System.Windows.Forms.Label playersLbl;
        private System.Windows.Forms.DataGridView playersGrid;
        private MetroFramework.Controls.MetroButton deletePlayerBtn;
        private MetroFramework.Controls.MetroCheckBox createCbx;
    }
}
