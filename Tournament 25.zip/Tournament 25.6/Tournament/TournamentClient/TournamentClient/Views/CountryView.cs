﻿using FootballTournament.HelperClasses;
using System.ComponentModel;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Views
{
    public partial class CountryView : UserControl
    {
        private Country _selectedCountry;
        private Player _selectedPlayer;

        Action _action;
        public Action Action
        {
            get => _action;
            set
            {
                _action = value;
                if (value == Action.Create)
                    ClearValues();

                applyBtn.Text = value.ToString();
                createCbx.Checked = value == Action.Create;
            }
        }

        private BindingList<Country> _countries;
        public BindingList<Country> Countries
        {
            set
            {
                _countries = value;
                countriesGrid.DataSource = value;

                if (value == null)
                    return;
                countriesGrid.Columns[nameof(Country.Id)].Visible = false;
                countriesGrid.Columns[nameof(Country.Name)].SortMode = DataGridViewColumnSortMode.Automatic;
                countriesGrid.ClearSelection();
            }
            get
            {
                return _countries;
            }
        }


        public CountryView()
        {
            InitializeComponent();

            Action = Action.Create;
            countriesGrid.ClearSelection();
        }

        private void ClearValues()
        {
            playersGrid.ClearSelection();
            countriesGrid.ClearSelection();
            nameTbx.Text = string.Empty;
        }
        private bool UpdateCountry()
        {
            var tmp = new Country()
            {
                Name = nameTbx.Text,
                Id = _selectedCountry.Id
            };

            var result = AppController.Instance.UpdateCountry(tmp);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully updated country" : result.Item2;
            string title = result.Item1 ? "Country update successful" : "Country update failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private bool CreateNewCountry()
        {
            var country = new Country()
            {
                Name = nameTbx.Text
            };

            var result = AppController.Instance.CreateNewCountry(country);
            MessageBoxIcon icon = result.Item1 ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            string message = result.Item1 ? "Successfully created a new country" : result.Item2;
            string title = result.Item1 ? "Country creation successful" : "Country creation failed";

            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);
            return result.Item1;
        }

        private void applyBtn_Click(object sender, System.EventArgs e)
        {
            bool success = true;
            if (Action == Action.Update)
                success = UpdateCountry();
            else if (Action == Action.Create)
                success = CreateNewCountry();


            if (!success)
                return;
            ClearValues();
        }

        private void clearBtn_Click(object sender, System.EventArgs e)
        {
            playersGrid.ClearSelection();
            ClearValues();
        }

        private void deleteBtn_Click(object sender, System.EventArgs e)
        {
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {_selectedCountry.Name} and all players?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            string countryName = _selectedCountry.Name;

            (success, message) = AppController.Instance.DeleteCountry(_selectedCountry);
            if (success)
                MessageBox.Show($"{countryName} successfully deleted!");
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void countriesGrid_SelectionChanged(object sender, System.EventArgs e)
        {
            _selectedCountry = null;
            //deleteBtn.Enabled = countriesGrid.SelectedRows.Count != 0;

            if (countriesGrid.SelectedRows.Count == 0)
            {
                nameTbx.Text = string.Empty;
                playersGrid.DataSource = new BindingList<Player>();
                Action = Action.Create;
                return;
            }


            if (!(countriesGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Country country))
                return;

            _selectedCountry = country;


            nameTbx.Text = country.Name;
            BindingList<Player> players = new BindingList<Player>(_selectedCountry.Players);

            playersGrid.DataSource = players;
            playersGrid.Columns["CountryID"].Visible = false;
            playersGrid.Columns["Country"].SortMode = DataGridViewColumnSortMode.Automatic;
            playersGrid.Columns["Surname"].SortMode = DataGridViewColumnSortMode.Automatic;
            playersGrid.Columns["Name"].SortMode = DataGridViewColumnSortMode.Automatic;
            playersGrid.Columns["Number"].SortMode = DataGridViewColumnSortMode.Automatic;
            Action = Action.Update;
        }

        private void countriesGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Country>(countriesGrid, e.ColumnIndex, Countries);
        }

        private void playersGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            BindingList<Player> players = new BindingList<Player>(_selectedCountry.Players);
            DataGridViewSorting.Sort(playersGrid, e.ColumnIndex, players);
        }

        private void deletePlayerBtn_Click(object sender, System.EventArgs e)
        {
            if (_selectedPlayer == null)
                return;

            string playerName = $"{_selectedPlayer.Name} {_selectedPlayer.Surname }";
            var dialogResult = MessageBox.Show(
                $"Are you sure you want to delete {playerName}?",
                "Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
                return;

            bool success;
            string message;
            (success, message) = AppController.Instance.DeletePlayer(_selectedPlayer);
            if (success)
            {
                MessageBox.Show($"{playerName} successfully deleted!");
                BindingList<Player> players = new BindingList<Player>(_selectedCountry.Players);
                playersGrid.DataSource = players;
            }
            else
                MessageBox.Show(message, "Delete failed!");
        }

        private void playersGrid_SelectionChanged(object sender, System.EventArgs e)
        {
            _selectedPlayer = null;
            deletePlayerBtn.Enabled = playersGrid.SelectedRows.Count != 0;

            if (playersGrid.SelectedRows.Count == 0)
                return;

            if (!(playersGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is Player player))
                return;

            _selectedPlayer = player;
        }

        private void createCbx_CheckedChanged(object sender, System.EventArgs e)
        {
            Action = createCbx.Checked ? Action.Create : Action.Update;
        }
    }
}
