﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Forms
{
    public partial class CountryForm : MetroForm
    {
        Country _country;
        public CountryForm(Country country = null)
        {
            InitializeComponent();
            if (country == null)
            {
                _country = new Country();
            }
            else
            {
                _country = country;
                countryNameTbx.Text = country.Name;
            }
            playersGV.DataSource = _country.Players;
        }

        private void Players_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            playersGV.DataSource = _country.Players;
        }

        private void playerNumberTbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void addPlayerBtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(numberTbx.Text, out int number))
                return;

            Player newPlayer = new Player()
            {
                Name = nameTbx.Text,
                Surname = surnameTbx.Text,
                Number = number
            };
            _country.Players.Add(newPlayer);
        }

        private void deletePlayerBtn_Click(object sender, EventArgs e)
        {
            List<Player> selectedPlayers = new List<Player>();
            foreach (DataGridViewRow row in playersGV.SelectedRows)
            {
                if (_country.Players.Count < row.Index && row.Index > -1)
                    selectedPlayers.Add(_country.Players[row.Index]);
            }
        }

        private void addCountryBtn_Click(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void playerTbx_TextChanged(object sender, EventArgs e)
        {
            addPlayerBtn.Enabled = 
                !( string.IsNullOrEmpty(nameTbx.Text) ||
                   string.IsNullOrEmpty(surnameTbx.Text) ||
                   string.IsNullOrEmpty(numberTbx.Text));
        }

        private void countryNameTbx_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(countryNameTbx.Text))
            {
                addCountryBtn.Enabled = false;
            }
            else
            {
                addCountryBtn.Enabled = true;

            }
        }

        private void playersGV_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= new KeyPressEventHandler(Column1_KeyPress);
            if (playersGV.CurrentCell.ColumnIndex == 0)
            {
                TextBox tb = e.Control as TextBox;
                if (tb != null)
                {
                    tb.KeyPress += new KeyPressEventHandler(Column1_KeyPress);
                }
            }
        }
        private void Column1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) || !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void playersGV_SelectionChanged(object sender, EventArgs e)
        {
            deletePlayerBtn.Enabled = playersGV.SelectedRows.Count > 0;
        }
    }
}
