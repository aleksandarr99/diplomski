﻿
namespace FootballTournament.Forms
{
    partial class SearchCountryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchTextTbx = new System.Windows.Forms.TextBox();
            this.searchTextLbl = new System.Windows.Forms.Label();
            this.countriesDG = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.countriesDG)).BeginInit();
            this.SuspendLayout();
            // 
            // searchTextTbx
            // 
            this.searchTextTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.searchTextTbx.Location = new System.Drawing.Point(23, 80);
            this.searchTextTbx.Name = "searchTextTbx";
            this.searchTextTbx.Size = new System.Drawing.Size(299, 20);
            this.searchTextTbx.TabIndex = 0;
            this.searchTextTbx.TextChanged += new System.EventHandler(this.searchTextTbx_TextChanged);
            // 
            // searchTextLbl
            // 
            this.searchTextLbl.AutoSize = true;
            this.searchTextLbl.Location = new System.Drawing.Point(20, 64);
            this.searchTextLbl.Name = "searchTextLbl";
            this.searchTextLbl.Size = new System.Drawing.Size(78, 13);
            this.searchTextLbl.TabIndex = 1;
            this.searchTextLbl.Text = "Searching text:";
            // 
            // countriesDG
            // 
            this.countriesDG.AllowUserToAddRows = false;
            this.countriesDG.AllowUserToDeleteRows = false;
            this.countriesDG.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.countriesDG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.countriesDG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.countriesDG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.countriesDG.Location = new System.Drawing.Point(20, 123);
            this.countriesDG.Name = "countriesDG";
            this.countriesDG.Size = new System.Drawing.Size(305, 233);
            this.countriesDG.TabIndex = 2;
            // 
            // SearchCountryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 418);
            this.Controls.Add(this.countriesDG);
            this.Controls.Add(this.searchTextLbl);
            this.Controls.Add(this.searchTextTbx);
            this.MinimumSize = new System.Drawing.Size(345, 418);
            this.Name = "SearchCountryForm";
            this.Text = "Search Country";
            ((System.ComponentModel.ISupportInitialize)(this.countriesDG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox searchTextTbx;
        private System.Windows.Forms.Label searchTextLbl;
        private System.Windows.Forms.DataGridView countriesDG;
    }
}