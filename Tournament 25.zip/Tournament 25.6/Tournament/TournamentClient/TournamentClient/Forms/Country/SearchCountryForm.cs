﻿using MetroFramework.Forms;
using System;
using System.ComponentModel;
using System.Linq;
using TournamentModels;

namespace FootballTournament.Forms
{
    public partial class SearchCountryForm : MetroForm
    {
        public SearchCountryForm()
        {
            InitializeComponent();
            countriesDG.DataSource = AppController.Instance.Countries;
        }

        private void searchTextTbx_TextChanged(object sender, EventArgs e)
        {
            string searchString = searchTextTbx.Text;

            var filtered = AppController.Instance.Countries.Where(
                    x => x.Name.ToLower().Contains(searchString.ToLower())).ToList();
            countriesDG.DataSource = new BindingList<Country>(filtered);
        }
    }
}
