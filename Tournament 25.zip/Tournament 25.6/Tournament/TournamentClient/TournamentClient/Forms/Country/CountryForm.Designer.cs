﻿
namespace FootballTournament.Forms
{
    partial class CountryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.countryNameTbx = new System.Windows.Forms.TextBox();
            this.countryNameLbl = new System.Windows.Forms.Label();
            this.numberTbx = new System.Windows.Forms.TextBox();
            this.nameTbx = new System.Windows.Forms.TextBox();
            this.surnameTbx = new System.Windows.Forms.TextBox();
            this.playerNumberLbl = new System.Windows.Forms.Label();
            this.playerNameLbl = new System.Windows.Forms.Label();
            this.playerSurnameLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.addPlayerBtn = new System.Windows.Forms.Button();
            this.deletePlayerBtn = new System.Windows.Forms.Button();
            this.playersGV = new System.Windows.Forms.DataGridView();
            this.addCountryBtn = new System.Windows.Forms.Button();
            this.creationPlayerPnl = new System.Windows.Forms.Panel();
            this.cancelBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.playersGV)).BeginInit();
            this.creationPlayerPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // countryNameTbx
            // 
            this.countryNameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.countryNameTbx.Location = new System.Drawing.Point(8, 86);
            this.countryNameTbx.Name = "countryNameTbx";
            this.countryNameTbx.Size = new System.Drawing.Size(350, 20);
            this.countryNameTbx.TabIndex = 0;
            this.countryNameTbx.TextChanged += new System.EventHandler(this.countryNameTbx_TextChanged);
            // 
            // countryNameLbl
            // 
            this.countryNameLbl.AutoSize = true;
            this.countryNameLbl.Location = new System.Drawing.Point(5, 70);
            this.countryNameLbl.Name = "countryNameLbl";
            this.countryNameLbl.Size = new System.Drawing.Size(77, 13);
            this.countryNameLbl.TabIndex = 1;
            this.countryNameLbl.Text = "Country Name:";
            // 
            // numberTbx
            // 
            this.numberTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numberTbx.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.numberTbx.Location = new System.Drawing.Point(6, 47);
            this.numberTbx.MaxLength = 3;
            this.numberTbx.Name = "numberTbx";
            this.numberTbx.Size = new System.Drawing.Size(339, 20);
            this.numberTbx.TabIndex = 2;
            this.numberTbx.TextChanged += new System.EventHandler(this.playerTbx_TextChanged);
            this.numberTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.playerNumberTbx_KeyPress);
            // 
            // nameTbx
            // 
            this.nameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nameTbx.Location = new System.Drawing.Point(6, 90);
            this.nameTbx.Name = "nameTbx";
            this.nameTbx.Size = new System.Drawing.Size(339, 20);
            this.nameTbx.TabIndex = 3;
            this.nameTbx.TextChanged += new System.EventHandler(this.playerTbx_TextChanged);
            // 
            // surnameTbx
            // 
            this.surnameTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.surnameTbx.Location = new System.Drawing.Point(6, 131);
            this.surnameTbx.Name = "surnameTbx";
            this.surnameTbx.Size = new System.Drawing.Size(339, 20);
            this.surnameTbx.TabIndex = 4;
            this.surnameTbx.TextChanged += new System.EventHandler(this.playerTbx_TextChanged);
            // 
            // playerNumberLbl
            // 
            this.playerNumberLbl.AutoSize = true;
            this.playerNumberLbl.Location = new System.Drawing.Point(3, 31);
            this.playerNumberLbl.Name = "playerNumberLbl";
            this.playerNumberLbl.Size = new System.Drawing.Size(47, 13);
            this.playerNumberLbl.TabIndex = 5;
            this.playerNumberLbl.Text = "Number:";
            // 
            // playerNameLbl
            // 
            this.playerNameLbl.AutoSize = true;
            this.playerNameLbl.Location = new System.Drawing.Point(3, 74);
            this.playerNameLbl.Name = "playerNameLbl";
            this.playerNameLbl.Size = new System.Drawing.Size(38, 13);
            this.playerNameLbl.TabIndex = 6;
            this.playerNameLbl.Text = "Name:";
            // 
            // playerSurnameLbl
            // 
            this.playerSurnameLbl.AutoSize = true;
            this.playerSurnameLbl.Location = new System.Drawing.Point(3, 115);
            this.playerSurnameLbl.Name = "playerSurnameLbl";
            this.playerSurnameLbl.Size = new System.Drawing.Size(52, 13);
            this.playerSurnameLbl.TabIndex = 7;
            this.playerSurnameLbl.Text = "Surname:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Players";
            // 
            // addPlayerBtn
            // 
            this.addPlayerBtn.Location = new System.Drawing.Point(6, 153);
            this.addPlayerBtn.Name = "addPlayerBtn";
            this.addPlayerBtn.Size = new System.Drawing.Size(114, 23);
            this.addPlayerBtn.TabIndex = 9;
            this.addPlayerBtn.Text = "Add";
            this.addPlayerBtn.UseVisualStyleBackColor = true;
            this.addPlayerBtn.Click += new System.EventHandler(this.addPlayerBtn_Click);
            // 
            // deletePlayerBtn
            // 
            this.deletePlayerBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.deletePlayerBtn.Location = new System.Drawing.Point(231, 153);
            this.deletePlayerBtn.Name = "deletePlayerBtn";
            this.deletePlayerBtn.Size = new System.Drawing.Size(114, 23);
            this.deletePlayerBtn.TabIndex = 10;
            this.deletePlayerBtn.Text = "Delete";
            this.deletePlayerBtn.UseVisualStyleBackColor = true;
            this.deletePlayerBtn.Click += new System.EventHandler(this.deletePlayerBtn_Click);
            // 
            // playersGV
            // 
            this.playersGV.AllowUserToAddRows = false;
            this.playersGV.AllowUserToDeleteRows = false;
            this.playersGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.playersGV.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.playersGV.Location = new System.Drawing.Point(0, 182);
            this.playersGV.Name = "playersGV";
            this.playersGV.Size = new System.Drawing.Size(350, 203);
            this.playersGV.TabIndex = 11;
            this.playersGV.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.playersGV_EditingControlShowing);
            this.playersGV.SelectionChanged += new System.EventHandler(this.playersGV_SelectionChanged);
            // 
            // addCountryBtn
            // 
            this.addCountryBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.addCountryBtn.Location = new System.Drawing.Point(45, 537);
            this.addCountryBtn.Name = "addCountryBtn";
            this.addCountryBtn.Size = new System.Drawing.Size(128, 23);
            this.addCountryBtn.TabIndex = 13;
            this.addCountryBtn.Text = "Add Country";
            this.addCountryBtn.UseVisualStyleBackColor = true;
            this.addCountryBtn.Click += new System.EventHandler(this.addCountryBtn_Click);
            // 
            // creationPlayerPnl
            // 
            this.creationPlayerPnl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.creationPlayerPnl.BackColor = System.Drawing.Color.WhiteSmoke;
            this.creationPlayerPnl.Controls.Add(this.numberTbx);
            this.creationPlayerPnl.Controls.Add(this.playersGV);
            this.creationPlayerPnl.Controls.Add(this.nameTbx);
            this.creationPlayerPnl.Controls.Add(this.deletePlayerBtn);
            this.creationPlayerPnl.Controls.Add(this.surnameTbx);
            this.creationPlayerPnl.Controls.Add(this.addPlayerBtn);
            this.creationPlayerPnl.Controls.Add(this.playerNumberLbl);
            this.creationPlayerPnl.Controls.Add(this.label1);
            this.creationPlayerPnl.Controls.Add(this.playerNameLbl);
            this.creationPlayerPnl.Controls.Add(this.playerSurnameLbl);
            this.creationPlayerPnl.Location = new System.Drawing.Point(8, 136);
            this.creationPlayerPnl.Name = "creationPlayerPnl";
            this.creationPlayerPnl.Size = new System.Drawing.Size(350, 385);
            this.creationPlayerPnl.TabIndex = 14;
            // 
            // cancelBtn
            // 
            this.cancelBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cancelBtn.Location = new System.Drawing.Point(186, 537);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(128, 23);
            this.cancelBtn.TabIndex = 15;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // CountryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 583);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.addCountryBtn);
            this.Controls.Add(this.countryNameLbl);
            this.Controls.Add(this.countryNameTbx);
            this.Controls.Add(this.creationPlayerPnl);
            this.MinimumSize = new System.Drawing.Size(366, 583);
            this.Name = "CountryForm";
            this.Text = "Country";
            ((System.ComponentModel.ISupportInitialize)(this.playersGV)).EndInit();
            this.creationPlayerPnl.ResumeLayout(false);
            this.creationPlayerPnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox countryNameTbx;
        private System.Windows.Forms.Label countryNameLbl;
        private System.Windows.Forms.TextBox numberTbx;
        private System.Windows.Forms.TextBox nameTbx;
        private System.Windows.Forms.TextBox surnameTbx;
        private System.Windows.Forms.Label playerNumberLbl;
        private System.Windows.Forms.Label playerNameLbl;
        private System.Windows.Forms.Label playerSurnameLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addPlayerBtn;
        private System.Windows.Forms.Button deletePlayerBtn;
        private System.Windows.Forms.DataGridView playersGV;
        private System.Windows.Forms.Button addCountryBtn;
        private System.Windows.Forms.Panel creationPlayerPnl;
        private System.Windows.Forms.Button cancelBtn;
    }
}