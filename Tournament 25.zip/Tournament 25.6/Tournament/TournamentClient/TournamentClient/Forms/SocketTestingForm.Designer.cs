﻿
namespace FootballTournament.Forms
{
    partial class SocketTestingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.receivedMessageLbx = new System.Windows.Forms.ListBox();
            this.receivedLbl = new MetroFramework.Controls.MetroLabel();
            this.messageTbx = new System.Windows.Forms.TextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.myMessagesLbx = new System.Windows.Forms.ListBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.SuspendLayout();
            // 
            // receivedMessageLbx
            // 
            this.receivedMessageLbx.FormattingEnabled = true;
            this.receivedMessageLbx.Location = new System.Drawing.Point(299, 186);
            this.receivedMessageLbx.Name = "receivedMessageLbx";
            this.receivedMessageLbx.Size = new System.Drawing.Size(274, 329);
            this.receivedMessageLbx.TabIndex = 0;
            // 
            // receivedLbl
            // 
            this.receivedLbl.AutoSize = true;
            this.receivedLbl.Location = new System.Drawing.Point(299, 164);
            this.receivedLbl.Name = "receivedLbl";
            this.receivedLbl.Size = new System.Drawing.Size(116, 19);
            this.receivedLbl.TabIndex = 5;
            this.receivedLbl.Text = "Received message";
            // 
            // messageTbx
            // 
            this.messageTbx.Location = new System.Drawing.Point(23, 102);
            this.messageTbx.Name = "messageTbx";
            this.messageTbx.Size = new System.Drawing.Size(540, 20);
            this.messageTbx.TabIndex = 1;
            this.messageTbx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.messageTbx_KeyDown);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 80);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(90, 19);
            this.metroLabel1.TabIndex = 3;
            this.metroLabel1.Text = "New message";
            // 
            // myMessagesLbx
            // 
            this.myMessagesLbx.FormattingEnabled = true;
            this.myMessagesLbx.Location = new System.Drawing.Point(23, 186);
            this.myMessagesLbx.Name = "myMessagesLbx";
            this.myMessagesLbx.Size = new System.Drawing.Size(248, 329);
            this.myMessagesLbx.TabIndex = 2;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 164);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(87, 19);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "My messages";
            // 
            // SocketTestingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 538);
            this.Controls.Add(this.receivedLbl);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.myMessagesLbx);
            this.Controls.Add(this.messageTbx);
            this.Controls.Add(this.receivedMessageLbx);
            this.Name = "SocketTestingForm";
            this.Text = "SocketTestingForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SocketTestingForm_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox receivedMessageLbx;
        private MetroFramework.Controls.MetroLabel receivedLbl;
        private System.Windows.Forms.TextBox messageTbx;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.ListBox myMessagesLbx;
        private MetroFramework.Controls.MetroLabel metroLabel2;
    }
}