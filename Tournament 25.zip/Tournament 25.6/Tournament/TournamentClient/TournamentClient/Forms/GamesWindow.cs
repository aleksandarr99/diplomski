﻿using FootballTournament.Controls;
using MetroFramework.Forms;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Forms
{
    public partial class GamesWindow : MetroForm
    {
        private Dictionary<int, List<GameControl>> _stageTables = new Dictionary<int, List<GameControl>>();

        private Tournament _tournament;

        public GamesWindow(Tournament tournament)
        {
            _tournament = tournament;
            InitializeComponent();

            confirmResultsBtn.Enabled = _tournament.WinnerName != "Unknown";
        }

        private void GamesWindow_Load(object sender, System.EventArgs e)
        {
            Text = $"{_tournament.Name} ({_tournament.City})";
            descriptionLbl.Text = string.IsNullOrEmpty(_tournament.Description) ? "" : "Description: " + _tournament.Description;
            errorLbl.Text = "";
            RecreateGameControls();
        }

        private void GameControl_ResultChanged(GameControl sender)
        {
            errorLbl.Text = "";
            confirmResultsBtn.Enabled = true;
            confirmResultsBtn.Visible = !string.IsNullOrEmpty(_tournament.WinnerName);
        }

        private void RecreateGameControls()
        {
            _stageTables.Clear();
            mainPanel.Controls.Clear();
            var tournamentGames = AppController.Instance.Games.ToList().FindAll(x => x.TournamentID == _tournament.Id);
            if (tournamentGames.Count == 0)
            {
                var result = AppController.Instance.CreateTournamentGames(_tournament);
                if (result.Item1 == null)
                {
                    MessageBox.Show(result.Item2, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Abort;
                }
                tournamentGames = result.Item1;
            }

            var stages = tournamentGames
                .GroupBy(g => g.Stage)
                .Select(group => new { Stage = group.Key, Games = group.Select(x => x).ToList() })
                .OrderByDescending(x => x.Stage).ToList();

            for (int i = 0; i < stages.Count; i++)
            {
                var stage = stages[i];
                var stageCount = stage.Games.Count;
                var yLocation = (stages[0].Games.Count - stageCount) / 2.0 * GameControl.ControlHeight;
                var xLocation = 440 * i;

                TableLayoutPanel newPanel = new TableLayoutPanel
                {
                    Width = 440,
                    Location = new Point(xLocation, (int)yLocation),
                    RowCount = stages[i].Stage,
                    Height = GameControl.ControlHeight * stageCount
                };

                mainPanel.Controls.Add(newPanel);
                var controlList = new List<GameControl>();

                newPanel.RowCount = stageCount;

                int j = 0;
                for (j = 0; j < stageCount; j++)
                {
                    var game = stage.Games[j];
                    GameControl gameControl = new GameControl(game);
                    gameControl.ResultChanged += GameControl_ResultChanged;


                    newPanel.Controls.Add(gameControl, 0, j);
                    controlList.Add(gameControl);
                }

                _stageTables.Add(stages[i].Stage, controlList);
            }
        }

        private void confirmResultsBtn_Click(object sender, System.EventArgs e)
        {
            if (!CheckResults())
                return;

            if (!UpdateCurrentStage())
                return;

            var lastStage = _stageTables.Last();
            bool final = lastStage.Key == 1;
            if (final)
            {
                _tournament.WinnerName = lastStage.Value[0].Game.Winner?.Name;
                var result = AppController.Instance.UpdateTournament(_tournament);

                if (result.Item1)
                    confirmResultsBtn.Enabled = false;
            }
            else
            {
                AppController.Instance.CreateNextStage(_tournament);
            }
            RecreateGameControls();
        }

        private bool UpdateCurrentStage()
        {
            var lastStage = _stageTables.Last();
            var gamesToUpdate = lastStage.Value.Select(x =>
                new Game()
                {
                    Id = x.Game.Id,
                    FirstTeamScore = x.FirstScore,
                    SecondTeamScore = x.SecondScore,

                    FirstTeamID = x.Game.FirstTeamID,
                    SecondTeamID = x.Game.SecondTeamID,
                    TournamentID = x.Game.TournamentID,
                    RefereeID = x.Game.RefereeID,

                    Stage = x.Game.Stage
                }).ToList();
            var result = AppController.Instance.UpdateGames(gamesToUpdate);

            if (!result.Item1)
                MessageBox.Show(result.Item2, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return result.Item1;
        }
        private bool CheckResults()
        {
            var lastStage = _stageTables.Last();
            Game game = null;
            foreach (var control in lastStage.Value)
            {
                if (control.Valid)
                    continue;

                game = control.Game;
                break;
            }
            if (game == null)
                return true;
            errorLbl.Text = $"{game.FirstTeam.Name} - {game.SecondTeam.Name} game must have a winner!";
            confirmResultsBtn.Enabled = false;
            return false;
        }
    }
}
