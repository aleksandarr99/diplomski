﻿
namespace FootballTournament.Forms
{
    partial class UniversalSearchForm<T>
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.searchTextLbl = new System.Windows.Forms.Label();
            this.searchTextTbx = new System.Windows.Forms.TextBox();
            this.selectBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGrid
            // 
            this.dataGrid.AllowUserToAddRows = false;
            this.dataGrid.AllowUserToDeleteRows = false;
            this.dataGrid.AllowUserToResizeRows = false;
            this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(8, 152);
            this.dataGrid.MultiSelect = false;
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.ReadOnly = true;
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGrid.Size = new System.Drawing.Size(302, 243);
            this.dataGrid.TabIndex = 5;
            this.dataGrid.SelectionChanged += new System.EventHandler(this.dataGrid_SelectionChanged);
            // 
            // searchTextLbl
            // 
            this.searchTextLbl.AutoSize = true;
            this.searchTextLbl.Location = new System.Drawing.Point(8, 93);
            this.searchTextLbl.Name = "searchTextLbl";
            this.searchTextLbl.Size = new System.Drawing.Size(78, 13);
            this.searchTextLbl.TabIndex = 4;
            this.searchTextLbl.Text = "Searching text:";
            // 
            // searchTextTbx
            // 
            this.searchTextTbx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.searchTextTbx.Location = new System.Drawing.Point(11, 109);
            this.searchTextTbx.Name = "searchTextTbx";
            this.searchTextTbx.Size = new System.Drawing.Size(296, 20);
            this.searchTextTbx.TabIndex = 3;
            this.searchTextTbx.TextChanged += new System.EventHandler(this.searchTextTbx_TextChanged);
            this.searchTextTbx.KeyUp += new System.Windows.Forms.KeyEventHandler(this.searchTextTbx_KeyUp);
            // 
            // selectBtn
            // 
            this.selectBtn.Location = new System.Drawing.Point(102, 404);
            this.selectBtn.Name = "selectBtn";
            this.selectBtn.Size = new System.Drawing.Size(114, 23);
            this.selectBtn.TabIndex = 10;
            this.selectBtn.Text = "Select";
            this.selectBtn.UseVisualStyleBackColor = true;
            this.selectBtn.Click += new System.EventHandler(this.selectBtn_Click);
            // 
            // UniversalSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(322, 450);
            this.Controls.Add(this.selectBtn);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.searchTextLbl);
            this.Controls.Add(this.searchTextTbx);
            this.MinimumSize = new System.Drawing.Size(322, 450);
            this.Name = "UniversalSearchForm";
            this.Text = "Search";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.Label searchTextLbl;
        private System.Windows.Forms.TextBox searchTextTbx;
        private System.Windows.Forms.Button selectBtn;
    }
}