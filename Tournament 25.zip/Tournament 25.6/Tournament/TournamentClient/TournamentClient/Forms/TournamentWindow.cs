﻿using FootballTournament.HelperClasses;
using MetroFramework.Forms;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Forms
{
    public partial class TournamentWindow : MetroForm
    {
        private static readonly string colorTie = "#f9fcd2";
        private static readonly string colorWin = "#d8fcd2";
        private static readonly string colorDefeat = "#fcd2d2";
        private BindingList<Game> _games;
        private Tournament _tournament;
        private Country _firstTeam;
        private Country _secondTeam;
        private Referee _referee;
        private int _firstScore;
        private int _secondScore;

        public TournamentWindow(Tournament tournament)
        {
            _tournament = tournament;

            InitializeComponent();

            Clear();
            Text = $"{tournament.Name} ({tournament.City})";
            descriptionLbl.Text = "Description: " + tournament.Description;

            RefreshGamesGrid();
        }

        private void RefreshGamesGrid()
        {
            var tournamentGames = AppController.Instance.Games.ToList().FindAll(x => x.TournamentID == _tournament.Id);
            _games = new BindingList<Game>(tournamentGames);

            gamesGrid.DataSource = _games;
            gamesGrid.Columns[nameof(Game.FirstTeamID)].Visible = false;
            gamesGrid.Columns[nameof(Game.SecondTeamID)].Visible = false;
            gamesGrid.Columns[nameof(Game.RefereeID)].Visible = false;
            gamesGrid.Columns[nameof(Game.TournamentID)].Visible = false;
            gamesGrid.Columns[nameof(Game.FirstTeamID)].Visible = false;
            gamesGrid.Columns[nameof(Game.Id)].Visible = false;
            gamesGrid.Columns[nameof(Game.Tournament)].Visible = false;


            gamesGrid.Columns[nameof(Game.FirstTeam)].SortMode = DataGridViewColumnSortMode.Automatic;
            gamesGrid.Columns[nameof(Game.FirstTeam)].HeaderText = "First";
            gamesGrid.Columns[nameof(Game.SecondTeam)].SortMode = DataGridViewColumnSortMode.Automatic;
            gamesGrid.Columns[nameof(Game.SecondTeam)].HeaderText = "Second";
            gamesGrid.Columns[nameof(Game.Referee)].SortMode = DataGridViewColumnSortMode.Automatic;
            gamesGrid.Columns[nameof(Game.FirstTeamScore)].SortMode = DataGridViewColumnSortMode.Automatic;
            gamesGrid.Columns[nameof(Game.FirstTeamScore)].HeaderText = "";
            gamesGrid.Columns[nameof(Game.SecondTeamScore)].SortMode = DataGridViewColumnSortMode.Automatic;
            gamesGrid.Columns[nameof(Game.SecondTeamScore)].HeaderText = "";
        }


        private bool ValidateValues()
        {
            if (_referee == null)
                return false;
            if (_firstTeam == null || _secondTeam == null)
                return false;
            return true;
        }

        private void Clear()
        {
            _secondTeam = _firstTeam = null;
            _referee = null;
            _firstScore = _secondScore = 0;
            firstTeamScoreTbx.Text = secondTeamScoreTbx.Text = "0";
            firstTeamTbx.Text = secondTeamTbx.Text = string.Empty;
        }

        private void Tbx_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void firstTeamTbx_Click(object sender, System.EventArgs e)
        {
            UniversalSearchForm<Country> universalSearchForm = new UniversalSearchForm<Country>();
            universalSearchForm.ShowDialog();

            if (universalSearchForm.DialogResult != DialogResult.OK)
                return;

            var selectedCountry = universalSearchForm.SelectedItem;
            bool first = sender == firstTeamTbx;
            bool second = sender == secondTeamTbx;

            bool allow = (first && (_secondTeam == null || _secondTeam.Id != selectedCountry.Id))
                      || (second && (_firstTeam == null ||  _firstTeam.Id != selectedCountry.Id));

            if (first && allow)
            {
                firstTeamTbx.Text = selectedCountry.ToString();
                _firstTeam = selectedCountry;
            }
            else if (second && allow)
            {
                secondTeamTbx.Text = selectedCountry.ToString();
                _secondTeam = selectedCountry;
            }
            else
            {
                MessageBox.Show("Selected teams cannot be the same", "Invalid Team Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void TeamScoreTbx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
                e.Handled = true;
        }

        private void firstTeamScoreTbx_TextChanged(object sender, System.EventArgs e)
        {
            if (int.TryParse(firstTeamScoreTbx.Text, out int result))
                _firstScore = result;
            else
                _firstScore = 0;
        }


        private void secondTeamScoreTbx_TextChanged(object sender, System.EventArgs e)
        {
            if (int.TryParse(secondTeamScoreTbx.Text, out int result))
                _secondScore = result;
            else
                _secondScore = 0;
        }

        private void refereeTbx_Click(object sender, System.EventArgs e)
        {
            UniversalSearchForm<Referee> universalSearchForm = new UniversalSearchForm<Referee>();
            universalSearchForm.ShowDialog();

            if (universalSearchForm.DialogResult != DialogResult.OK)
                return;

            _referee = universalSearchForm.SelectedItem;
            refereeTbx.Text = _referee.ToString();
        }


        private void clearBtn_Click(object sender, System.EventArgs e)
        {
            Clear();
        }

        private void createBtn_Click(object sender, System.EventArgs e)
        {
            if (!ValidateValues())
                return;

            Game newGame = new Game()
            {
                FirstTeam = _firstTeam,
                SecondTeam = _secondTeam,
                FirstTeamScore = _firstScore,
                SecondTeamScore = _secondScore,
                FirstTeamID = _firstTeam.Id,
                SecondTeamID = _secondTeam.Id,
                Tournament = _tournament,
                TournamentID = _tournament.Id,
                Referee = _referee,
                RefereeID = _referee.Id
            };
            bool success;
            string message;
            (success, message) = AppController.Instance.CreateNewGame(newGame);

            MessageBoxIcon icon = success ? MessageBoxIcon.Information : MessageBoxIcon.Error;
            message = success ? "Successfully updated tournament" : message;
            string title = success ? "Tournament update successful" : "Tournament update failed";
            MessageBox.Show(message, title, MessageBoxButtons.OK, icon);

            if (success)
                RefreshGamesGrid();
        }

        private void gamesGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewSorting.Sort<Game>(gamesGrid, e.ColumnIndex, _games);
        }

        private void gamesGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            var game = _games[e.RowIndex];

            // column indexes
            var first = gamesGrid.Columns.IndexOf(gamesGrid.Columns[nameof(Game.FirstTeam)]);
            var firstScore = gamesGrid.Columns.IndexOf(gamesGrid.Columns[nameof(Game.FirstTeamScore)]);
            var second = gamesGrid.Columns.IndexOf(gamesGrid.Columns[nameof(Game.SecondTeam)]);
            var secondScore = gamesGrid.Columns.IndexOf(gamesGrid.Columns[nameof(Game.SecondTeamScore)]);
            var column = e.ColumnIndex;

            bool firstTeam = column == first || column == firstScore;
            bool secondTeam = column == second || column == secondScore;

            if (!firstTeam && !secondTeam)
                return;

            e.CellStyle.BackColor = ColorTranslator.FromHtml(colorTie);
            //First team win
            if (game.FirstTeamScore > game.SecondTeamScore)
            {
                if (firstTeam)
                    e.CellStyle.BackColor = ColorTranslator.FromHtml(colorWin);
                else
                    e.CellStyle.BackColor = ColorTranslator.FromHtml(colorDefeat);
            }
            //Second team win
            else if (game.FirstTeamScore < game.SecondTeamScore)
            {
                if (secondTeam)
                    e.CellStyle.BackColor = ColorTranslator.FromHtml(colorWin);
                else
                    e.CellStyle.BackColor = ColorTranslator.FromHtml(colorDefeat);
            }
        }
    }
}
