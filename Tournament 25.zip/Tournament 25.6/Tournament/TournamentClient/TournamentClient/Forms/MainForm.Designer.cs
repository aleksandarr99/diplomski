﻿
namespace FootballTournament.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewsPanel = new System.Windows.Forms.Panel();
            this.refereeBtn = new System.Windows.Forms.Button();
            this.tournamentsBtn = new System.Windows.Forms.Button();
            this.adminsBtn = new System.Windows.Forms.Button();
            this.countriesBtn = new System.Windows.Forms.Button();
            this.playersBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.activeViewLbl = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.playerView = new FootballTournament.Views.PlayerView();
            this.tournamentView = new FootballTournament.Views.TournamentView();
            this.adminView = new FootballTournament.Views.AdminView();
            this.refereeView = new FootballTournament.Views.RefereeView();
            this.countryView = new FootballTournament.Views.CountryView();
            this.viewsPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // viewsPanel
            // 
            this.viewsPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.viewsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.viewsPanel.Controls.Add(this.refereeBtn);
            this.viewsPanel.Controls.Add(this.tournamentsBtn);
            this.viewsPanel.Controls.Add(this.adminsBtn);
            this.viewsPanel.Controls.Add(this.countriesBtn);
            this.viewsPanel.Controls.Add(this.playersBtn);
            this.viewsPanel.Location = new System.Drawing.Point(1, 112);
            this.viewsPanel.MinimumSize = new System.Drawing.Size(0, 300);
            this.viewsPanel.Name = "viewsPanel";
            this.viewsPanel.Size = new System.Drawing.Size(91, 470);
            this.viewsPanel.TabIndex = 1;
            // 
            // refereeBtn
            // 
            this.refereeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.refereeBtn.BackColor = System.Drawing.Color.White;
            this.refereeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.refereeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refereeBtn.ForeColor = System.Drawing.Color.Black;
            this.refereeBtn.Location = new System.Drawing.Point(7, 147);
            this.refereeBtn.Name = "refereeBtn";
            this.refereeBtn.Size = new System.Drawing.Size(76, 40);
            this.refereeBtn.TabIndex = 3;
            this.refereeBtn.Text = "Referee";
            this.refereeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.refereeBtn.UseVisualStyleBackColor = false;
            this.refereeBtn.Click += new System.EventHandler(this.activeViewBtn_Click);
            // 
            // tournamentsBtn
            // 
            this.tournamentsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tournamentsBtn.BackColor = System.Drawing.Color.White;
            this.tournamentsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tournamentsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tournamentsBtn.ForeColor = System.Drawing.Color.Black;
            this.tournamentsBtn.Image = global::FootballTournament.Properties.Resources.icons8_trophy_24;
            this.tournamentsBtn.Location = new System.Drawing.Point(7, 9);
            this.tournamentsBtn.Name = "tournamentsBtn";
            this.tournamentsBtn.Size = new System.Drawing.Size(76, 40);
            this.tournamentsBtn.TabIndex = 0;
            this.tournamentsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tournamentsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.tournamentsBtn.UseVisualStyleBackColor = false;
            this.tournamentsBtn.Click += new System.EventHandler(this.activeViewBtn_Click);
            // 
            // adminsBtn
            // 
            this.adminsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.adminsBtn.BackColor = System.Drawing.Color.White;
            this.adminsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.adminsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminsBtn.ForeColor = System.Drawing.Color.Black;
            this.adminsBtn.Location = new System.Drawing.Point(7, 421);
            this.adminsBtn.Name = "adminsBtn";
            this.adminsBtn.Size = new System.Drawing.Size(76, 40);
            this.adminsBtn.TabIndex = 4;
            this.adminsBtn.Text = "Admins";
            this.adminsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.adminsBtn.UseVisualStyleBackColor = false;
            this.adminsBtn.Click += new System.EventHandler(this.activeViewBtn_Click);
            // 
            // countriesBtn
            // 
            this.countriesBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.countriesBtn.BackColor = System.Drawing.Color.White;
            this.countriesBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.countriesBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countriesBtn.ForeColor = System.Drawing.Color.Black;
            this.countriesBtn.Location = new System.Drawing.Point(7, 101);
            this.countriesBtn.Name = "countriesBtn";
            this.countriesBtn.Size = new System.Drawing.Size(76, 40);
            this.countriesBtn.TabIndex = 2;
            this.countriesBtn.Text = "Countries";
            this.countriesBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.countriesBtn.UseVisualStyleBackColor = false;
            this.countriesBtn.Click += new System.EventHandler(this.activeViewBtn_Click);
            // 
            // playersBtn
            // 
            this.playersBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.playersBtn.BackColor = System.Drawing.Color.White;
            this.playersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playersBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playersBtn.ForeColor = System.Drawing.Color.Black;
            this.playersBtn.Location = new System.Drawing.Point(7, 55);
            this.playersBtn.Name = "playersBtn";
            this.playersBtn.Size = new System.Drawing.Size(76, 40);
            this.playersBtn.TabIndex = 1;
            this.playersBtn.Text = "Players";
            this.playersBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.playersBtn.UseVisualStyleBackColor = false;
            this.playersBtn.Click += new System.EventHandler(this.activeViewBtn_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.activeViewLbl);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(98, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(779, 657);
            this.panel1.TabIndex = 2;
            // 
            // activeViewLbl
            // 
            this.activeViewLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.activeViewLbl.AutoSize = true;
            this.activeViewLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.activeViewLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.activeViewLbl.Location = new System.Drawing.Point(272, 9);
            this.activeViewLbl.Name = "activeViewLbl";
            this.activeViewLbl.Size = new System.Drawing.Size(71, 24);
            this.activeViewLbl.TabIndex = 1;
            this.activeViewLbl.Text = "Players";
            this.activeViewLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.playerView);
            this.panel2.Controls.Add(this.tournamentView);
            this.panel2.Controls.Add(this.adminView);
            this.panel2.Controls.Add(this.refereeView);
            this.panel2.Controls.Add(this.countryView);
            this.panel2.Location = new System.Drawing.Point(3, 49);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(773, 605);
            this.panel2.TabIndex = 0;
            // 
            // playerView
            // 
            this.playerView.Action = FootballTournament.Action.Create;
            this.playerView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.playerView.Location = new System.Drawing.Point(0, 0);
            this.playerView.Name = "playerView";
            this.playerView.Players = null;
            this.playerView.Size = new System.Drawing.Size(773, 605);
            this.playerView.TabIndex = 5;
            this.playerView.Visible = false;
            // 
            // tournamentView
            // 
            this.tournamentView.Action = FootballTournament.Action.Create;
            this.tournamentView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tournamentView.Location = new System.Drawing.Point(0, 0);
            this.tournamentView.Name = "tournamentView";
            this.tournamentView.Size = new System.Drawing.Size(773, 605);
            this.tournamentView.TabIndex = 4;
            this.tournamentView.Tournaments = null;
            this.tournamentView.Visible = false;
            // 
            // adminView
            // 
            this.adminView.Action = FootballTournament.Action.Create;
            this.adminView.Admins = null;
            this.adminView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adminView.Location = new System.Drawing.Point(0, 0);
            this.adminView.Name = "adminView";
            this.adminView.Size = new System.Drawing.Size(773, 605);
            this.adminView.TabIndex = 3;
            this.adminView.Visible = false;
            // 
            // refereeView
            // 
            this.refereeView.Action = FootballTournament.Action.Create;
            this.refereeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.refereeView.Location = new System.Drawing.Point(0, 0);
            this.refereeView.Name = "refereeView";
            this.refereeView.Referees = null;
            this.refereeView.Size = new System.Drawing.Size(773, 605);
            this.refereeView.TabIndex = 2;
            this.refereeView.Visible = false;
            // 
            // countryView
            // 
            this.countryView.Action = FootballTournament.Action.Create;
            this.countryView.Countries = null;
            this.countryView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.countryView.Location = new System.Drawing.Point(0, 0);
            this.countryView.Name = "countryView";
            this.countryView.Size = new System.Drawing.Size(773, 605);
            this.countryView.TabIndex = 1;
            this.countryView.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(900, 700);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.viewsPanel);
            this.MinimumSize = new System.Drawing.Size(900, 700);
            this.Name = "MainForm";
            this.Text = "Football Tournament";
            this.viewsPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button playersBtn;
        private System.Windows.Forms.Panel viewsPanel;
        private System.Windows.Forms.Button refereeBtn;
        private System.Windows.Forms.Button tournamentsBtn;
        private System.Windows.Forms.Button adminsBtn;
        private System.Windows.Forms.Button countriesBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label activeViewLbl;
        private System.Windows.Forms.Panel panel2;
        private Views.CountryView countryView;
        private Views.RefereeView refereeView;
        private Views.AdminView adminView;
        private Views.TournamentView tournamentView;
        private Views.PlayerView playerView;
    }
}