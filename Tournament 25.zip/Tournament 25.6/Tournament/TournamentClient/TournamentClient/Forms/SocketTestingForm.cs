﻿using CommunicationModule;
using MetroFramework.Forms;
using System;
using System.ComponentModel;

namespace FootballTournament.Forms
{
    public partial class SocketTestingForm : MetroForm
    {
        private SocketClient _client;
        public SocketTestingForm()
        {
            InitializeComponent();
            _client = new SocketClient("localhost", 1234);
            _client.Connect();
        }


        private void messageTbx_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == System.Windows.Forms.Keys.Enter)
            {
                string message = messageTbx.Text;
                messageTbx.Text = string.Empty;

                myMessagesLbx.Items.Add(message);
                try
                {
                    //var receivedMessage = _client.SendMessage(message);
                    //receivedMessageLbx.Items.Add(receivedMessage);

                }
                catch (Exception)
                {
                }
            }
        }

        private void SocketTestingForm_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            _client.Disconnect();
        }
    }
}
