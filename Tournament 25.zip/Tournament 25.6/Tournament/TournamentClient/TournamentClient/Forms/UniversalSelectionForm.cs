﻿using MetroFramework.Forms;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace FootballTournament.Forms
{
    public partial class UniversalMultiSelectForm<T>
        : MetroForm
    {
        private int _requestedNumber { get; set; } = 1;
        BindingList<T> _sourceList;
        public BindingList<T> SelectedItems { get; set; }

        public UniversalMultiSelectForm(int requestedNumber = 1, BindingList<T> alreadySelected = null)
        {
            InitializeComponent();

            _requestedNumber = requestedNumber;
            infoLbl.Text = $"Selecte { requestedNumber } more items.";

            var type = typeof(T);
            Text = $"{ type.Name }s Selection";

            var items = AppController.Instance.GetItems<T>();
            _sourceList = new BindingList<T>();
            foreach (var item in items)
                _sourceList.Add(item);

            sourceDG.DataSource = _sourceList;

            SelectedItems = new BindingList<T>();

            SelectedItems.ListChanged += SelectedItems_ListChanged;
            if (alreadySelected != null)
                foreach (var item in alreadySelected)
                {
                    SelectedItems.Add(item);
                    _sourceList.Remove(item);
                }
            selectedItemsDG.DataSource = SelectedItems;
            confirmBtn.Enabled = SelectedItems.Count == _requestedNumber;
            TryToHideIDColumn();
        }

        private void SelectedItems_ListChanged(object sender, ListChangedEventArgs e)
        {
            int x = _requestedNumber - SelectedItems.Count;
            bool selectionFinished = x == 0;
            confirmBtn.Enabled = selectionFinished;
            infoLbl.Visible = !selectionFinished;
            selectBtn.Enabled = !selectionFinished;
            infoLbl.Text = $"Selecte { x } more items.";
        }

        private void TryToHideIDColumn()
        {
            try
            {
                sourceDG.Columns["ID"].Visible = false;
                selectedItemsDG.Columns["ID"].Visible = false;
            }
            catch
            { }
        }

        private void sourceDG_SelectionChanged(object sender, EventArgs e)
        {
            selectBtn.Enabled = sourceDG.SelectedRows.Count != 0;
        }

        private void selectedItemsDG_SelectionChanged(object sender, EventArgs e)
        {
            deselectBtn.Enabled = selectedItemsDG.SelectedRows.Count != 0;
        }

        private void selectBtn_Click(object sender, EventArgs e)
        {
            T selected = GetSelectedItem(sourceDG);
            if (selected == null)
                return;

            _sourceList.Remove(selected);
            SelectedItems.Add(selected);
        }

        private void deselectBtn_Click(object sender, EventArgs e)
        {
            T selected = GetSelectedItem(selectedItemsDG);
            if (selected == null)
                return;

            SelectedItems.Remove(selected);
            _sourceList.Add(selected);
        }

        private T GetSelectedItem(DataGridView dataGrid)
        {
            if (dataGrid.SelectedRows.Count == 0)
                return default;

            if (!(dataGrid.SelectedRows[0] is DataGridViewRow row))
                return default;

            if (!(row.DataBoundItem is T selected))
                return default;
            return selected;
        }

        private void confirmBtn_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
