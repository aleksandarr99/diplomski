﻿using MetroFramework.Forms;
using System.Drawing;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament.Forms
{
    public partial class MainForm : MetroForm
    {
        private static readonly string selectedBackColor = "#0078d7";
        private static readonly string selectedForeColor = "#FFFFFF";

        private static readonly string unselectedBackColor = "#FFFFFF";
        private static readonly string unselectedForeColor = "#111111";

        private ActiveViews _activeView;
        public ActiveViews ActiveView
        {
            get => _activeView;
            set
            {
                if (_activeView == value)
                    return;
                _activeView = value;

                ChangeViewButtonsColor();
                ChangeActiveViewLabel();
                ChangeActiveView();

            }
        }

        public MainForm()
        {
            InitializeComponent();

            InitializeBtnTags();

            playerView.Players = AppController.Instance.GetItems<Player>();
            ActiveView = ActiveViews.Tournaments;

            ChangeViewButtonsColor();
            ChangeActiveViewLabel();
            ChangeActiveView();
        }

        private void InitializeBtnTags()
        {
            playersBtn.Tag = ActiveViews.Players;
            countriesBtn.Tag = ActiveViews.Countries;
            tournamentsBtn.Tag = ActiveViews.Tournaments;
            refereeBtn.Tag = ActiveViews.Referees;
            adminsBtn.Tag = ActiveViews.Admins;
        }

        private void ChangeActiveViewLabel()
        {
            activeViewLbl.Text = ActiveView.ToString();
        }

        private void ChangeActiveView()
        {
            switch (ActiveView)
            {
                case ActiveViews.Players:
                    playerView.Players = AppController.Instance.GetItems<Player>();
                    break;
                case ActiveViews.Countries:
                    countryView.Countries = AppController.Instance.GetItems<Country>();
                    break;
                case ActiveViews.Referees:
                    refereeView.Referees = AppController.Instance.GetItems<Referee>();
                    break;
                case ActiveViews.Admins:
                    adminView.Admins = AppController.Instance.GetItems<Admin>();
                    break;
                case ActiveViews.Tournaments:
                    tournamentView.Tournaments = AppController.Instance.GetItems<Tournament>();
                    break;
            }
            playerView.Visible = ActiveView == ActiveViews.Players;
            countryView.Visible = ActiveView == ActiveViews.Countries;
            refereeView.Visible = ActiveView == ActiveViews.Referees;
            adminView.Visible = ActiveView == ActiveViews.Admins;
            tournamentView.Visible = ActiveView == ActiveViews.Tournaments;
        }

        private void ChangeViewButtonsColor()
        {
            foreach (var control in viewsPanel.Controls)
            {
                if (!(control is Button button))
                    continue;
                if (!(button.Tag is ActiveViews buttonView))
                    continue;


                string btnColorCode = buttonView == ActiveView
                    ? selectedBackColor
                    : unselectedBackColor;
                string btnForeColor = buttonView == ActiveView
                    ? selectedForeColor
                    : unselectedForeColor;
                button.ForeColor = ColorTranslator.FromHtml(btnForeColor);
                button.BackColor = ColorTranslator.FromHtml(btnColorCode);
            }
        }


        private void activeViewBtn_Click(object sender, System.EventArgs e)
        {
            Button selectedButton = (Button)sender;
            ActiveViews activeView = (ActiveViews)selectedButton.Tag;
            ActiveView = activeView;
        }


    }
}
