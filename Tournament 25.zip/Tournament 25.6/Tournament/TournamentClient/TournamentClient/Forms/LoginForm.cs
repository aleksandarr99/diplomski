﻿using MetroFramework.Forms;
using System;
using System.Windows.Forms;

namespace FootballTournament.Forms
{
    public partial class LoginForm : MetroForm
    {
        public LoginForm()
        {
            InitializeComponent();
            usernameTbx.Text = "admin";
            passwordTbx.Text = "admin";


//            loginBtn.Enabled = false;
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            TryLogin();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void usernameTbx_TextChanged(object sender, EventArgs e)
        {
            loginBtn.Enabled = !string.IsNullOrEmpty(passwordTbx.Text) &&
                !string.IsNullOrEmpty(usernameTbx.Text);
        }

        private void passwordTbx_TextChanged(object sender, EventArgs e)
        {
            loginBtn.Enabled = !string.IsNullOrEmpty(passwordTbx.Text) &&
                !string.IsNullOrEmpty(usernameTbx.Text);
        }

        private void passwordTbx_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData != Keys.Enter)
                return;
            TryLogin();
        }
        private void TryLogin()
        {
            var username = usernameTbx.Text;
            var password = passwordTbx.Text;

            bool success;
            string message;
            (success, message) = AppController.Instance.Login(username, password);

            if (success)
            {
                var admin = AppController.Instance.Admin;
                MessageBox.Show($"WELCOME {admin.Name} {admin.Surname}!", "Login successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show(message, "Login failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
