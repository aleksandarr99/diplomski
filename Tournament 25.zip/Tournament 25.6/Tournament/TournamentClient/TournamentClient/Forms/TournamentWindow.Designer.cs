﻿
namespace FootballTournament.Forms
{
    partial class TournamentWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.descriptionLbl = new System.Windows.Forms.Label();
            this.gamesGrid = new System.Windows.Forms.DataGridView();
            this.allGamesLbl = new System.Windows.Forms.Label();
            this.createGameLbl = new System.Windows.Forms.Label();
            this.firstTeamTbx = new System.Windows.Forms.TextBox();
            this.firstTeamLbl = new System.Windows.Forms.Label();
            this.secondTeamLbl = new System.Windows.Forms.Label();
            this.secondTeamTbx = new System.Windows.Forms.TextBox();
            this.firstTeamScoreTbx = new System.Windows.Forms.TextBox();
            this.secondTeamScoreTbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.refereeTbx = new System.Windows.Forms.TextBox();
            this.clearBtn = new MetroFramework.Controls.MetroButton();
            this.createBtn = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.gamesGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // descriptionLbl
            // 
            this.descriptionLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.descriptionLbl.AutoSize = true;
            this.descriptionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.descriptionLbl.Location = new System.Drawing.Point(23, 60);
            this.descriptionLbl.MaximumSize = new System.Drawing.Size(900, 0);
            this.descriptionLbl.Name = "descriptionLbl";
            this.descriptionLbl.Size = new System.Drawing.Size(877, 36);
            this.descriptionLbl.TabIndex = 3;
            this.descriptionLbl.Text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce pellentesque place" +
    "rat nisl et sodales. Nam sollicitudin quis ex sit amet dapibus. \r\n";
            this.descriptionLbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gamesGrid
            // 
            this.gamesGrid.AllowUserToAddRows = false;
            this.gamesGrid.AllowUserToDeleteRows = false;
            this.gamesGrid.AllowUserToResizeRows = false;
            this.gamesGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gamesGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gamesGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gamesGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gamesGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gamesGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.gamesGrid.Location = new System.Drawing.Point(26, 143);
            this.gamesGrid.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.gamesGrid.MultiSelect = false;
            this.gamesGrid.Name = "gamesGrid";
            this.gamesGrid.ReadOnly = true;
            this.gamesGrid.RowHeadersVisible = false;
            this.gamesGrid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.gamesGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.gamesGrid.Size = new System.Drawing.Size(989, 376);
            this.gamesGrid.TabIndex = 17;
            this.gamesGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gamesGrid_CellFormatting);
            this.gamesGrid.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gamesGrid_ColumnHeaderMouseClick);
            // 
            // allGamesLbl
            // 
            this.allGamesLbl.AutoSize = true;
            this.allGamesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allGamesLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.allGamesLbl.Location = new System.Drawing.Point(22, 112);
            this.allGamesLbl.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.allGamesLbl.Name = "allGamesLbl";
            this.allGamesLbl.Size = new System.Drawing.Size(87, 24);
            this.allGamesLbl.TabIndex = 18;
            this.allGamesLbl.Text = "All Game";
            this.allGamesLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // createGameLbl
            // 
            this.createGameLbl.AutoSize = true;
            this.createGameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createGameLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.createGameLbl.Location = new System.Drawing.Point(23, 530);
            this.createGameLbl.Margin = new System.Windows.Forms.Padding(3, 30, 3, 0);
            this.createGameLbl.Name = "createGameLbl";
            this.createGameLbl.Size = new System.Drawing.Size(121, 24);
            this.createGameLbl.TabIndex = 19;
            this.createGameLbl.Text = "Create Game";
            this.createGameLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // firstTeamTbx
            // 
            this.firstTeamTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.firstTeamTbx.Location = new System.Drawing.Point(100, 565);
            this.firstTeamTbx.Name = "firstTeamTbx";
            this.firstTeamTbx.Size = new System.Drawing.Size(169, 20);
            this.firstTeamTbx.TabIndex = 20;
            this.firstTeamTbx.Click += new System.EventHandler(this.firstTeamTbx_Click);
            this.firstTeamTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tbx_KeyPress);
            // 
            // firstTeamLbl
            // 
            this.firstTeamLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.firstTeamLbl.AutoSize = true;
            this.firstTeamLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstTeamLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.firstTeamLbl.Location = new System.Drawing.Point(24, 565);
            this.firstTeamLbl.Name = "firstTeamLbl";
            this.firstTeamLbl.Size = new System.Drawing.Size(65, 15);
            this.firstTeamLbl.TabIndex = 21;
            this.firstTeamLbl.Text = "First Team";
            this.firstTeamLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secondTeamLbl
            // 
            this.secondTeamLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.secondTeamLbl.AutoSize = true;
            this.secondTeamLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondTeamLbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.secondTeamLbl.Location = new System.Drawing.Point(542, 565);
            this.secondTeamLbl.Name = "secondTeamLbl";
            this.secondTeamLbl.Size = new System.Drawing.Size(84, 15);
            this.secondTeamLbl.TabIndex = 23;
            this.secondTeamLbl.Text = "Second Team";
            this.secondTeamLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secondTeamTbx
            // 
            this.secondTeamTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.secondTeamTbx.Location = new System.Drawing.Point(367, 565);
            this.secondTeamTbx.Name = "secondTeamTbx";
            this.secondTeamTbx.Size = new System.Drawing.Size(169, 20);
            this.secondTeamTbx.TabIndex = 22;
            this.secondTeamTbx.Click += new System.EventHandler(this.firstTeamTbx_Click);
            this.secondTeamTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tbx_KeyPress);
            // 
            // firstTeamScoreTbx
            // 
            this.firstTeamScoreTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.firstTeamScoreTbx.Location = new System.Drawing.Point(275, 565);
            this.firstTeamScoreTbx.Name = "firstTeamScoreTbx";
            this.firstTeamScoreTbx.Size = new System.Drawing.Size(40, 20);
            this.firstTeamScoreTbx.TabIndex = 24;
            this.firstTeamScoreTbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.firstTeamScoreTbx.TextChanged += new System.EventHandler(this.firstTeamScoreTbx_TextChanged);
            this.firstTeamScoreTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TeamScoreTbx_KeyPress);
            // 
            // secondTeamScoreTbx
            // 
            this.secondTeamScoreTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.secondTeamScoreTbx.Location = new System.Drawing.Point(321, 565);
            this.secondTeamScoreTbx.Name = "secondTeamScoreTbx";
            this.secondTeamScoreTbx.Size = new System.Drawing.Size(40, 20);
            this.secondTeamScoreTbx.TabIndex = 25;
            this.secondTeamScoreTbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.secondTeamScoreTbx.TextChanged += new System.EventHandler(this.secondTeamScoreTbx_TextChanged);
            this.secondTeamScoreTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TeamScoreTbx_KeyPress);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(636, 565);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 15);
            this.label3.TabIndex = 29;
            this.label3.Text = "Referee:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // refereeTbx
            // 
            this.refereeTbx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.refereeTbx.Location = new System.Drawing.Point(701, 565);
            this.refereeTbx.Name = "refereeTbx";
            this.refereeTbx.Size = new System.Drawing.Size(169, 20);
            this.refereeTbx.TabIndex = 28;
            this.refereeTbx.Click += new System.EventHandler(this.refereeTbx_Click);
            this.refereeTbx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tbx_KeyPress);
            // 
            // clearBtn
            // 
            this.clearBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearBtn.Location = new System.Drawing.Point(957, 565);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(75, 20);
            this.clearBtn.TabIndex = 12;
            this.clearBtn.Text = "Clear";
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // createBtn
            // 
            this.createBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.createBtn.Location = new System.Drawing.Point(876, 565);
            this.createBtn.Name = "createBtn";
            this.createBtn.Size = new System.Drawing.Size(75, 20);
            this.createBtn.TabIndex = 11;
            this.createBtn.Text = "Create";
            this.createBtn.Click += new System.EventHandler(this.createBtn_Click);
            // 
            // TournamentWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(1050, 600);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.createBtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.refereeTbx);
            this.Controls.Add(this.secondTeamScoreTbx);
            this.Controls.Add(this.firstTeamScoreTbx);
            this.Controls.Add(this.secondTeamLbl);
            this.Controls.Add(this.secondTeamTbx);
            this.Controls.Add(this.firstTeamLbl);
            this.Controls.Add(this.firstTeamTbx);
            this.Controls.Add(this.createGameLbl);
            this.Controls.Add(this.allGamesLbl);
            this.Controls.Add(this.gamesGrid);
            this.Controls.Add(this.descriptionLbl);
            this.MinimumSize = new System.Drawing.Size(1050, 600);
            this.Name = "TournamentWindow";
            this.Text = "Tournament";
            ((System.ComponentModel.ISupportInitialize)(this.gamesGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label descriptionLbl;
        private System.Windows.Forms.DataGridView gamesGrid;
        private System.Windows.Forms.Label allGamesLbl;
        private System.Windows.Forms.Label createGameLbl;
        private System.Windows.Forms.TextBox firstTeamTbx;
        private System.Windows.Forms.Label firstTeamLbl;
        private System.Windows.Forms.Label secondTeamLbl;
        private System.Windows.Forms.TextBox secondTeamTbx;
        private System.Windows.Forms.TextBox firstTeamScoreTbx;
        private System.Windows.Forms.TextBox secondTeamScoreTbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox refereeTbx;
        private MetroFramework.Controls.MetroButton clearBtn;
        private MetroFramework.Controls.MetroButton createBtn;
    }
}