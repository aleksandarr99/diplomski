﻿using MetroFramework.Forms;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace FootballTournament.Forms
{
    public partial class UniversalSearchForm<T>
        : MetroForm
    {
        BindingList<T> _sourceList;
        public T SelectedItem { get; set; }

        public UniversalSearchForm()
        {
            InitializeComponent();
            var items = AppController.Instance.GetItems<T>();

            _sourceList = new BindingList<T>(items);
            dataGrid.DataSource = _sourceList;
            TryToHideIDColumn();
        }


        private void TryToHideIDColumn()
        {
            try
            {
                dataGrid.Columns["ID"].Visible = false;
            }
            catch
            { }
        }


        private void searchTextTbx_TextChanged(object sender, EventArgs e)
        {
            string searchingString = searchTextTbx.Text;

            if (string.IsNullOrEmpty(searchingString))
            {
                BindingList<T> filteredBindingList = new BindingList<T>(AppController.Instance.GetItems<T>());
                dataGrid.DataSource = filteredBindingList;
                TryToHideIDColumn();
            }
        }

        private void selectBtn_Click(object sender, EventArgs e)
        {
            if (dataGrid.SelectedRows.Count == 0)
                return;

            if (!(dataGrid.SelectedRows[0] is DataGridViewRow row))
                return;

            if (!(row.DataBoundItem is T selected))
                return;

            SelectedItem = selected;
            DialogResult = DialogResult.OK;
        }

        private void dataGrid_SelectionChanged(object sender, EventArgs e)
        {
            selectBtn.Enabled = dataGrid.SelectedRows.Count != 0;
        }

        private void searchTextTbx_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                var searchingString = searchTextTbx.Text;
                var result = AppController.Instance.SearchItems<T>(searchingString);
                if (result == null)
                    return;

                _sourceList = new BindingList<T>(result);
                dataGrid.DataSource = _sourceList;
                TryToHideIDColumn();
            }
        }
    }
}
