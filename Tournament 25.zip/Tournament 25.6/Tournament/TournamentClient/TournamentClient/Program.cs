﻿using FootballTournament.Forms;
using System;
using System.Windows.Forms;
using TournamentModels;

namespace FootballTournament
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //var loginForm = new LoginForm();
            //var result = loginForm.ShowDialog();

            //if (result != DialogResult.OK)
            //    return;

            AppController.Instance.Login("admin", "admin");

            Application.Run(new MainForm());



            //Application.Run(new MainForm());
            //var adminSearch = new UniversalSearchForm<Admin>();
            //Application.Run(adminSearch);

            //var playersSearch = new UniversalSearchForm<Player>();
        }
    }
}
