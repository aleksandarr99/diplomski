﻿namespace FootballTournament
{
    public enum ActiveViews
    {
        Admins,
        Referees,
        Players,
        Countries,
        Tournaments,
        Games
    }

    public enum Action
    {
        Create,
        Update,
        Delete
    }
}
