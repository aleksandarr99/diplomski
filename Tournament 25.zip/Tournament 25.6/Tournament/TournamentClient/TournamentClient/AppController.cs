﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using TournamentModels;

namespace FootballTournament
{
    public class AppController
    {
        private static AppController _instance;
        public static AppController Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new AppController();
                return _instance;
            }
        }

        private AppController()
        {
        }

        public Admin Admin { get; set; }

        public bool RootAdmin
        {
            get => Admin != null && Admin.Name.ToLower() == "admin";
        }




        public (bool, string) Login(string username, string password)
        {
            using (var backend = new BackendCommunication())
            {
                string message;
                (Admin, message) = backend.Login(username, password);

                return (Admin != null, message);
            }
        }

        public void FillGame(Game game)
        {
            if (game.FirstTeam == null)
                game.FirstTeam = Countries.FirstOrDefault(x => x.Id == game.FirstTeamID);
            if (game.SecondTeam == null)
                game.SecondTeam = Countries.FirstOrDefault(x => x.Id == game.SecondTeamID);
            if (game.Referee == null)
                game.Referee = Referees.FirstOrDefault(x => x.Id == game.RefereeID);
            if(game.Odds == null)
                game.Odds = SearchOdds(game.FirstTeamID, game.SecondTeamID);
        }

        public BindingList<T> GetItems<T>()
        {
            if (typeof(T) == typeof(Admin))
            {
                return (BindingList<T>)(object)Admins;
            }
            if (typeof(T) == typeof(Player))
            {
                return (BindingList<T>)(object)Players;
            }
            if (typeof(T) == typeof(Country))
            {
                return (BindingList<T>)(object)Countries;
            }
            if (typeof(T) == typeof(Referee))
            {
                return (BindingList<T>)(object)Referees;
            }
            if (typeof(T) == typeof(Tournament))
            {
                return (BindingList<T>)(object)Tournaments;
            }
            if (typeof(T) == typeof(Game))
            {
                return (BindingList<T>)(object)Games;
            }

            return null;
        }

        public List<T> SearchItems<T>(string searchingString)
        {
            if (typeof(T) == typeof(Admin))
            {
                List<Admin> result;
                string message;
                (result, message) = SearchAdmins(searchingString);

                return (List<T>)(object)result;
            }
            if (typeof(T) == typeof(Player))
            {
                List<Player> result;
                string message;
                (result, message) = SearchPlayers(searchingString);
                return (List<T>)(object)result;
            }
            if (typeof(T) == typeof(Country))
            {
                List<Country> result;
                string message;
                (result, message) = SearchCountries(searchingString);
                return (List<T>)(object)result;
            }
            if (typeof(T) == typeof(Referee))
            {
                List<Referee> result;
                string message;
                (result, message) = SearchReferees(searchingString);
                return (List<T>)(object)result;
            }
            return null;
        }

        #region Players

        private BindingList<Player> _players;

        public BindingList<Player> Players
        {
            get
            {
                if (_players == null)
                {
                    string message;
                    List<Player> players;
                    (players, message) = SearchPlayers(null);

                    players.ForEach(item =>
                    {
                        if (item.Country == null)
                        {
                            item.Country = Countries.ToList().Find(x => x.Id == item.CountryID);
                            item.Country.Players.Add(item);
                        }
                    });

                    _players = new BindingList<Player>(players);
                }
                return _players;
            }
        }

        private (List<Player>, string) SearchPlayers(string searchingString)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                return backend.SearchPlayers(searchingString);
            }
        }

        public (bool, string) CreateNewPlayer(Player player)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreatePlayer(player);
                if (!result.Item1)
                    return result;

                Players.Add(player);
                player.Country.Players.Add(player);
                return result;
            }
        }

        public (bool, string) UpdatePlayer(Player player)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdatePlayer(player);
                if (!result.Item1)
                    return result;

                var existing = Players.FirstOrDefault(x => x.Number == player.Number && x.CountryID == player.CountryID);
                if (existing != null)
                {
                    existing.Number = player.Number;
                    existing.CountryID = player.CountryID;
                    existing.Name = player.Name;
                    existing.Country = player.Country;
                    existing.Surname = player.Surname;
                }
                return result;
            }
        }

        public (bool, string) DeletePlayer(Player selectedPlayer)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeletePlayer(selectedPlayer);
                if (success)
                {
                    Players.Remove(selectedPlayer);
                    selectedPlayer.Country.Players.Remove(selectedPlayer);
                }
                return (success, message);
            }
        }

        #endregion

        #region Admins
        private BindingList<Admin> _admins;
        public BindingList<Admin> Admins
        {
            get
            {
                if (_admins == null)
                {
                    string message;
                    List<Admin> admins;
                    (admins, message) = SearchAdmins(null);
                    _admins = new BindingList<Admin>(admins);
                }
                return _admins;
            }
        }

        private (List<Admin>, string) SearchAdmins(string searching)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                return backend.SearchAdmins(searching);
            }
        }

        public (bool, string) CreateNewAdmin(Admin admin)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreateAdmin(admin);
                if (!result.Item1)
                    return result;

                Admins.Add(admin);
                return result;
            }
        }

        public (bool, string) UpdateAdmin(Admin admin)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateAdmin(admin);
                if (!result.Item1)
                    return result;

                var existing = Admins.FirstOrDefault(x => x.Id == admin.Id);
                if (existing != null)
                {
                    existing.Name = admin.Name;
                    existing.Surname = admin.Surname;
                    existing.Password = admin.Password;
                    existing.Username = admin.Username;
                }
                return result;
            }
        }

        public (bool, string) DeleteAdmin(Admin admin)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeleteAdmin(admin);

                if (success)
                    Admins.Remove(admin);
                return (success, message);
            }
        }

        #endregion

        #region Countries

        private BindingList<Country> _countries;
        public BindingList<Country> Countries
        {
            get
            {
                if (_countries == null)
                {
                    string message;
                    List<Country> countries;
                    (countries, message) = SearchCountries(null);
                    if (countries == null)
                        countries = new List<Country>();
                    _countries = new BindingList<Country>(countries);
                }
                return _countries;
            }
        }

        private (List<Country>, string) SearchCountries(string searchingString)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                return backend.SearchCountries(searchingString);
            }
        }

        public (bool, string) CreateNewCountry(Country country)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreateCountry(country);
                if (!result.Item1)
                    return result;

                Countries.Add(country);
                return result;
            }
        }

        public (bool, string) UpdateCountry(Country country)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateCountry(country);
                if (!result.Item1)
                    return result;

                var existing = Countries.FirstOrDefault(x => x.Id == country.Id);
                if (existing != null)
                {
                    existing.Name = country.Name;
                }
                return result;
            }
        }

        public (bool, string) DeleteCountry(Country selectedCountry)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeleteCountry(selectedCountry);

                if (success)
                {
                    Countries.Remove(selectedCountry);
                    var players = (new List<Player>(Players)).FindAll(x => x.CountryID == selectedCountry.Id);
                    foreach (var player in players)
                        Players.Remove(player);
                }
                return (success, message);
            }
        }

        #endregion

        #region Referees

        private BindingList<Referee> _referees;
        public BindingList<Referee> Referees
        {
            get
            {
                if (_referees == null)
                {
                    string message;
                    List<Referee> referees;
                    (referees, message) = SearchReferees(null);
                    _referees = new BindingList<Referee>(referees);
                }
                return _referees;
            }
        }

        private (List<Referee>, string) SearchReferees(string searchingString)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                return backend.SearchReferees(searchingString);
            }
        }

        public (bool, string) CreateNewReferee(Referee referee)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreateReferee(referee);
                if (!result.Item1)
                    return result;

                Referees.Add(referee);
                return result;
            }
        }

        public (bool, string) UpdateReferee(Referee referee)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateReferee(referee);
                if (!result.Item1)
                    return result;

                var existing = Referees.FirstOrDefault(x => x.Id == referee.Id);
                if (existing != null)
                {
                    existing.Name = referee.Name;
                    existing.Surname = referee.Surname;
                    existing.Experience = referee.Experience;
                }
                return result;
            }
        }

        public (bool, string) DeleteReferee(Referee selecteReferee)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeleteReferee(selecteReferee);
                if (success)
                    Referees.Remove(selecteReferee);
                return (success, message);
            }
        }

        #endregion

        #region Games

        private BindingList<Game> _games;
        public BindingList<Game> Games
        {
            get
            {
                if (_games != null)
                    return _games;

                string message;
                List<Game> games;
                (games, message) = SearchGames(null);
                var countries = Countries.ToList();
                var tournaments = Tournaments.ToList();
                var referees = Referees.ToList();

                if (games == null)
                {
                    _games = new BindingList<Game>();
                }
                else
                {
                    games.ForEach(game =>
                    {
                        game.FirstTeam = countries.Find(x => x.Id == game.FirstTeamID);
                        game.SecondTeam = countries.Find(x => x.Id == game.SecondTeamID);
                        game.Referee = referees.Find(x => x.Id == game.RefereeID);
                        game.Tournament = tournaments.Find(x => x.Id == game.TournamentID);
                    });
                    _games = new BindingList<Game>(games);
                }
                return _games;
            }
        }

        private (List<Game>, string) SearchGames(string searchingString)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result =  backend.SearchGames(searchingString);
                if (result.Item1 == null)
                    return result;

                foreach (var game in result.Item1)
                {
                    if (game.FirstTeam == null)
                        game.FirstTeam = Countries.FirstOrDefault(x => x.Id == game.FirstTeamID);
                    if (game.SecondTeam == null)
                        game.SecondTeam = Countries.FirstOrDefault(x => x.Id == game.SecondTeamID);
                    if (game.Referee == null)
                        game.Referee = Referees.FirstOrDefault(x => x.Id == game.RefereeID);
                }
                return result;
            }
        }

        public (bool, string) UpdateGame(Game game)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateGame(game);
                if (!result.Item1)
                    return result;

                var existing = Games.FirstOrDefault(x => x.Id == game.Id);
                if (existing != null)
                {
                    existing.FirstTeamScore = game.FirstTeamScore;
                    existing.SecondTeamScore = game.SecondTeamScore;
                }
                return result;
            }
        }

        public (bool, string) CreateNewGame(Game game)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreateGame(game);
                if (!result.Item1)
                    return result;

                Games.Add(game);
                return result;
            }
        }

        public (bool, string) DeleteGame(Game selectedGame)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeleteGame(selectedGame);
                if (success)
                    Games.Remove(selectedGame);
                return (success, message);
            }
        }

        #endregion


        #region Tournament

        private BindingList<Tournament> _tournaments;
        public BindingList<Tournament> Tournaments
        {
            get
            {
                if (_tournaments == null)
                {
                    string message;
                    List<Tournament> tournaments;
                    (tournaments, message) = SearchTournaments(null);
                    if (tournaments == null)
                        tournaments = new List<Tournament>();
                    _tournaments = new BindingList<Tournament>(tournaments);
                }
                return _tournaments;
            }
        }

        private (List<Tournament>, string) SearchTournaments(string searchingString)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var tournaments = backend.SearchTournaments(searchingString);
                if (tournaments.Item1 == null)
                    return tournaments;

                foreach (var tournament in tournaments.Item1)
                {
                    foreach (var id in tournament.CountryIds)
                    {
                        if (tournament.Countries.Find(x => x.Id == id) != null)
                            continue;

                        var existing = Countries.FirstOrDefault(x => x.Id == id);
                        if (existing != null)
                            tournament.Countries.Add(existing);
                    }

                    foreach (var refId in tournament.RefereeIds)
                    {
                        if (tournament.Referees.Find(x => x.Id == refId) != null)
                            continue;

                        var existing = Referees.FirstOrDefault(x => x.Id == refId);
                        if (existing != null)
                            tournament.Referees.Add(existing);
                    }
                }

                return tournaments;
            }
        }

        public (bool, string) CreateNewTournament(Tournament tournament)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.CreateTournament(tournament);
                if (!result.Item1)
                    return result;
                Tournaments.Add(tournament);
                return result;
            }
        }

        public (List<Game>, string) CreateTournamentGames(Tournament tournament)
        {
            List<Game> gamesVM = new List<Game>();
            try
            {
                List<Game> games = new List<Game>();
                int capacity = (int)tournament.Capacity;
                Game game = null;
                Game gameVM = null;
                List<int> countries = new List<int>(tournament.CountryIds);
                int refIndex = 0;
                int refCount = capacity / 4;
                for (int left = capacity - 1; left >= 0; left--)
                {
                    Random random = new Random();
                    int index = random.Next(0, left);
                    int countryID = countries[index];

                    if (left % 2 == 1)
                    {
                        game = new Game()
                        {
                            Stage = capacity / 2,
                            TournamentID = tournament.Id,
                            FirstTeamID = countryID,
                            RefereeID = tournament.RefereeIds[refIndex % refCount]
                        };

                        gameVM = new Game()
                        {
                            FirstTeamID = countryID,
                            FirstTeam = tournament.Countries.Find(x => x.Id == countryID),
                            Stage = capacity / 2,
                            TournamentID = tournament.Id,
                            Tournament = tournament,
                            RefereeID = tournament.RefereeIds[refIndex % refCount],
                            Referee = tournament.Referees[refIndex % refCount]
                        };

                        refIndex++;
                    }
                    else
                    {
                        game.SecondTeamID = countryID;
                        games.Add(game);

                        gameVM.SecondTeamID = countryID;
                        gameVM.SecondTeam = tournament.Countries.Find(x => x.Id == countryID);
                        gamesVM.Add(gameVM);
                    }
                    countries.RemoveAt(index);
                }

                using (BackendCommunication backend = new BackendCommunication())
                {
                    var result = backend.CreateGames(games);
                    if (!result.Item1)
                        return (null, result.Item2);

                    for (int i = 0; i < gamesVM.Count; i++)
                    {
                        gamesVM[i].Id = games[i].Id;
                        Games.Add(gamesVM[i]);
                    }
                    return (games, result.Item2);
                }
            }
            catch (Exception e)
            {
                return (null, "[CreateTournamentGames]: " + e.Message);
            }
        }

        public (List<Game>, string) CreateNextStage(Tournament tournament)
        {
            List<Game> nextStageGames = new List<Game>();
            try
            {
                var gamesList = Games.ToList();
                var stages = gamesList.FindAll(x => x.TournamentID == tournament.Id).Select(x => x.Stage).OrderBy(x => x);
                if (stages.Count() == 0)
                    return (null, "Invalid Stage");
                var stage = stages.First();

                var currentStage = gamesList.FindAll(x => x.Stage == stage && tournament.Id == x.TournamentID);

                //currentStage = Games.Select(x => x.)

                List<Game> games = new List<Game>();
                List<int> countries = new List<int>(tournament.CountryIds);
                int refIndex = 0;
                for (int i = 0; i < currentStage.Count ; i += 2)
                {
                    int nextStage = currentStage[i].Stage / 2;
                    var firstTeam = currentStage[i].Winner;
                    var secondTeam = currentStage[i + 1].Winner;


                    refIndex %= tournament.RefereeIds.Count;

                    games.Add(new Game()
                    {
                        FirstTeamID = firstTeam.Id,
                        SecondTeamID = secondTeam.Id,
                        Stage = nextStage,
                        TournamentID = tournament.Id,
                        RefereeID = tournament.RefereeIds[refIndex],
                    });

                    nextStageGames.Add(new Game()
                    {
                        FirstTeamID = firstTeam.Id,
                        FirstTeam = firstTeam,
                        SecondTeamID = secondTeam.Id,
                        SecondTeam = secondTeam,
                        Stage = nextStage,
                        TournamentID = tournament.Id,
                        Tournament = tournament,
                        RefereeID = tournament.RefereeIds[refIndex],
                        Referee = tournament.Referees[refIndex]
                    });

                    refIndex++;
                }

                using (BackendCommunication backend = new BackendCommunication())
                {
                    var result = backend.CreateGames(games);
                    if (!result.Item1)
                        return (null, result.Item2);

                    for(int i = 0; i < nextStageGames.Count; i++)
                    {
                        nextStageGames[i].Id = games[i].Id;
                        Games.Add(nextStageGames[i]);
                    }
                    return (games, result.Item2);
                }
            }
            catch (Exception e)
            {
                return (null, "[CreateTournamentGames]: " + e.Message);
            }
        }

        public (bool, string) UpdateGames(List<Game> games)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateGames(games);
                if (!result.Item1)
                    return result;

                foreach (var game in games)
                {
                    var existing = Games.FirstOrDefault(x => x.Id == game.Id);
                    if (existing != null)
                    {
                        existing.FirstTeamScore = game.FirstTeamScore;
                        existing.SecondTeamScore = game.SecondTeamScore;
                    }
                }

                return result;
            }
        }

        public (bool, string) UpdateTournament(Tournament tournament)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.UpdateTournament(tournament);
                if (!result.Item1)
                    return result;

                var existing = Tournaments.FirstOrDefault(x => x.Id == tournament.Id);
                if (existing != null)
                {
                    existing.City = tournament.City;
                    existing.Name = tournament.Name;
                    existing.StartTime = tournament.StartTime;
                    existing.EndTime = tournament.EndTime;
                    existing.Description = tournament.Description;
                    existing.WinnerName = tournament.WinnerName;
                }
                return result;
            }
        }


        public (bool, string) DeleteTournament(Tournament selectedTournamnt)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                bool success;
                string message;
                (success, message) = backend.DeleteTournament(selectedTournamnt);
                if (success)
                    Tournaments.Remove(selectedTournamnt);
                return (success, message);
            }
        }

        #endregion

        #region Odds
        private Odds SearchOdds(int firstTeamID, int secondTeamID)
        {
            using (BackendCommunication backend = new BackendCommunication())
            {
                var result = backend.SearchOdds(firstTeamID, secondTeamID).Item1;
                if (result == null || result.Count == 0)
                    return null;

                return result[0];
            }
        }
        #endregion
    }
}
