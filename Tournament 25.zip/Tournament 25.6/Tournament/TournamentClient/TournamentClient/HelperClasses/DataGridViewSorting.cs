﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace FootballTournament.HelperClasses
{
    public class DataGridViewSorting
    {
        public static void Sort<T>(DataGridView gridView, int columnIndex, BindingList<T> bindingList)
        {
            DataGridViewColumn clickedColumn = gridView.Columns[columnIndex];

            // Provjerite je li kliknuta kolona već sortirana
            if (clickedColumn.SortMode != DataGridViewColumnSortMode.Automatic)
                return;

            // Promijenite smjer sortiranja
            ListSortDirection newSortDirection = ListSortDirection.Ascending;
            if (clickedColumn.HeaderCell.SortGlyphDirection == SortOrder.Ascending)
                newSortDirection = ListSortDirection.Descending;

            // Očistite trenutni sort status svih stupaca
            foreach (DataGridViewColumn column in gridView.Columns)
                column.HeaderCell.SortGlyphDirection = SortOrder.None;

            // Postavite ikonu sortiranja za kliknuti stupac
            clickedColumn.HeaderCell.SortGlyphDirection = newSortDirection == ListSortDirection.Ascending
                ? SortOrder.Ascending : SortOrder.Descending;

            // Izvedite sortiranje podataka
            SortData(bindingList, clickedColumn.DataPropertyName, newSortDirection);
        }


        private static void SortData<T>(BindingList<T> bindingList, string propertyName, ListSortDirection sortDirection)
        {
            PropertyDescriptor property = TypeDescriptor.GetProperties(typeof(T))[propertyName];
            List<T> list = bindingList.ToList();
            list.Sort(new Comparison<T>((x, y) =>
            {
                object valueX = property.GetValue(x);
                object valueY = property.GetValue(y);
                int result = Comparer<object>.Default.Compare(valueX, valueY);
                return sortDirection == ListSortDirection.Ascending ? result : -result;
            }));

            bindingList.Clear();
            foreach (T item in list)
                bindingList.Add(item);
        }
    }
}
