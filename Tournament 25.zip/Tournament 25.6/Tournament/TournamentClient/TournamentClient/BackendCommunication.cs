﻿using CommunicationModule;
using CommunicationModule.Requests;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using TournamentModels;

namespace FootballTournament
{
    class BackendCommunication : IDisposable
    {
        private SocketClient _client;
        private static readonly string IP_ADDRESS = "localhost";
        private static readonly int PORT = 1234;

        public BackendCommunication()
        {
            _client = new SocketClient(IP_ADDRESS, PORT);
            _client.Connect();
        }

        public (Admin, string) Login(string username, string password)
        {
            LoginRequest request = new LoginRequest()
            {
                Username = username,
                Password = password
            };

            var result = _client.Login(request);

            if (result == null)
                return (null, "Login failed");

            if (result.Admin != null)
                return (result.Admin, result.ResultMessage);
            return (null, result.ResultMessage);
        }

        #region Players

        public (List<Player>, string) SearchPlayers(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>()
                    {
                        { "Name", searchingString },
                        { "Surname", searchingString },
                        { "Number", searchingString },
                    };

                PlayerSearchRequest request = new PlayerSearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreatePlayer(Player player)
        {
            PlayerCreateRequest playerRequest = new PlayerCreateRequest()
            {
                Value = player
            };

            var result = _client.Create(playerRequest);

            if (result == null)
                return (false, "Invalid player creation!");

            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdatePlayer(Player player)
        {
            PlayerUpdateRequest playerRequest = new PlayerUpdateRequest()
            {
                Value = player
            };

            var result = _client.Update(playerRequest);

            if (result == null)
                return (false, "Invalid player update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeletePlayer(Player selectedPlayer)
        {
            try
            {
                PlayerDeleteRequest deleteRequest = new PlayerDeleteRequest()
                {
                    Player = selectedPlayer
                };

                var result = _client.PlayerDelete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a player");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Admins
        public (List<Admin>, string) SearchAdmins(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>()
                    {
                        { "Name", searchingString },
                        { "Username", searchingString },
                        { "Surname", searchingString },
                        { "Password", searchingString }
                    };

                AdminSearchRequest request = new AdminSearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");
                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreateAdmin(Admin admin)
        {
            AdminCreateRequest refereeRequest = new AdminCreateRequest()
            {
                Value = admin
            };

            var result = _client.Create(refereeRequest);

            if (result == null)
                return (false, "Invalid admin creation!");
            admin.Id = result.Value.Id;
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateAdmin(Admin admin)
        {
            AdminUpdateRequest adminRequest = new AdminUpdateRequest()
            {
                Value = admin
            };

            var result = _client.Update(adminRequest);

            if (result == null)
                return (false, "Invalid admin update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeleteAdmin(Admin selectedAdmin)
        {
            try
            {
                DeleteRequest deleteRequest = new DeleteRequest()
                {
                    ObjectType = ObjectType.Admin,
                    ID = selectedAdmin.Id
                };

                var result = _client.Delete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a admin");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Countries

        public (List<Country>, string) SearchCountries(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>()
                    {
                        { "Name", searchingString }
                    };

                CountrySearchRequest request = new CountrySearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreateCountry(Country country)
        {
            CountryCreateRequest countryRequest = new CountryCreateRequest()
            {
                Value = country
            };

            var result = _client.Create(countryRequest);

            if (result == null)
                return (false, "Invalid country creation!");

            country.Id = result.Value.Id;
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateCountry(Country country)
        {
            CountryUpdateRequest countryRequest = new CountryUpdateRequest()
            {
                Value = country
            };

            var result = _client.Update(countryRequest);

            if (result == null)
                return (false, "Invalid country update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeleteCountry(Country selectedCountry)
        {
            try
            {
                DeleteRequest deleteRequest = new DeleteRequest()
                {
                    ObjectType = ObjectType.Country,
                    ID = selectedCountry.Id
                };

                var result = _client.Delete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a country");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Referees

        public (List<Referee>, string) SearchReferees(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>()
                    {
                        { "Name", searchingString },
                        { "Surname", searchingString }
                    };

                RefereeSearchRequest request = new RefereeSearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreateReferee(Referee referee)
        {
            RefereeCreateRequest refereeRequest = new RefereeCreateRequest()
            {
                Value = referee
            };

            var result = _client.Create(refereeRequest);

            if (result == null)
                return (false, "Invalid referee creation!");
            referee.Id = result.Value.Id;

            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateReferee(Referee referee)
        {
            RefereeUpdateRequest refereeRequest = new RefereeUpdateRequest()
            {
                Value = referee
            };

            var result = _client.Update(refereeRequest);

            if (result == null)
                return (false, "Invalid referee update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeleteReferee(Referee selectedReferee)
        {
            try
            {
                DeleteRequest deleteRequest = new DeleteRequest()
                {
                    ObjectType = ObjectType.Referee,
                    ID = selectedReferee.Id
                };

                var result = _client.Delete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a referee");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Games

        public (List<Game>, string) SearchGames(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>();

                GameSearchRequest request = new GameSearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreateGame(Game game)
        {
            GameCreateRequest refereeRequest = new GameCreateRequest()
            {
                Value = game
            };

            var result = _client.Create(refereeRequest);

            if (result == null)
                return (false, "Invalid game creation!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) CreateGames(List<Game> games)
        {
            GameMultiCreateRequest request = new GameMultiCreateRequest()
            {
                Values = games
            };

            var result = _client.MultiCreate(request);

            if (result == null)
                return (false, "Invalid multi games creation!");
            if (result.Success)
                for (int i = 0; i < games.Count; i++)
                    games[i].Id = result.Values[i].Id;

            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateGames(List<Game> games)
        {
            GameMultiUpdateRequest request = new GameMultiUpdateRequest()
            {
                Values = games
            };

            var result = _client.MultiUpdate(request);
            if (result == null)
                return (false, "Invalid multi games update!");

            foreach (var game in games)
            {
                var existing = result.Values.Find(x => x.Id == game.Id);
                if (existing != null)
                {
                    game.FirstTeamScore = existing.FirstTeamScore;
                    game.SecondTeamScore = existing.SecondTeamScore;
                }
            }

            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateGame(Game game)
        {
            GameUpdateRequest gameRequest = new GameUpdateRequest()
            {
                Value = game
            };

            var result = _client.Update(gameRequest);

            if (result == null)
                return (false, "Invalid game update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeleteGame(Game game)
        {
            try
            {
                DeleteRequest deleteRequest = new DeleteRequest()
                {
                    ObjectType = ObjectType.Game,
                    ID = game.Id
                };

                var result = _client.Delete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a game");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Tournaments

        public (List<Tournament>, string) SearchTournaments(string searchingString)
        {
            try
            {
                Dictionary<string, string> param = string.IsNullOrEmpty(searchingString)
                    ? null
                    : new Dictionary<string, string>()
                    {
                        { "Name", searchingString },
                        { "City", searchingString }
                    };

                TournamentSearchRequest request = new TournamentSearchRequest()
                {
                    Parameters = param,
                    Operation = LogicalOperation.Or
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        public (bool, string) CreateTournament(Tournament tournament)
        {
            TournamentCreateRequest refereeRequest = new TournamentCreateRequest()
            {
                Value = tournament
            };

            var result = _client.Create(refereeRequest);

            if (result == null)
                return (false, "Invalid tournament creation!");

            tournament.Id = result.Value.Id;
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) UpdateTournament(Tournament tournament)
        {
            TournamentUpdateRequest tournamentRequest = new TournamentUpdateRequest()
            {
                Value = tournament
            };

            var result = _client.Update(tournamentRequest);

            if (result == null)
                return (false, "Invalid tournament update!");
            return (result.Success, result.ResultMessage);
        }

        public (bool, string) DeleteTournament(Tournament tournament)
        {
            try
            {
                DeleteRequest deleteRequest = new DeleteRequest()
                {
                    ObjectType = ObjectType.Tournament,
                    ID = tournament.Id
                };

                var result = _client.Delete(deleteRequest);

                if (result == null)
                    return (false, "Failed to delete a tournament");

                return (result.Success, result.ResultMessage);
            }
            catch (Exception e)
            {
                return (false, e.Message);
            }
        }

        #endregion

        #region Odds

        public (List<Odds>, string) SearchOdds(int homeId = -1, int awayId = -1)
        {
            try
            {
                var request = new OddsSearchRequest()
                {
                    HomeId = homeId,
                    AwayId = awayId
                };

                var result = _client.Search(request);
                if (result == null)
                    return (null, "Invalid search");

                return (result.Result, result.ResultMessage);

            }
            catch (Exception e)
            {
                return (null, e.Message);
            }
        }

        #endregion

        public void Dispose()
        {
            try
            {
                _client.Disconnect();
            }
            catch
            {
            }
        }

    }
}
